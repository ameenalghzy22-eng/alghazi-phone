<?php
/**
 * AL GHAZI Phone Store - Order Tracking Page
 * متجر الغزي للهواتف الذكية - صفحة تتبع الطلبات والشحنات
 */

$page_title = 'تتبع الطلب';
$active_nav = 'order_tracking';
require_once __DIR__ . '/includes/header.php';
$pdo = get_db();

$search_order = trim($_GET['order'] ?? $_POST['order_number'] ?? '');
$search_contact = trim($_GET['email'] ?? $_POST['contact_info'] ?? '');

$found_order = null;
$order_items = [];
$error_msg = null;

if (!empty($search_order) && !empty($search_contact)) {
    $stmt = $pdo->prepare("
        SELECT * FROM orders 
        WHERE (order_number = ? OR id = ?) 
          AND (customer_email = ? OR customer_phone = ?)
    ");
    $stmt->execute([$search_order, $search_order, $search_contact, $search_contact]);
    $found_order = $stmt->fetch();

    if ($found_order) {
        $stmt_items = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $stmt_items->execute([$found_order['id']]);
        $order_items = $stmt_items->fetchAll();
    } else {
        $error_msg = current_lang() === 'ar' 
            ? 'لم يتم العثور على أي طلب يطابق البيانات المدخلة. يرجى التأكد من رقم الطلب والبريد/الهاتف.' 
            : 'No matching order found. Please check your order number and contact information.';
    }
}
?>

<div style="max-width:750px; margin: 30px auto 60px;">
  <div class="section-header">
    <h1 class="section-title">📦 <?php _e('track_order_title'); ?></h1>
  </div>

  <!-- Search Card -->
  <div class="cart-table-card" style="margin-bottom:30px;">
    <form action="order-tracking.php" method="GET">
      <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px; margin-bottom:18px;">
        <div class="form-group" style="margin:0;">
          <label class="form-label"><?php _e('enter_order_number'); ?> *</label>
          <input type="text" name="order" class="form-control" placeholder="ORD-2026-9011" value="<?php echo htmlspecialchars($search_order); ?>" required>
        </div>
        <div class="form-group" style="margin:0;">
          <label class="form-label"><?php _e('enter_order_email'); ?> *</label>
          <input type="text" name="email" class="form-control" placeholder="customer@alghazi.com" value="<?php echo htmlspecialchars($search_contact); ?>" required>
        </div>
      </div>
      <button type="submit" class="btn-primary" style="padding:12px;">
        🔍 <?php _e('track_now'); ?>
      </button>
    </form>
    
    <div style="margin-top:14px; font-size:0.8rem; color:var(--text-dim); text-align:center;">
      💡 <?php echo current_lang() === 'ar' ? 'يمكنك تجربة رقم الطلب التجريبي: ORD-2026-9011 مع البريد: customer@alghazi.com' : 'Try sample tracking: ORD-2026-9011 with email: customer@alghazi.com'; ?>
    </div>
  </div>

  <?php if ($error_msg): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error_msg); ?></div>
  <?php endif; ?>

  <!-- Order Details & Live Tracking Display -->
  <?php if ($found_order): ?>
    <div class="cart-table-card">
      <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--border-color); padding-bottom:16px; margin-bottom:20px;">
        <div>
          <h2 style="font-size:1.35rem; font-weight:800; color:#fff;"><?php echo htmlspecialchars($found_order['order_number']); ?></h2>
          <span style="font-size:0.85rem; color:var(--text-muted);"><?php _e('order_date'); ?>: <?php echo date('Y-m-d', strtotime($found_order['created_at'])); ?></span>
        </div>
        <div>
          <span class="status-badge status-<?php echo $found_order['status']; ?>" style="font-size:0.9rem; padding:6px 14px;">
            <?php _e('status_' . $found_order['status']); ?>
          </span>
        </div>
      </div>

      <!-- Stepper -->
      <?php
        $steps = ['pending', 'processing', 'shipped', 'delivered'];
        $current_index = array_search($found_order['status'], $steps);
        if ($current_index === false) $current_index = 0;
      ?>
      <div class="tracking-steps">
        <div class="step-item <?php echo $current_index >= 0 ? 'completed' : ''; ?> <?php echo $found_order['status'] === 'pending' ? 'active' : ''; ?>">
          <div class="step-circle">1</div>
          <div class="step-label"><?php _e('status_pending'); ?></div>
        </div>
        <div class="step-item <?php echo $current_index >= 1 ? 'completed' : ''; ?> <?php echo $found_order['status'] === 'processing' ? 'active' : ''; ?>">
          <div class="step-circle">2</div>
          <div class="step-label"><?php _e('status_processing'); ?></div>
        </div>
        <div class="step-item <?php echo $current_index >= 2 ? 'completed' : ''; ?> <?php echo $found_order['status'] === 'shipped' ? 'active' : ''; ?>">
          <div class="step-circle">3</div>
          <div class="step-label"><?php _e('status_shipped'); ?></div>
        </div>
        <div class="step-item <?php echo $current_index >= 3 ? 'completed' : ''; ?> <?php echo $found_order['status'] === 'delivered' ? 'active' : ''; ?>">
          <div class="step-circle">4</div>
          <div class="step-label"><?php _e('status_delivered'); ?></div>
        </div>
      </div>

      <!-- Shipping Destination -->
      <div style="background:var(--bg-surface); padding:16px; border-radius:var(--radius-sm); margin-bottom:20px; font-size:0.875rem;">
        <strong style="color:#fff; display:block; margin-bottom:4px;">📍 <?php _e('street_address'); ?>:</strong>
        <div><?php echo htmlspecialchars($found_order['customer_name']); ?> — <?php echo htmlspecialchars($found_order['shipping_city']); ?></div>
        <div style="color:var(--text-muted);"><?php echo htmlspecialchars($found_order['shipping_address']); ?></div>
      </div>

      <!-- Items List -->
      <h4 style="font-size:1rem; font-weight:800; margin-bottom:12px;"><?php echo current_lang() === 'ar' ? 'المنتجات في هذا الطلب:' : 'Items in this order:'; ?></h4>
      <div style="display:flex; flex-direction:column; gap:10px;">
        <?php foreach ($order_items as $oi): ?>
          <div style="display:flex; justify-content:space-between; align-items:center; padding:10px; background:var(--bg-surface); border-radius:6px; font-size:0.875rem;">
            <div>
              <strong style="color:#fff;"><?php echo htmlspecialchars($oi['product_name']); ?></strong>
              <span style="color:var(--text-dim); margin-inline-start:8px;">x<?php echo $oi['quantity']; ?></span>
            </div>
            <div style="font-weight:700; color:var(--primary);"><?php echo format_price($oi['subtotal']); ?></div>
          </div>
        <?php endforeach; ?>
      </div>

      <!-- Total -->
      <div style="margin-top:20px; padding-top:14px; border-top:1px solid var(--border-color); display:flex; justify-content:space-between; align-items:center;">
        <span style="font-weight:700;"><?php _e('total'); ?>:</span>
        <span style="font-size:1.3rem; font-weight:900; color:var(--primary);"><?php echo format_price($found_order['grand_total']); ?></span>
      </div>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
