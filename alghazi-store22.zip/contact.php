<?php
/**
 * AL GHAZI Phone Store - Contact Us Page
 * متجر الغزي للهواتف الذكية - صفحة اتصل بنا
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

$pdo = get_db();

$page_title = 'اتصل بنا';
$active_nav = 'contact';

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token';
    } else {
        $name = clean_input($_POST['name'] ?? '');
        $email = clean_input($_POST['email'] ?? '');
        $phone = clean_input($_POST['phone'] ?? '');
        $subject = clean_input($_POST['subject'] ?? '');
        $message = clean_input($_POST['message'] ?? '');

        if (empty($name) || empty($email) || empty($subject) || empty($message)) {
            $error = current_lang() === 'ar' ? 'يرجى ملء كافة الحقول الإلزامية' : 'Please fill all required fields';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = current_lang() === 'ar' ? 'البريد الإلكتروني غير صالح' : 'Invalid email address';
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO contact_messages (name, email, phone, subject, message)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->execute([$name, $email, $phone, $subject, $message]);
            $success = true;
            set_flash('success', __('message_sent'));
            header("Location: contact.php");
            exit;
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div style="margin: 30px 0 60px;">
  <div class="section-header">
    <div>
      <h1 class="section-title">💬 <?php _e('contact_heading'); ?></h1>
      <p class="section-subtitle"><?php _e('contact_subheading'); ?></p>
    </div>
  </div>

  <div class="cart-layout">
    <!-- Contact Form Column -->
    <div class="cart-table-card">
      <h3 style="font-size:1.2rem; font-weight:800; margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:12px;">
        ✉️ <?php echo current_lang() === 'ar' ? 'أرسل لنا استفسارك أو اقتراحك' : 'Send Us an Inquiry or Feedback'; ?>
      </h3>

      <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
      <?php endif; ?>

      <form action="contact.php" method="POST">
        <?php echo csrf_field(); ?>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
          <div class="form-group">
            <label class="form-label"><?php _e('full_name'); ?> *</label>
            <input type="text" name="name" class="form-control" required placeholder="سعد القحطاني" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
          </div>
          <div class="form-group">
            <label class="form-label"><?php _e('email_address'); ?> *</label>
            <input type="email" name="email" class="form-control" required placeholder="saad@example.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
          <div class="form-group">
            <label class="form-label"><?php _e('phone_number'); ?></label>
            <input type="tel" name="phone" class="form-control" placeholder="+966 50 XXX XXXX" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
          </div>
          <div class="form-group">
            <label class="form-label"><?php _e('subject'); ?> *</label>
            <input type="text" name="subject" class="form-control" required placeholder="<?php echo current_lang() === 'ar' ? 'استفسار عن طلب / صيانة / أسعار' : 'Inquiry about order / service / pricing'; ?>" value="<?php echo htmlspecialchars($_POST['subject'] ?? ''); ?>">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label"><?php _e('message'); ?> *</label>
          <textarea name="message" class="form-control" rows="5" required placeholder="<?php echo current_lang() === 'ar' ? 'اكتب تفاصيل رسالتك أو استفسارك هنا...' : 'Write the details of your inquiry here...'; ?>"><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea>
        </div>

        <button type="submit" class="btn-primary" style="padding:14px; font-size:1rem;">
          📤 <?php _e('send_message'); ?>
        </button>
      </form>
    </div>

    <!-- Store Info & Working Hours Column -->
    <div class="summary-card">
      <h3 style="font-size:1.2rem; font-weight:800; margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:12px;">
        🏢 <?php _e('store_location'); ?>
      </h3>

      <div style="display:flex; flex-direction:column; gap:20px; font-size:0.9rem; line-height:1.7;">
        <div>
          <strong style="color:var(--primary); display:block; margin-bottom:4px;">📍 <?php echo current_lang() === 'ar' ? 'العنوان الرئيسي' : 'Main Showroom'; ?>:</strong>
          <p style="color:var(--text-muted);"><?php echo htmlspecialchars(get_setting('store_address_' . current_lang(), get_setting('store_address_ar'))); ?></p>
        </div>

        <div>
          <strong style="color:var(--primary); display:block; margin-bottom:4px;">📞 <?php echo current_lang() === 'ar' ? 'أرقام الاتصال وخدمة العملاء' : 'Customer Care Contacts'; ?>:</strong>
          <p style="color:var(--text-muted);">
            <?php echo htmlspecialchars(get_setting('store_phone')); ?><br>
            واتساب: <?php echo htmlspecialchars(get_setting('store_whatsapp')); ?>
          </p>
        </div>

        <div>
          <strong style="color:var(--primary); display:block; margin-bottom:4px;">✉️ <?php echo current_lang() === 'ar' ? 'البريد الإلكتروني الرسمي' : 'Official Support Email'; ?>:</strong>
          <p style="color:var(--text-muted);"><?php echo htmlspecialchars(get_setting('store_email')); ?></p>
        </div>

        <div>
          <strong style="color:var(--primary); display:block; margin-bottom:4px;">⏰ <?php echo current_lang() === 'ar' ? 'مواعيد العمل الرسمية' : 'Working Hours'; ?>:</strong>
          <p style="color:var(--text-muted);"><?php _e('working_hours'); ?></p>
        </div>

        <div style="background:var(--bg-surface); padding:16px; border-radius:var(--radius-sm); border:1px solid var(--border-color); text-align:center; margin-top:10px;">
          <div style="font-weight:700; color:#fff; margin-bottom:8px;">💬 <?php echo current_lang() === 'ar' ? 'تواصل فوري عبر واتساب' : 'Instant WhatsApp Chat'; ?></div>
          <a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', get_setting('store_whatsapp', '966501234567')); ?>" 
             class="btn-sm btn-primary-sm" style="background:#25D366; color:#fff; text-decoration:none; padding:8px 18px;" target="_blank">
            فتح محادثة واتساب
          </a>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
