<?php
/**
 * AL GHAZI Phone Store - Products Catalog Page
 * متجر الغزي للهواتف الذكية - صفحة المنتجات والكتالوج مع الفلاتر
 */

$page_title = 'جميع المنتجات';
$active_nav = 'products';

// Check category slug in query
$current_category_slug = $_GET['category'] ?? '';
if ($current_category_slug === 'phones') {
    $page_title = 'الهواتف الذكية';
    $active_nav = 'phones';
} elseif ($current_category_slug === 'headphones') {
    $page_title = 'السماعات والصوتيات';
    $active_nav = 'headphones';
} elseif ($current_category_slug === 'accessories') {
    $page_title = 'الإكسسوارات والشواحن';
    $active_nav = 'accessories';
} elseif ($current_category_slug === 'smartwatches') {
    $page_title = 'الساعات الذكية';
    $active_nav = 'smartwatches';
}

require_once __DIR__ . '/includes/header.php';
$pdo = get_db();
$menu_categories = $pdo->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order ASC")->fetchAll();

// Prepare Filters
$where_clauses = ["1=1"];
$params = [];

// 1. Search Query
$search_query = trim($_GET['q'] ?? '');
if (!empty($search_query)) {
    $where_clauses[] = "(p.name_ar LIKE ? OR p.name_en LIKE ? OR p.brand LIKE ? OR p.description_ar LIKE ? OR p.description_en LIKE ?)";
    $term = "%{$search_query}%";
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

// 2. Category Filter
if (!empty($current_category_slug)) {
    $where_clauses[] = "c.slug = ?";
    $params[] = $current_category_slug;
}

// 3. Brand Filter
$selected_brand = trim($_GET['brand'] ?? '');
if (!empty($selected_brand)) {
    $where_clauses[] = "p.brand = ?";
    $params[] = $selected_brand;
}

// 4. Special Collections / Filter Tag
$filter_tag = trim($_GET['filter'] ?? '');
if ($filter_tag === 'deals') {
    $where_clauses[] = "p.discount_price IS NOT NULL AND p.discount_price < p.price";
} elseif ($filter_tag === 'bestseller') {
    $where_clauses[] = "p.is_bestseller = 1";
} elseif ($filter_tag === 'new') {
    $where_clauses[] = "p.is_new = 1";
}

// 5. Price Range
$min_price = isset($_GET['min_price']) && is_numeric($_GET['min_price']) ? (float)$_GET['min_price'] : 0;
$max_price = isset($_GET['max_price']) && is_numeric($_GET['max_price']) ? (float)$_GET['max_price'] : 0;

if ($min_price > 0) {
    $where_clauses[] = "COALESCE(p.discount_price, p.price) >= ?";
    $params[] = $min_price;
}
if ($max_price > 0) {
    $where_clauses[] = "COALESCE(p.discount_price, p.price) <= ?";
    $params[] = $max_price;
}

// 6. Sorting Order
$sort = $_GET['sort'] ?? 'default';
$order_by = "p.id DESC";
if ($sort === 'price_asc') {
    $order_by = "COALESCE(p.discount_price, p.price) ASC";
} elseif ($sort === 'price_desc') {
    $order_by = "COALESCE(p.discount_price, p.price) DESC";
} elseif ($sort === 'newest') {
    $order_by = "p.created_at DESC";
} elseif ($sort === 'rating') {
    $order_by = "p.rating DESC";
}

// Execute Query
$where_sql = implode(' AND ', $where_clauses);
$sql = "
    SELECT p.*, c.name_ar as cat_name_ar, c.name_en as cat_name_en, c.slug as cat_slug 
    FROM products p
    JOIN categories c ON p.category_id = c.id
    WHERE {$where_sql}
    ORDER BY {$order_by}
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$catalog_products = $stmt->fetchAll();

// Fetch distinct brands for sidebar
$brands_list = $pdo->query("SELECT DISTINCT brand FROM products ORDER BY brand ASC")->fetchAll(PDO::FETCH_COLUMN);
?>

<div class="catalog-layout">
  <!-- Filter Sidebar -->
  <aside class="catalog-sidebar">
    <div class="sidebar-title">
      <span>⚙️ <?php _e('filters'); ?></span>
      <a href="products.php" style="font-size:0.75rem; color:var(--primary); font-weight:700;"><?php _e('reset_filters'); ?></a>
    </div>

    <form action="products.php" method="GET" id="filterForm">
      <?php if (!empty($search_query)): ?>
        <input type="hidden" name="q" value="<?php echo htmlspecialchars($search_query); ?>">
      <?php endif; ?>

      <!-- Category Filter -->
      <div class="filter-group">
        <label class="filter-label">📁 <?php _e('category'); ?></label>
        <ul class="filter-list">
          <li class="filter-item">
            <label>
              <input type="radio" name="category" value="" <?php echo empty($current_category_slug) ? 'checked' : ''; ?> onchange="this.form.submit()">
              <span><?php _e('all_categories'); ?></span>
            </label>
          </li>
          <?php foreach ($menu_categories as $mc): ?>
            <li class="filter-item">
              <label>
                <input type="radio" name="category" value="<?php echo htmlspecialchars($mc['slug']); ?>" 
                       <?php echo $current_category_slug === $mc['slug'] ? 'checked' : ''; ?> onchange="this.form.submit()">
                <span><?php echo htmlspecialchars(get_localized($mc, 'name')); ?></span>
              </label>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>

      <!-- Brand Filter -->
      <div class="filter-group">
        <label class="filter-label">🏷️ <?php _e('brands'); ?></label>
        <ul class="filter-list">
          <li class="filter-item">
            <label>
              <input type="radio" name="brand" value="" <?php echo empty($selected_brand) ? 'checked' : ''; ?> onchange="this.form.submit()">
              <span><?php _e('all_brands'); ?></span>
            </label>
          </li>
          <?php foreach ($brands_list as $b): ?>
            <li class="filter-item">
              <label>
                <input type="radio" name="brand" value="<?php echo htmlspecialchars($b); ?>" 
                       <?php echo $selected_brand === $b ? 'checked' : ''; ?> onchange="this.form.submit()">
                <span><?php echo htmlspecialchars($b); ?></span>
              </label>
            </li>
          <?php endforeach; ?>
        </ul>
      </div>

      <!-- Price Range Filter -->
      <div class="filter-group">
        <label class="filter-label">💰 <?php _e('price_range'); ?></label>
        <div style="display:flex; gap:10px; margin-bottom:12px;">
          <input type="number" name="min_price" class="form-control" placeholder="Min $" value="<?php echo $min_price ?: ''; ?>" style="padding:6px 10px;">
          <input type="number" name="max_price" class="form-control" placeholder="Max $" value="<?php echo $max_price ?: ''; ?>" style="padding:6px 10px;">
        </div>
        <button type="submit" class="btn-primary" style="padding:8px 14px; font-size:0.85rem;">
          <?php _e('apply_filters'); ?>
        </button>
      </div>
    </form>
  </aside>

  <!-- Products Main Content -->
  <section class="catalog-main">
    <!-- Toolbar -->
    <div class="catalog-toolbar">
      <div class="toolbar-info">
        <strong><?php echo count($catalog_products); ?></strong> <?php _e('products_found'); ?>
        <?php if (!empty($search_query)): ?>
          (<?php echo current_lang() === 'ar' ? 'بحث عن: ' : 'Search: '; ?> "<em><?php echo htmlspecialchars($search_query); ?></em>")
        <?php endif; ?>
      </div>

      <div class="toolbar-sort">
        <label for="sortSelect" style="font-size:0.85rem; color:var(--text-muted);"><?php _e('sort_by'); ?>:</label>
        <select id="sortSelect" class="sort-select" onchange="location = this.value;">
          <?php
          function build_sort_url($s) {
              $params = $_GET;
              $params['sort'] = $s;
              return 'products.php?' . http_build_query($params);
          }
          ?>
          <option value="<?php echo build_sort_url('default'); ?>" <?php echo $sort === 'default' ? 'selected' : ''; ?>><?php _e('sort_default'); ?></option>
          <option value="<?php echo build_sort_url('price_asc'); ?>" <?php echo $sort === 'price_asc' ? 'selected' : ''; ?>><?php _e('sort_price_low'); ?></option>
          <option value="<?php echo build_sort_url('price_desc'); ?>" <?php echo $sort === 'price_desc' ? 'selected' : ''; ?>><?php _e('sort_price_high'); ?></option>
          <option value="<?php echo build_sort_url('newest'); ?>" <?php echo $sort === 'newest' ? 'selected' : ''; ?>><?php _e('sort_newest'); ?></option>
          <option value="<?php echo build_sort_url('rating'); ?>" <?php echo $sort === 'rating' ? 'selected' : ''; ?>><?php _e('sort_rating'); ?></option>
        </select>
      </div>
    </div>

    <!-- Products Grid -->
    <?php if (empty($catalog_products)): ?>
      <div style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius-md); padding:60px 30px; text-align:center;">
        <div style="font-size:3rem; margin-bottom:15px;">🔍</div>
        <h3 style="font-size:1.3rem; margin-bottom:10px;"><?php _e('no_products_found'); ?></h3>
        <p style="color:var(--text-muted); margin-bottom:20px;"><?php echo current_lang() === 'ar' ? 'جرب البحث بكلمات أخرى أو قم بإلغاء الفلاتر المحددة.' : 'Try adjusting your filters or search keywords.'; ?></p>
        <a href="products.php" class="btn-primary" style="display:inline-flex; width:auto;"><?php _e('view_all'); ?></a>
      </div>
    <?php else: ?>
      <div class="products-grid">
        <?php foreach ($catalog_products as $p): ?>
          <?php include __DIR__ . '/includes/product-card.php'; ?>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </section>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
