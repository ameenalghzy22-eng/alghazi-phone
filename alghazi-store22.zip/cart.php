<?php
/**
 * AL GHAZI Phone Store - Shopping Cart Page
 * متجر الغزي للهواتف الذكية - صفحة سلة المشتريات
 */

$page_title = 'سلة المشتريات';
$active_nav = 'cart';
require_once __DIR__ . '/includes/header.php';
$pdo = get_db();

// Handle synchronous form actions (fallback)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $pid = (int)($_POST['product_id'] ?? 0);
        $qty = max(1, (int)($_POST['quantity'] ?? 1));
        if ($pid > 0) {
            add_to_cart($pid, $qty);
            set_flash('success', current_lang() === 'ar' ? 'تمت إضافة المنتج إلى السلة بنجاح!' : 'Product added to cart!');
            header("Location: cart.php");
            exit;
        }
    } elseif ($action === 'update') {
        if (isset($_POST['quantities']) && is_array($_POST['quantities'])) {
            foreach ($_POST['quantities'] as $pid => $qty) {
                update_cart_quantity((int)$pid, (int)$qty);
            }
            set_flash('success', current_lang() === 'ar' ? 'تم تحديث سلة التسوق بنجاح!' : 'Cart updated successfully!');
            header("Location: cart.php");
            exit;
        }
    } elseif ($action === 'apply_coupon') {
        $code = strtoupper(trim($_POST['coupon_code'] ?? ''));
        if (!empty($code)) {
            $stmt_c = $pdo->prepare("SELECT * FROM coupons WHERE code = ? AND is_active = 1");
            $stmt_c->execute([$code]);
            $coupon = $stmt_c->fetch();
            if ($coupon) {
                $_SESSION['coupon'] = [
                    'code' => $coupon['code'],
                    'discount_type' => $coupon['discount_type'],
                    'discount_val' => (float)$coupon['discount_val'],
                    'min_order' => (float)$coupon['min_order']
                ];
                set_flash('success', __('coupon_applied'));
            } else {
                set_flash('danger', __('coupon_invalid'));
            }
        }
        header("Location: cart.php");
        exit;
    } elseif ($action === 'remove_coupon') {
        unset($_SESSION['coupon']);
        set_flash('info', current_lang() === 'ar' ? 'تمت إزالة كود الخصم.' : 'Coupon removed.');
        header("Location: cart.php");
        exit;
    }
}

// Handle GET remove item
if (isset($_GET['remove'])) {
    $remove_id = (int)$_GET['remove'];
    remove_from_cart($remove_id);
    set_flash('info', current_lang() === 'ar' ? 'تم حذف المنتج من السلة.' : 'Item removed from cart.');
    header("Location: cart.php");
    exit;
}

// Handle GET clear cart
if (isset($_GET['clear'])) {
    clear_cart();
    set_flash('info', current_lang() === 'ar' ? 'تم إفراغ سلة المشتريات بالكامل.' : 'Cart cleared.');
    header("Location: cart.php");
    exit;
}

// Fetch Cart Details
$cart_data = get_cart_items_details($pdo);
$items = $cart_data['items'];
$subtotal = $cart_data['subtotal'];
$discount = calculate_discount_amount($subtotal);
$shipping = calculate_shipping_fee($subtotal - $discount);
$grand_total = max(0, ($subtotal - $discount) + $shipping);

$free_shipping_min = (float)get_setting('free_shipping_min', 250);
$diff_free = $free_shipping_min - $subtotal;
?>

<button onclick="history.length > 1 ? history.back() : window.location.href='products.php'" class="btn-back">
  ⬅️ <?php echo current_lang() === 'ar' ? 'رجوع للتسوق' : 'Back to Shopping'; ?>
</button>

<div class="section-header" style="margin-top: 5px;">
  <h1 class="section-title">🛒 <?php _e('shopping_cart'); ?></h1>
  <?php if (!empty($items)): ?>
    <a href="cart.php?clear=1" class="btn-remove" onclick="return confirm('<?php echo current_lang() === 'ar' ? 'هل تريد بالتأكيد إفراغ السلة؟' : 'Are you sure you want to clear your cart?'; ?>');">
      🗑️ <?php _e('clear_cart'); ?>
    </a>
  <?php endif; ?>
</div>

<?php if (empty($items)): ?>
  <!-- Empty Cart State -->
  <div style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius-md); padding:80px 20px; text-align:center; margin:30px 0 60px;">
    <div style="font-size:4rem; margin-bottom:15px;">🛍️</div>
    <h2 style="font-size:1.6rem; margin-bottom:12px;"><?php _e('cart_empty'); ?></h2>
    <p style="color:var(--text-muted); max-width:450px; margin:0 auto 25px; line-height:1.6;">
      <?php _e('cart_empty_desc'); ?>
    </p>
    <a href="products.php" class="btn-primary" style="display:inline-flex; width:auto; padding:12px 28px;">
      📲 <?php _e('continue_shopping'); ?>
    </a>
  </div>
<?php else: ?>
  <!-- Cart Items & Summary Grid -->
  <div class="cart-layout">
    <!-- Items Table Column -->
    <div class="cart-table-card">
      <!-- Free Shipping Tracker -->
      <div style="background:var(--bg-surface); border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:12px 18px; margin-bottom:20px; font-size:0.875rem;">
        <?php if ($diff_free <= 0): ?>
          <span style="color:var(--success); font-weight:700;">🎉 <?php echo current_lang() === 'ar' ? 'تهانينا! طلبيتك مؤهلة للشحن المجاني السريع!' : 'Congratulations! Your order qualifies for free express delivery!'; ?></span>
        <?php else: ?>
          <span>🚚 <?php echo current_lang() === 'ar' ? "أضف بقيمة <strong>" . format_price($diff_free) . "</strong> إضافية للحصول على شحن مجاني!" : "Add <strong>" . format_price($diff_free) . "</strong> more to get free express delivery!"; ?></span>
        <?php endif; ?>
      </div>

      <form action="cart.php" method="POST">
        <input type="hidden" name="action" value="update">
        <table class="cart-table">
          <thead>
            <tr>
              <th><?php _e('product'); ?></th>
              <th><?php _e('price'); ?></th>
              <th><?php _e('quantity'); ?></th>
              <th><?php _e('subtotal'); ?></th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($items as $item): ?>
              <?php 
                $prod = $item['product'];
                $p_name = get_localized($prod, 'name');
                $img = 'assets/images/products/' . htmlspecialchars($prod['main_image']);
                if (!file_exists(__DIR__ . '/' . $img)) {
                    $img = 'uploads/products/' . htmlspecialchars($prod['main_image']);
                }
              ?>
              <tr>
                <td>
                  <div class="cart-item-info">
                    <img src="<?php echo $img; ?>" alt="<?php echo htmlspecialchars($p_name); ?>" class="cart-item-img">
                    <div>
                      <div style="font-size:0.75rem; color:var(--primary); font-weight:700; text-transform:uppercase;"><?php echo htmlspecialchars($prod['brand']); ?></div>
                      <a href="product-details.php?id=<?php echo $prod['id']; ?>" style="font-weight:700; font-size:0.95rem;">
                        <?php echo htmlspecialchars($p_name); ?>
                      </a>
                    </div>
                  </div>
                </td>
                <td style="font-weight:700;">
                  <?php echo format_price($item['unit_price']); ?>
                </td>
                <td>
                  <input type="number" name="quantities[<?php echo $prod['id']; ?>]" value="<?php echo $item['quantity']; ?>" min="1" max="<?php echo max(1, $prod['stock']); ?>"
                         class="form-control" style="width:70px; text-align:center; padding:6px;">
                </td>
                <td style="font-weight:800; color:var(--primary);">
                  <?php echo format_price($item['line_total']); ?>
                </td>
                <td>
                  <a href="cart.php?remove=<?php echo $prod['id']; ?>" class="btn-remove" title="<?php _e('remove'); ?>">✕</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>

        <div style="margin-top:20px; display:flex; justify-content:space-between; align-items:center;">
          <a href="products.php" style="font-size:0.875rem; color:var(--text-muted);">
            &larr; <?php _e('continue_shopping'); ?>
          </a>
          <button type="submit" class="btn-sm btn-secondary-sm" style="padding:10px 18px;">
            🔄 <?php echo current_lang() === 'ar' ? 'تحديث السلة' : 'Update Cart'; ?>
          </button>
        </div>
      </form>
    </div>

    <!-- Order Summary Column -->
    <div class="summary-card">
      <h3 style="font-size:1.25rem; font-weight:800; margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:12px;">
        <?php _e('order_summary'); ?>
      </h3>

      <!-- Subtotal -->
      <div class="summary-row">
        <span><?php _e('subtotal'); ?>:</span>
        <strong style="color:#fff;"><?php echo format_price($subtotal); ?></strong>
      </div>

      <!-- Coupon Row -->
      <?php if ($discount > 0): ?>
        <div class="summary-row" style="color:var(--success);">
          <span><?php _e('discount'); ?> (<?php echo htmlspecialchars($_SESSION['coupon']['code']); ?>):</span>
          <strong>-<?php echo format_price($discount); ?></strong>
        </div>
      <?php endif; ?>

      <!-- Shipping -->
      <div class="summary-row">
        <span><?php _e('shipping'); ?>:</span>
        <strong>
          <?php echo $shipping == 0 ? '<span style="color:var(--success);">' . __('free') . '</span>' : format_price($shipping); ?>
        </strong>
      </div>

      <!-- Coupon Apply Form -->
      <div style="margin: 20px 0; border-top:1px solid rgba(255,255,255,0.06); padding-top:16px;">
        <label style="font-size:0.825rem; font-weight:700; color:var(--text-muted); margin-bottom:8px; display:block;">
          <?php _e('have_coupon'); ?>
        </label>
        <?php if (isset($_SESSION['coupon'])): ?>
          <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(16,185,129,0.1); border:1px solid var(--success); padding:8px 12px; border-radius:var(--radius-sm); font-size:0.85rem;">
            <span>🎟️ <strong><?php echo htmlspecialchars($_SESSION['coupon']['code']); ?></strong></span>
            <form action="cart.php" method="POST" style="margin:0;">
              <input type="hidden" name="action" value="remove_coupon">
              <button type="submit" style="background:transparent; border:none; color:var(--danger); cursor:pointer; font-weight:700;">✕</button>
            </form>
          </div>
        <?php else: ?>
          <form action="cart.php" method="POST" class="coupon-form">
            <input type="hidden" name="action" value="apply_coupon">
            <input type="text" name="coupon_code" placeholder="GHAZI10" class="coupon-input" required>
            <button type="submit" class="btn-sm btn-secondary-sm" style="padding:8px 14px;">
              <?php _e('apply_coupon'); ?>
            </button>
          </form>
          <span style="font-size:0.75rem; color:var(--text-dim);">
            <?php echo current_lang() === 'ar' ? 'كوبونات تجريبية متاحة: GHAZI10 (خصم 10%) أو WELCOME20' : 'Try sample coupons: GHAZI10 (10% off) or WELCOME20'; ?>
          </span>
        <?php endif; ?>
      </div>

      <!-- Grand Total -->
      <div class="summary-row total">
        <span><?php _e('total'); ?>:</span>
        <span style="color:var(--primary);"><?php echo format_price($grand_total); ?></span>
      </div>

      <!-- Checkout Button -->
      <div style="margin-top:24px;">
        <a href="checkout.php" class="btn-primary" style="padding:14px; font-size:1.05rem;">
          💳 <?php _e('proceed_to_checkout'); ?>
        </a>
      </div>
    </div>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
