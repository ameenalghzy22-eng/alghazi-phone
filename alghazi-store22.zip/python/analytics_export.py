#!/usr/bin/env python3
"""
AL GHAZI Store - Analytics & Reporting Service (Python)
Generates business intelligence summaries and CSV export reports for orders and inventory.
"""
import os
import sys
import sqlite3
import csv
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "database", "database.sqlite")
REPORTS_DIR = os.path.join(BASE_DIR, "reports")
os.makedirs(REPORTS_DIR, exist_ok=True)

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def print_summary():
    conn = get_connection()
    c = conn.cursor()

    # Sales & Orders metrics
    c.execute("SELECT COUNT(*) AS total_orders, COALESCE(SUM(grand_total), 0) AS total_revenue FROM orders WHERE status != 'cancelled'")
    row = c.fetchone()
    total_orders = row["total_orders"]
    total_revenue = row["total_revenue"]
    aov = (total_revenue / total_orders) if total_orders > 0 else 0

    # Products count & Low stock
    c.execute("SELECT COUNT(*) AS total_prods, SUM(CASE WHEN stock <= 5 THEN 1 ELSE 0 END) AS low_stock FROM products")
    prow = c.fetchone()
    total_products = prow["total_prods"]
    low_stock = prow["low_stock"] or 0

    # Users count
    c.execute("SELECT COUNT(*) AS total_users FROM users WHERE role = 'customer'")
    total_customers = c.fetchone()["total_users"]

    print("\n" + "=" * 60)
    print("      AL GHAZI STORE — BUSINESS ANALYTICS REPORT")
    print("      تقرير إحصائيات متجر الغزي للهواتف الذكية")
    print("=" * 60)
    print(f"Generated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Total Revenue (الإيرادات الإجمالية):    ${total_revenue:,.2f}")
    print(f"Total Orders (إجمالي الطلبات):          {total_orders}")
    print(f"Average Order Value (متوسط قيمة الطلب): ${aov:,.2f}")
    print(f"Total Products (إجمالي المنتجات):       {total_products}")
    print(f"Total Customers (إجمالي العملاء):       {total_customers}")
    print(f"Low Stock Alerts (منتجات منخفضة المخزون): {low_stock}")
    print("-" * 60)

    # Top selling products
    print("Top Selling Products (المنتجات الأكثر مبيعاً):")
    c.execute("""
        SELECT product_name, SUM(quantity) as units_sold, SUM(subtotal) as sales_val
        FROM order_items
        GROUP BY product_id
        ORDER BY units_sold DESC
        LIMIT 5
    """)
    top_items = c.fetchall()
    if top_items:
        for idx, item in enumerate(top_items, 1):
            print(f"  {idx}. {item['product_name'][:40]} | Units: {item['units_sold']} | Sales: ${item['sales_val']:,.2f}")
    else:
        print("  No sales recorded yet.")

    print("=" * 60 + "\n")
    conn.close()

def export_sales_csv():
    conn = get_connection()
    c = conn.cursor()
    filename = f"sales_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    filepath = os.path.join(REPORTS_DIR, filename)

    c.execute("""
        SELECT order_number, customer_name, customer_email, customer_phone,
               shipping_city, payment_method, subtotal, shipping_cost, discount_amount,
               grand_total, status, created_at
        FROM orders
        ORDER BY created_at DESC
    """)
    rows = c.fetchall()

    with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow([
            "Order Number", "Customer Name", "Email", "Phone",
            "City", "Payment Method", "Subtotal ($)", "Shipping ($)", "Discount ($)",
            "Grand Total ($)", "Status", "Date"
        ])
        for r in rows:
            writer.writerow([
                r["order_number"], r["customer_name"], r["customer_email"], r["customer_phone"],
                r["shipping_city"], r["payment_method"], f"{r['subtotal']:.2f}", f"{r['shipping_cost']:.2f}",
                f"{r['discount_amount']:.2f}", f"{r['grand_total']:.2f}", r["status"], r["created_at"]
            ])

    conn.close()
    print(f"Sales report exported successfully to: {filepath}")
    return filepath

def export_inventory_csv():
    conn = get_connection()
    c = conn.cursor()
    filename = f"inventory_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    filepath = os.path.join(REPORTS_DIR, filename)

    c.execute("""
        SELECT p.id, p.name_ar, p.name_en, p.brand, c.name_en as category,
               p.price, p.discount_price, p.stock, p.rating
        FROM products p
        JOIN categories c ON p.category_id = c.id
        ORDER BY p.stock ASC
    """)
    rows = c.fetchall()

    with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f)
        writer.writerow([
            "ID", "Product Name (AR)", "Product Name (EN)", "Brand", "Category",
            "Price ($)", "Discount Price ($)", "Stock Quantity", "Rating"
        ])
        for r in rows:
            writer.writerow([
                r["id"], r["name_ar"], r["name_en"], r["brand"], r["category"],
                f"{r['price']:.2f}", f"{r['discount_price']:.2f}" if r['discount_price'] else "N/A",
                r["stock"], r["rating"]
            ])

    conn.close()
    print(f"Inventory report exported successfully to: {filepath}")
    return filepath

if __name__ == "__main__":
    action = sys.argv[1] if len(sys.argv) > 1 else "summary"
    if action == "sales":
        export_sales_csv()
    elif action == "inventory":
        export_inventory_csv()
    elif action == "all":
        print_summary()
        export_sales_csv()
        export_inventory_csv()
    else:
        print_summary()
