#!/usr/bin/env python3
"""
AL GHAZI Store - Image & SVG Generator
Generates high quality SVG mockups for phone products, banners, and logos.
"""
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMG_DIR = os.path.join(BASE_DIR, "assets", "images")
PROD_IMG_DIR = os.path.join(IMG_DIR, "products")
UPLOAD_PROD_DIR = os.path.join(BASE_DIR, "uploads", "products")

os.makedirs(IMG_DIR, exist_ok=True)
os.makedirs(PROD_IMG_DIR, exist_ok=True)
os.makedirs(UPLOAD_PROD_DIR, exist_ok=True)

def create_logo_svg():
    svg = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 80" width="320" height="80">
  <defs>
    <linearGradient id="logoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#00E5FF"/>
      <stop offset="100%" stop-color="#3A86FF"/>
    </linearGradient>
    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="3" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
  </defs>
  
  <!-- Icon: Modern Phone with Hexagon Shield -->
  <g transform="translate(10, 10)">
    <rect x="5" y="5" width="46" height="54" rx="10" fill="url(#logoGrad)" filter="url(#glow)"/>
    <rect x="7" y="7" width="42" height="50" rx="8" fill="#0B132B"/>
    <!-- Phone Screen -->
    <rect x="11" y="11" width="34" height="42" rx="5" fill="#1C2541"/>
    <!-- Screen Notch/Speaker -->
    <line x1="23" y1="14" x2="33" y2="14" stroke="#00E5FF" stroke-width="2" stroke-linecap="round"/>
    <!-- Screen Dynamic Island / Wave -->
    <path d="M 16 35 Q 28 20 40 35" fill="none" stroke="url(#logoGrad)" stroke-width="2.5" stroke-linecap="round"/>
    <circle cx="28" cy="46" r="2.5" fill="#00E5FF"/>
  </g>

  <!-- Typography -->
  <text x="75" y="38" font-family="'Segoe UI', 'Tajawal', Cairo, sans-serif" font-weight="900" font-size="26" fill="#FFFFFF" letter-spacing="1.5">
    AL GHAZI
  </text>
  <text x="76" y="58" font-family="'Segoe UI', 'Tajawal', Cairo, sans-serif" font-weight="600" font-size="14" fill="#00E5FF" letter-spacing="0.5">
    متجر الغزي للهواتف الذكية
  </text>
</svg>'''
    with open(os.path.join(IMG_DIR, "logo.svg"), "w", encoding="utf-8") as f:
        f.write(svg)

def create_banner_svg(filename, title_ar, title_en, subtitle_ar, subtitle_en, bg_color1, bg_color2, accent):
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 450" width="1200" height="450">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="{bg_color1}"/>
      <stop offset="60%" stop-color="{bg_color2}"/>
      <stop offset="100%" stop-color="#070b19"/>
    </linearGradient>
    <linearGradient id="accentGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="{accent}"/>
      <stop offset="100%" stop-color="#3A86FF"/>
    </linearGradient>
    <filter id="cardGlow">
      <feDropShadow dx="0" dy="15" stdDeviation="25" flood-color="{accent}" flood-opacity="0.3"/>
    </filter>
  </defs>

  <!-- Background -->
  <rect width="1200" height="450" fill="url(#bg)"/>

  <!-- Cybernetic Grid & Decorative Circles -->
  <g opacity="0.08" stroke="#FFFFFF" stroke-width="1">
    <line x1="0" y1="90" x2="1200" y2="90" />
    <line x1="0" y1="180" x2="1200" y2="180" />
    <line x1="0" y1="270" x2="1200" y2="270" />
    <line x1="0" y1="360" x2="1200" y2="360" />
    <line x1="200" y1="0" x2="200" y2="450" />
    <line x1="400" y1="0" x2="400" y2="450" />
    <line x1="600" y1="0" x2="600" y2="450" />
    <line x1="800" y1="0" x2="800" y2="450" />
    <line x1="1000" y1="0" x2="1000" y2="450" />
  </g>
  <circle cx="950" cy="225" r="240" fill="{accent}" opacity="0.12" filter="blur(60px)"/>
  <circle cx="150" cy="80" r="120" fill="#3A86FF" opacity="0.1" filter="blur(40px)"/>

  <!-- Graphic Phone Mockup -->
  <g transform="translate(850, 60)" filter="url(#cardGlow)">
    <!-- Phone Body -->
    <rect x="0" y="0" width="180" height="330" rx="32" fill="#1C2541" stroke="{accent}" stroke-width="4"/>
    <!-- Screen Inner -->
    <rect x="8" y="8" width="164" height="314" rx="26" fill="#0B132B"/>
    <!-- Screen Content Gradient -->
    <rect x="14" y="14" width="152" height="302" rx="22" fill="url(#bg)" opacity="0.9"/>
    <!-- Dynamic Island -->
    <rect x="65" y="24" width="50" height="14" rx="7" fill="#000000"/>
    <circle cx="76" cy="31" r="3" fill="#00E5FF"/>
    <!-- Sleek visual art inside phone -->
    <circle cx="90" cy="150" r="45" fill="none" stroke="url(#accentGrad)" stroke-width="3"/>
    <polygon points="90,120 120,175 60,175" fill="none" stroke="{accent}" stroke-width="2"/>
    <text x="90" y="235" font-family="'Segoe UI', sans-serif" font-weight="800" font-size="14" fill="#FFFFFF" text-anchor="middle">AL GHAZI</text>
    <text x="90" y="255" font-family="'Segoe UI', sans-serif" font-weight="600" font-size="11" fill="{accent}" text-anchor="middle">5G FLAGSHIP</text>
  </g>

  <!-- Left Accent / Overlapping mini phone -->
  <g transform="translate(740, 110)" opacity="0.85">
    <rect x="0" y="0" width="150" height="270" rx="24" fill="#141E33" stroke="#3A86FF" stroke-width="2"/>
    <rect x="6" y="6" width="138" height="258" rx="20" fill="#0B132B"/>
    <rect x="55" y="16" width="40" height="10" rx="5" fill="#000000"/>
    <text x="75" y="140" font-family="'Segoe UI', sans-serif" font-weight="700" font-size="12" fill="#8892B0" text-anchor="middle">OFFICIAL</text>
    <text x="75" y="160" font-family="'Segoe UI', sans-serif" font-weight="800" font-size="14" fill="#00E5FF" text-anchor="middle">WARRANTY</text>
  </g>

  <!-- Text / Content -->
  <g transform="translate(90, 120)">
    <rect x="0" y="0" width="160" height="32" rx="16" fill="{accent}" fill-opacity="0.2"/>
    <text x="80" y="21" font-family="'Segoe UI', Cairo, sans-serif" font-weight="700" font-size="13" fill="{accent}" text-anchor="middle">
      {subtitle_ar} • {subtitle_en}
    </text>

    <text x="0" y="85" font-family="'Segoe UI', Cairo, sans-serif" font-weight="900" font-size="46" fill="#FFFFFF">
      {title_ar}
    </text>
    <text x="0" y="135" font-family="'Segoe UI', sans-serif" font-weight="800" font-size="32" fill="url(#accentGrad)">
      {title_en}
    </text>
    <text x="0" y="180" font-family="'Segoe UI', Cairo, sans-serif" font-weight="500" font-size="18" fill="#A0AEC0">
      أحدث الهواتف الذكية الأصلية 100% مع ضمان رسمي وتوصيل فوري لجميع المدن
    </text>
  </g>
</svg>'''
    with open(os.path.join(IMG_DIR, filename), "w", encoding="utf-8") as f:
        f.write(svg)

def create_product_svg(filename, brand, model_name, category_type, color_hex, secondary_hex):
    """
    Creates realistic SVG images for phones, accessories, headphones
    """
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" width="500" height="500">
  <defs>
    <linearGradient id="deviceGrad_{filename}" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="{color_hex}"/>
      <stop offset="100%" stop-color="{secondary_hex}"/>
    </linearGradient>
    <linearGradient id="screenGrad" x1="0%" y1="0%" x2="50%" y2="100%">
      <stop offset="0%" stop-color="#141E33"/>
      <stop offset="100%" stop-color="#0B132B"/>
    </linearGradient>
    <radialGradient id="bgGlow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="{color_hex}" stop-opacity="0.15"/>
      <stop offset="100%" stop-color="#0B132B" stop-opacity="0"/>
    </radialGradient>
    <filter id="shadow">
      <feDropShadow dx="0" dy="18" stdDeviation="20" flood-color="#000000" flood-opacity="0.45"/>
    </filter>
  </defs>

  <!-- Background Canvas -->
  <rect width="500" height="500" fill="#0C1427" rx="16"/>
  <circle cx="250" cy="240" r="180" fill="url(#bgGlow)"/>

  <!-- Category Specific Illustration -->
'''

    if category_type == 'phone':
        svg += f'''
  <!-- Smartphone Vector -->
  <g transform="translate(145, 60)" filter="url(#shadow)">
    <!-- Phone Outer Shell -->
    <rect x="0" y="0" width="210" height="380" rx="36" fill="url(#deviceGrad_{filename})" stroke="#3A4D6B" stroke-width="2.5"/>
    <!-- Phone Bezel / Glass -->
    <rect x="8" y="8" width="194" height="364" rx="30" fill="#050811"/>
    <!-- Active Screen -->
    <rect x="14" y="14" width="182" height="352" rx="26" fill="url(#screenGrad)"/>
    
    <!-- Dynamic Island / Punch hole -->
    <rect x="76" y="24" width="58" height="15" rx="7.5" fill="#000000"/>
    <circle cx="88" cy="31.5" r="3.5" fill="#00E5FF"/>
    
    <!-- Modern Wallpaper Visuals -->
    <circle cx="105" cy="180" r="55" fill="none" stroke="{color_hex}" stroke-width="3" stroke-dasharray="8 4"/>
    <circle cx="105" cy="180" r="35" fill="{color_hex}" fill-opacity="0.2"/>
    <path d="M 40 270 Q 105 190 170 270" fill="none" stroke="url(#deviceGrad_{filename})" stroke-width="4" stroke-linecap="round"/>
    
    <!-- Bottom Home Bar -->
    <line x1="75" y1="352" x2="135" y2="352" stroke="#FFFFFF" stroke-opacity="0.6" stroke-width="3" stroke-linecap="round"/>
    
    <!-- Screen Branding -->
    <text x="105" y="140" font-family="'Segoe UI', sans-serif" font-weight="800" font-size="14" fill="#FFFFFF" text-anchor="middle" letter-spacing="1">{brand.upper()}</text>
    <text x="105" y="225" font-family="'Segoe UI', sans-serif" font-weight="600" font-size="12" fill="{color_hex}" text-anchor="middle">5G ULTRA</text>
  </g>
'''
    elif category_type == 'headphone':
        svg += f'''
  <!-- Headphone Vector -->
  <g transform="translate(130, 80)" filter="url(#shadow)">
    <!-- Headband Arch -->
    <path d="M 40 170 C 40 50, 200 50, 200 170" fill="none" stroke="url(#deviceGrad_{filename})" stroke-width="16" stroke-linecap="round"/>
    <!-- Soft Headband Cushion -->
    <path d="M 60 140 C 60 75, 180 75, 180 140" fill="none" stroke="#243048" stroke-width="8" stroke-linecap="round"/>
    
    <!-- Left Ear Cup -->
    <g transform="translate(15, 150)">
      <rect x="0" y="0" width="50" height="90" rx="25" fill="url(#deviceGrad_{filename})"/>
      <rect x="25" y="8" width="28" height="74" rx="14" fill="#141E33"/>
      <circle cx="25" cy="45" r="14" fill="#0B132B"/>
    </g>

    <!-- Right Ear Cup -->
    <g transform="translate(175, 150)">
      <rect x="0" y="0" width="50" height="90" rx="25" fill="url(#deviceGrad_{filename})"/>
      <rect x="-3" y="8" width="28" height="74" rx="14" fill="#141E33"/>
      <circle cx="25" cy="45" r="14" fill="#0B132B"/>
    </g>

    <!-- Sound waves -->
    <path d="M 0 195 Q -20 195 -20 195" stroke="{color_hex}" stroke-width="3" stroke-linecap="round"/>
    <path d="M 240 195 Q 260 195 260 195" stroke="{color_hex}" stroke-width="3" stroke-linecap="round"/>
    <text x="120" y="290" font-family="'Segoe UI', sans-serif" font-weight="700" font-size="13" fill="#FFFFFF" text-anchor="middle">HI-RES AUDIO</text>
  </g>
'''
    elif category_type == 'earbuds':
        svg += f'''
  <!-- Earbuds & Case Vector -->
  <g transform="translate(130, 90)" filter="url(#shadow)">
    <!-- Charging Case -->
    <rect x="40" y="100" width="160" height="130" rx="40" fill="url(#deviceGrad_{filename})" stroke="#3A4D6B" stroke-width="2"/>
    <!-- Case Seam / Lid Line -->
    <line x1="40" y1="140" x2="200" y2="140" stroke="#050811" stroke-width="3"/>
    <!-- LED Indicator -->
    <circle cx="120" cy="170" r="4" fill="#00E5FF"/>
    
    <!-- Left Earbud (Floating) -->
    <g transform="translate(45, 10)">
      <circle cx="25" cy="25" r="22" fill="url(#deviceGrad_{filename})"/>
      <rect x="20" y="35" width="10" height="40" rx="5" fill="url(#deviceGrad_{filename})"/>
      <circle cx="25" cy="25" r="12" fill="#141E33"/>
    </g>

    <!-- Right Earbud (Floating) -->
    <g transform="translate(150, 10)">
      <circle cx="25" cy="25" r="22" fill="url(#deviceGrad_{filename})"/>
      <rect x="20" y="35" width="10" height="40" rx="5" fill="url(#deviceGrad_{filename})"/>
      <circle cx="25" cy="25" r="12" fill="#141E33"/>
    </g>
    
    <text x="120" y="275" font-family="'Segoe UI', sans-serif" font-weight="700" font-size="13" fill="#FFFFFF" text-anchor="middle">ACTIVE NOISE CANCEL</text>
  </g>
'''
    elif category_type == 'accessory':
        svg += f'''
  <!-- Charger / Accessory Vector -->
  <g transform="translate(140, 90)" filter="url(#shadow)">
    <!-- Fast Charger Brick -->
    <rect x="35" y="50" width="150" height="170" rx="24" fill="url(#deviceGrad_{filename})" stroke="#3A4D6B" stroke-width="2"/>
    <!-- USB-C Ports -->
    <rect x="75" y="85" width="70" height="16" rx="8" fill="#0B132B" stroke="#00E5FF" stroke-width="1.5"/>
    <rect x="75" y="120" width="70" height="16" rx="8" fill="#0B132B" stroke="#00E5FF" stroke-width="1.5"/>
    <rect x="75" y="155" width="70" height="16" rx="8" fill="#0B132B" stroke="#3A86FF" stroke-width="1.5"/>
    <!-- Power pins -->
    <rect x="80" y="220" width="15" height="45" rx="3" fill="#718096"/>
    <rect x="125" y="220" width="15" height="45" rx="3" fill="#718096"/>
    <!-- Text -->
    <text x="110" y="40" font-family="'Segoe UI', sans-serif" font-weight="800" font-size="16" fill="#00E5FF" text-anchor="middle">GaN 65W FAST</text>
  </g>
'''
    elif category_type == 'smartwatch':
        svg += f'''
  <!-- Smartwatch Vector -->
  <g transform="translate(150, 70)" filter="url(#shadow)">
    <!-- Watch Straps -->
    <rect x="60" y="0" width="80" height="90" rx="12" fill="#1C2541"/>
    <rect x="60" y="270" width="80" height="90" rx="12" fill="#1C2541"/>
    <!-- Watch Body -->
    <rect x="25" y="70" width="150" height="180" rx="38" fill="url(#deviceGrad_{filename})" stroke="#3A4D6B" stroke-width="3"/>
    <!-- Watch Screen -->
    <rect x="37" y="82" width="126" height="156" rx="28" fill="#050811"/>
    <!-- Screen Dial -->
    <circle cx="100" cy="160" r="50" fill="none" stroke="{color_hex}" stroke-width="4" stroke-dasharray="20 10"/>
    <text x="100" y="155" font-family="'Segoe UI', sans-serif" font-weight="900" font-size="24" fill="#FFFFFF" text-anchor="middle">10:45</text>
    <text x="100" y="180" font-family="'Segoe UI', sans-serif" font-weight="700" font-size="12" fill="#00E5FF" text-anchor="middle">AM • 128 BPM</text>
    <!-- Digital Crown Button -->
    <rect x="175" y="110" width="10" height="34" rx="4" fill="#718096"/>
  </g>
'''

    # Product label overlay
    svg += f'''
  <!-- Brand & Model Tag -->
  <g transform="translate(250, 465)">
    <text x="0" y="0" font-family="'Segoe UI', 'Tajawal', Cairo, sans-serif" font-weight="700" font-size="14" fill="#A0AEC0" text-anchor="middle">
      {brand} — {model_name}
    </text>
  </g>
</svg>'''

    # Save to both assets/images/products and uploads/products
    path1 = os.path.join(PROD_IMG_DIR, filename)
    path2 = os.path.join(UPLOAD_PROD_DIR, filename)
    with open(path1, "w", encoding="utf-8") as f:
        f.write(svg)
    with open(path2, "w", encoding="utf-8") as f:
        f.write(svg)

def main():
    print("Generating store branding and SVGs...")
    create_logo_svg()
    create_banner_svg("banner1.svg", "أقوى عروض الهواتف الذكية", "FLAGSHIP PHONES 2026", "خصومات حصرية", "EXCLUSIVE OFFERS", "#0B132B", "#1C2541", "#00E5FF")
    create_banner_svg("banner2.svg", "سماعات وإكسسوارات أصلية", "PREMIUM AUDIO & TECH", "أداء لا يضاهى", "PURE SOUND", "#0F172A", "#1E293B", "#F59E0B")
    
    # Generate 16 realistic tech products
    products = [
        ("iphone-16-pro-max.svg", "Apple", "iPhone 16 Pro Max", "phone", "#E0D7C6", "#61574C"),
        ("iphone-16.svg", "Apple", "iPhone 16", "phone", "#00E5FF", "#0A4E7A"),
        ("samsung-s25-ultra.svg", "Samsung", "Galaxy S25 Ultra", "phone", "#506266", "#1F282A"),
        ("samsung-z-fold6.svg", "Samsung", "Galaxy Z Fold 6", "phone", "#3A86FF", "#18325E"),
        ("xiaomi-14-ultra.svg", "Xiaomi", "Xiaomi 14 Ultra", "phone", "#F59E0B", "#78350F"),
        ("pixel-9-pro.svg", "Google", "Pixel 9 Pro XL", "phone", "#10B981", "#064E3B"),
        ("honor-magic-6-pro.svg", "Honor", "Honor Magic 6 Pro", "phone", "#8B5CF6", "#4C1D95"),
        ("oneplus-12.svg", "OnePlus", "OnePlus 12", "phone", "#EF4444", "#7F1D1D"),
        ("airpods-pro-2.svg", "Apple", "AirPods Pro 2 USB-C", "earbuds", "#F8FAFC", "#94A3B8"),
        ("galaxy-buds-3-pro.svg", "Samsung", "Galaxy Buds 3 Pro", "earbuds", "#CBD5E1", "#475569"),
        ("sony-wh1000xm5.svg", "Sony", "WH-1000XM5 ANC", "headphone", "#334155", "#0F172A"),
        ("bose-quietcomfort-ultra.svg", "Bose", "QuietComfort Ultra", "headphone", "#64748B", "#1E293B"),
        ("apple-watch-ultra-2.svg", "Apple", "Apple Watch Ultra 2", "smartwatch", "#F97316", "#7C2D12"),
        ("galaxy-watch-ultra.svg", "Samsung", "Galaxy Watch Ultra", "smartwatch", "#06B6D4", "#0E7490"),
        ("anker-65w-gan.svg", "Anker", "735 GaN 65W Charger", "accessory", "#38BDF8", "#0369A1"),
        ("magsafe-powerbank.svg", "Anker", "MagSafe Wireless 10000mAh", "accessory", "#A855F7", "#581C87"),
    ]

    for fname, brand, model_name, cat, c1, c2 in products:
        create_product_svg(fname, brand, model_name, cat, c1, c2)

    print(f"Successfully generated logo, 2 banners, and {len(products)} product SVGs!")

if __name__ == "__main__":
    main()
