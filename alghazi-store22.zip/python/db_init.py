#!/usr/bin/env python3
"""
AL GHAZI Store - Database Initializer & Seeder
Creates tables and seeds realistic phones, accessories, categories, users, coupons, and orders.
"""
import os
import sqlite3
import json

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "database", "database.sqlite")
SCHEMA_PATH = os.path.join(BASE_DIR, "database", "schema.sql")

# Password hashes generated with PHP's PASSWORD_BCRYPT
ADMIN_HASH = "$2y$12$LLBXIFLS8179RNosojbB.OWdDtBXFAQIPKc0Ekh5eo5DDfaLNyU5u" # admin123
USER_HASH  = "$2y$12$tPTaKzxIrdusEIZGjQWFte09QXcvp1Z8YzyxesyopLDGvyR7Wfx6u" # user123

def init_database():
    print(f"Connecting to database: {DB_PATH}")
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON;")
    cursor = conn.cursor()

    # Read and execute schema
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        schema_sql = f.read()
    cursor.executescript(schema_sql)
    print("Schema executed successfully.")

    # 1. Seed Users
    users_data = [
        ("مدير المتجر - الغزي", "admin@alghazi.com", ADMIN_HASH, "+966501234567", "admin", "الرياض", "شارع العليا العام"),
        ("أحمد عبد الله", "customer@alghazi.com", USER_HASH, "+966559876543", "customer", "جدة", "حي الروضة"),
        ("سارة المنصور", "sara@gmail.com", USER_HASH, "+966541122334", "customer", "الدمام", "حي الشاطئ"),
    ]
    cursor.executemany("""
        INSERT OR IGNORE INTO users (name, email, password_hash, phone, role, city, address)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, users_data)

    # 2. Seed Categories
    categories = [
        ("phones", "الهواتف الذكية", "Smartphones", "أحدث وأقوى الهواتف الذكية من كبرى الشركات العالمية", "Latest flagship and budget smartphones", "phone", 1),
        ("headphones", "السماعات والصوتيات", "Headphones & Audio", "سماعات لاسلكية وعازلة للضوضاء بأعلى نقاء صوتي", "Wireless and noise-cancelling headphones and earbuds", "headphones", 2),
        ("accessories", "الإكسسوارات والشواحن", "Accessories & Chargers", "شواحن سريعة وبنوك طاقة وأغطية حماية أصلية", "Fast chargers, powerbanks, and authentic protective cases", "charging-station", 3),
        ("smartwatches", "الساعات الذكية", "Smartwatches", "ساعات ذكية رياضية وأنيقة لمتابعة الصحة والأنشطة", "Smartwatches for fitness tracking and daily productivity", "watch", 4)
    ]
    cursor.executemany("""
        INSERT OR IGNORE INTO categories (slug, name_ar, name_en, description_ar, description_en, icon, sort_order)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, categories)

    # Fetch Category IDs
    cursor.execute("SELECT id, slug FROM categories")
    cat_map = {row[1]: row[0] for row in cursor.fetchall()}

    # 3. Seed Products
    products = [
        # Phones
        (
            cat_map['phones'],
            "iphone-16-pro-max",
            "آبل آيفون 16 برو ماكس - 256 جيجابايت",
            "Apple iPhone 16 Pro Max - 256GB",
            "Apple",
            "أقوى هاتف من آبل بشريحة A18 Pro الجبارة وإطار تيتانيوم متين مع زر التحكم الجديد بالكاميرا وبطارية تدوم طوال اليوم وشاشة Super Retina XDR مقاس 6.9 بوصة.",
            "Apple's flagship phone featuring the blazing fast A18 Pro chip, Grade 5 titanium design, Camera Control button, and a stunning 6.9-inch Super Retina XDR display.",
            1299.00,
            1199.00,
            15,
            4.9,
            88,
            "iphone-16-pro-max.svg",
            json.dumps(["iphone-16-pro-max.svg", "iphone-16.svg"]),
            json.dumps({
                "storage": "256GB / 512GB / 1TB",
                "ram": "8GB Unified",
                "chip": "Apple A18 Pro (3nm)",
                "screen": "6.9-inch OLED ProMotion 120Hz",
                "battery": "4685 mAh, 30W Fast Charge",
                "camera": "48MP Main + 48MP Ultra-wide + 12MP 5x Telephoto",
                "color": "تيتانيوم صحراوي / Desert Titanium",
                "warranty": "سنتان ضمان الوكيل / 2 Years Official Warranty"
            }),
            1, 1, 1
        ),
        (
            cat_map['phones'],
            "iphone-16",
            "آبل آيفون 16 - 128 جيجابايت",
            "Apple iPhone 16 - 128GB",
            "Apple",
            "هاتف آيفون 16 الجديد كلياً مع دعم ميزات ذكاء آبل الاصطناعي وزر الإجراءات وكاميرا متطورة بدقة 48 ميجابكسل وألوان عصرية مبهجة.",
            "The all-new iPhone 16 with Apple Intelligence support, customizable Action button, 48MP Fusion camera and vibrant colors.",
            899.00,
            829.00,
            20,
            4.8,
            64,
            "iphone-16.svg",
            json.dumps(["iphone-16.svg", "iphone-16-pro-max.svg"]),
            json.dumps({
                "storage": "128GB / 256GB",
                "ram": "8GB",
                "chip": "Apple A18",
                "screen": "6.1-inch Super Retina XDR",
                "battery": "3561 mAh, 25W MagSafe",
                "camera": "48MP Dual Camera Fusion",
                "color": "أزرق تيل / Teal Blue",
                "warranty": "سنتان ضمان الوكيل / 2 Years Official Warranty"
            }),
            1, 0, 1
        ),
        (
            cat_map['phones'],
            "samsung-galaxy-s25-ultra",
            "سامسونج جالكسي S25 ألترا - 512 جيجابايت",
            "Samsung Galaxy S25 Ultra - 512GB",
            "Samsung",
            "قمة التقنية مع معالج Snapdragon 8 Elite وقلم S-Pen مدمج وكاميرا بدقة 200 ميجابكسل مع تقريب بصري مذهل وميزات Galaxy AI المتقدمة.",
            "Ultimate flagship power powered by Snapdragon 8 Elite for Galaxy, integrated S-Pen, 200MP camera system and advanced Galaxy AI tools.",
            1349.00,
            1249.00,
            12,
            5.0,
            95,
            "samsung-s25-ultra.svg",
            json.dumps(["samsung-s25-ultra.svg", "samsung-z-fold6.svg"]),
            json.dumps({
                "storage": "512GB",
                "ram": "16GB LPDDR5X",
                "chip": "Snapdragon 8 Elite for Galaxy",
                "screen": "6.8-inch Dynamic AMOLED 2X, 120Hz, 2600 nits",
                "battery": "5000 mAh, 45W Fast Charge",
                "camera": "200MP + 50MP + 50MP + 12MP Quad",
                "color": "رمادي تيتانيوم / Titanium Gray",
                "warranty": "سنتان ضمان سامسونج / 2 Years Samsung Warranty"
            }),
            1, 1, 1
        ),
        (
            cat_map['phones'],
            "samsung-galaxy-z-fold-6",
            "سامسونج جالكسي زد فولد 6 قابل للطي",
            "Samsung Galaxy Z Fold 6 5G",
            "Samsung",
            "شاشة داخلية ضخمة تفتح لتمنحك تجربة حاسوب لوحي مع تصميم أنحف وأخف وزناً ومقاومة للماء ومحرك إنتاجية مدعوم بالذكاء الاصطناعي.",
            "Unfold a tablet-sized experience in a lighter, thinner chassis with IP48 water resistance and Galaxy AI productivity tools.",
            1799.00,
            1649.00,
            8,
            4.7,
            42,
            "samsung-z-fold6.svg",
            json.dumps(["samsung-z-fold6.svg"]),
            json.dumps({
                "storage": "512GB",
                "ram": "12GB",
                "chip": "Snapdragon 8 Gen 3",
                "screen": "7.6-inch Foldable Dynamic AMOLED 2X + 6.3-inch Cover",
                "battery": "4400 mAh, 25W Fast Charging",
                "camera": "50MP Triple ProVisual Engine",
                "color": "فضي كربوني / Silver Shadow",
                "warranty": "سنتان مع تأمين الشاشة / 2 Years + Screen Care"
            }),
            1, 0, 0
        ),
        (
            cat_map['phones'],
            "xiaomi-14-ultra",
            "شاومي 14 ألترا - كاميرا لايكا الاحترافية",
            "Xiaomi 14 Ultra - Leica Quad Camera",
            "Xiaomi",
            "وحش التصوير الفوتوغرافي بمستشعر مقاس 1 بوصة وعدسات لايكا الاحترافية وبطارية عملاقة 5000 مللي أمبير مع شحن خارق 90 واط.",
            "The master of mobile photography featuring a 1-inch sensor, Leica Summilux quad lenses and 90W HyperCharge.",
            1099.00,
            999.00,
            10,
            4.8,
            51,
            "xiaomi-14-ultra.svg",
            json.dumps(["xiaomi-14-ultra.svg"]),
            json.dumps({
                "storage": "512GB",
                "ram": "16GB",
                "chip": "Snapdragon 8 Gen 3",
                "screen": "6.73-inch WQHD+ AMOLED 120Hz",
                "battery": "5000 mAh, 90W Wired + 80W Wireless",
                "camera": "50MP 1-inch LYT-900 + 3x 50MP Leica",
                "color": "أسود جلد فاخر / Black Vegan Leather",
                "warranty": "سنتان ضمان شاومي / 2 Years Official Warranty"
            }),
            0, 1, 0
        ),
        (
            cat_map['phones'],
            "google-pixel-9-pro-xl",
            "جوجل بيكسل 9 برو إكس إل - الذكاء الاصطناعي الأقوى",
            "Google Pixel 9 Pro XL - Gemini AI Built-in",
            "Google",
            "هاتف جوجل الرائد مع معالج Tensor G4 ومساعد Gemini المتطور وكاميرا تلتقط أروع الصور الواقعية وتحديثات أندرويد مضمونة لسبع سنوات.",
            "Google's flagship phone with Google Tensor G4, Gemini AI integrated into everyday tasks, and 7 years of OS updates.",
            1149.00,
            1049.00,
            14,
            4.9,
            39,
            "pixel-9-pro.svg",
            json.dumps(["pixel-9-pro.svg"]),
            json.dumps({
                "storage": "256GB",
                "ram": "16GB",
                "chip": "Google Tensor G4 + Titan M2",
                "screen": "6.8-inch Super Actua LTPO OLED 120Hz",
                "battery": "5060 mAh, 37W Fast Charge",
                "camera": "50MP Octa PD + 48MP Telephoto 5x + 48MP Ultrawide",
                "color": "بورسلين رخامي / Porcelain White",
                "warranty": "سنتان ضمان دولي / 2 Years Warranty"
            }),
            1, 0, 1
        ),
        (
            cat_map['phones'],
            "honor-magic-6-pro",
            "هونر ماجيك 6 برو - بطارية السيليكون الخارقة",
            "Honor Magic 6 Pro - Falcon Camera System",
            "Honor",
            "أقوى زجاج مضاد للكسر وشاشة معتمة لحماية العين وكاميرا بيريسكوب 180 ميجابكسل وبطارية من الجيل الثاني تدوم يومين كاملين.",
            "Breakthrough Silicon-Carbon 5600mAh battery, 180MP Periscope telephoto, and ultra-tough NanoCrystal Shield.",
            999.00,
            899.00,
            15,
            4.7,
            33,
            "honor-magic-6-pro.svg",
            json.dumps(["honor-magic-6-pro.svg"]),
            json.dumps({
                "storage": "512GB",
                "ram": "12GB",
                "chip": "Snapdragon 8 Gen 3",
                "screen": "6.8-inch LTPO 120Hz 5000 nits peak",
                "battery": "5600 mAh, 80W Wired + 66W Wireless",
                "camera": "180MP Periscope + 50MP Falcon + 50MP Wide",
                "color": "أخضر زمردي / Epi Green",
                "warranty": "سنتان ضمان الوكيل / 2 Years Warranty"
            }),
            0, 0, 0
        ),
        (
            cat_map['phones'],
            "oneplus-12",
            "ون بلس 12 - سرعة خارقة وأداء فائق",
            "OnePlus 12 5G - Hasselblad Camera",
            "OnePlus",
            "شاشة 2K فائقة السطوع 4500 شمعة مع كاميرات هاسيلبلاد وشحن صاروخي 100 واط يعبئ البطارية بالكامل في 26 دقيقة فقط.",
            "Flagship smooth experience with Hasselblad 4th Gen camera, 5400mAh battery and blazing 100W SUPERVOOC charging.",
            849.00,
            769.00,
            18,
            4.8,
            47,
            "oneplus-12.svg",
            json.dumps(["oneplus-12.svg"]),
            json.dumps({
                "storage": "256GB / 512GB",
                "ram": "16GB",
                "chip": "Snapdragon 8 Gen 3",
                "screen": "6.82-inch ProXDR 120Hz 4500 nits",
                "battery": "5400 mAh, 100W SuperVOOC",
                "camera": "50MP Sony LYT-808 + 64MP Periscope + 48MP UW",
                "color": "أخضر زمردي / Flowy Emerald",
                "warranty": "سنتان ضمان / 2 Years Warranty"
            }),
            0, 1, 0
        ),

        # Headphones & Audio
        (
            cat_map['headphones'],
            "airpods-pro-2-usb-c",
            "آبل إيربودز برو 2 مع علبة MagSafe USB-C",
            "Apple AirPods Pro 2 - Active Noise Cancellation",
            "Apple",
            "عزل ضوضاء أنشط بمرتين، ميزة الصوت التكيفي ووضع شفافية الصوت وتتبع حركة الرأس ثلاثي الأبعاد مع مقاومة للغبار والماء.",
            "Up to 2x more Active Noise Cancellation, Adaptive Audio, Transparency mode, and USB-C MagSafe charging case.",
            249.00,
            219.00,
            30,
            4.9,
            120,
            "airpods-pro-2.svg",
            json.dumps(["airpods-pro-2.svg"]),
            json.dumps({
                "type": "True Wireless In-Ear",
                "chip": "Apple H2 Headphone Chip",
                "battery": "Up to 30 hours with case",
                "connectivity": "Bluetooth 5.3, USB-C MagSafe",
                "features": "Spatial Audio, Adaptive EQ, Touch Control",
                "warranty": "سنة ضمان آبل / 1 Year Apple Warranty"
            }),
            1, 1, 0
        ),
        (
            cat_map['headphones'],
            "galaxy-buds-3-pro",
            "سامسونج جالكسي بودز 3 برو الذكية",
            "Samsung Galaxy Buds 3 Pro - Hi-Fi Audio",
            "Samsung",
            "تصميم شريطي مضيء جديد كلياً مع صوت Hi-Fi 24-bit نقي وترجمة فورية مباشرة مدعومة بذكاء اصطناعي Galaxy AI وعزل تكيفي ممتاز.",
            "Sleek blade design with LED lights, 24-bit Hi-Fi sound, adaptive ANC, and real-time Interpreter via Galaxy AI.",
            229.00,
            189.00,
            25,
            4.7,
            75,
            "galaxy-buds-3-pro.svg",
            json.dumps(["galaxy-buds-3-pro.svg"]),
            json.dumps({
                "type": "True Wireless Earbuds",
                "battery": "Up to 30 hours playback",
                "connectivity": "Bluetooth 5.4, Auto Switch",
                "water_resistance": "IP57",
                "warranty": "سنة ضمان سامسونج / 1 Year Warranty"
            }),
            0, 1, 1
        ),
        (
            cat_map['headphones'],
            "sony-wh-1000xm5",
            "سوني WH-1000XM5 - ملكة عزل الضوضاء",
            "Sony WH-1000XM5 Wireless Noise Canceling",
            "Sony",
            "أفضل سماعة رأس عازلة للضوضاء في العالم بمعالجين متطورين و8 ميكروفونات ومكالمات فائقة الوضوح وبطارية تدوم حتى 30 ساعة.",
            "Industry-leading noise cancellation with 8 microphones, Auto NC Optimizer, and up to 30 hours of continuous playback.",
            399.00,
            329.00,
            14,
            4.9,
            110,
            "sony-wh1000xm5.svg",
            json.dumps(["sony-wh1000xm5.svg"]),
            json.dumps({
                "type": "Over-Ear Wireless",
                "drivers": "30mm precision carbon fiber",
                "battery": "30 hours with ANC on (Quick charge: 3 min = 3 hrs)",
                "codec": "LDAC, AAC, SBC, Hi-Res Audio Wireless",
                "weight": "250g ultra-lightweight",
                "warranty": "سنتان ضمان سوني / 2 Years Sony Warranty"
            }),
            1, 1, 0
        ),
        (
            cat_map['headphones'],
            "bose-quietcomfort-ultra",
            "بوز كوايت كومفورت ألترا - صوت محيطي غامر",
            "Bose QuietComfort Ultra Headphones",
            "Bose",
            "راحة أسطورية مع تقنية Bose Immersive Audio التي تجعل الصوت واقعياً حولك وتقنية العزل الصوتي الرائدة عالمياً.",
            "World-class noise cancellation, groundbreaking Bose Immersive Audio, and unmatched custom-tuned comfort.",
            429.00,
            379.00,
            10,
            4.8,
            49,
            "bose-quietcomfort-ultra.svg",
            json.dumps(["bose-quietcomfort-ultra.svg"]),
            json.dumps({
                "type": "Over-Ear Wireless",
                "battery": "24 hours (18 hours with Immersive Audio)",
                "modes": "Quiet Mode, Aware Mode, Immersion Mode",
                "warranty": "سنة ضمان الوكيل / 1 Year Warranty"
            }),
            0, 0, 0
        ),

        # Smartwatches
        (
            cat_map['smartwatches'],
            "apple-watch-ultra-2",
            "ساعة آبل واتش ألترا 2 - تيتانيوم 49 مم",
            "Apple Watch Ultra 2 - Titanium 49mm GPS + Cellular",
            "Apple",
            "أقوى وأصلب ساعة من آبل بهيكل تيتانيوم مقاوم للصدمات، شاشة ساطعة 3000 شمعة، وتتبع دقيق للملاحة والغوص حتى عمق 40 متراً.",
            "The ultimate sports and adventure watch featuring a rugged 49mm titanium case, 3000-nit display and dual-frequency GPS.",
            799.00,
            749.00,
            11,
            4.9,
            68,
            "apple-watch-ultra-2.svg",
            json.dumps(["apple-watch-ultra-2.svg"]),
            json.dumps({
                "case": "49mm Grade 5 Titanium",
                "display": "Always-On Retina 3000 nits",
                "battery": "Up to 36 hours (72 hours Low Power)",
                "water_resistance": "100m, Dive ready to 40m (EN13319)",
                "sensors": "ECG, Blood Oxygen, Temperature, Depth Gauge",
                "warranty": "سنتان ضمان آبل / 2 Years Apple Warranty"
            }),
            1, 1, 1
        ),
        (
            cat_map['smartwatches'],
            "samsung-galaxy-watch-ultra",
            "سامسونج جالكسي واتش ألترا 47 مم",
            "Samsung Galaxy Watch Ultra 47mm LTE",
            "Samsung",
            "ساعة مصممة للمغامرات القاسية مع معالج 3 نانومتر فائق السرعة وزر سريع قابل للتخصيص ومقاومة درجات الحرارة والضغط العالي.",
            "Built to push boundaries with a cushion titanium design, 3nm processor, multi-sports tracking and Siren alert.",
            649.00,
            579.00,
            13,
            4.8,
            53,
            "galaxy-watch-ultra.svg",
            json.dumps(["galaxy-watch-ultra.svg"]),
            json.dumps({
                "case": "47mm Grade 4 Titanium",
                "screen": "1.5-inch Super AMOLED Sapphire Crystal",
                "battery": "Up to 100 hours in Power Saving",
                "durability": "10ATM + IP68, MIL-STD-810H",
                "warranty": "سنتان ضمان سامسونج / 2 Years Warranty"
            }),
            0, 1, 1
        ),

        # Accessories
        (
            cat_map['accessories'],
            "anker-735-gan-65w-charger",
            "شاحن أنكر 735 بتقنية جان 65 واط ثلاثي المنافذ",
            "Anker 735 GaN 65W Fast Charger (Nano II)",
            "Anker",
            "اشحن هاتفك وجهازك اللوحي وحاسوبك المحمول في نفس الوقت بحجم أصغر بنسبة 59% مع تقنية PowerIQ 4.0 لتوزيع الطاقة الذكي.",
            "High-speed charging for 3 devices simultaneously with 2 USB-C ports and 1 USB-A port in a compact travel-friendly size.",
            59.00,
            45.00,
            45,
            4.9,
            140,
            "anker-65w-gan.svg",
            json.dumps(["anker-65w-gan.svg"]),
            json.dumps({
                "output": "65W Max GaN Technology",
                "ports": "2x USB-C + 1x USB-A",
                "compatibility": "iPhone, Samsung, MacBook, iPad, Android",
                "safety": "ActiveShield 2.0 temperature sensor",
                "warranty": "سنتان ضمان أنكر الأصلي / 2 Years Anker Warranty"
            }),
            1, 1, 0
        ),
        (
            cat_map['accessories'],
            "anker-magsafe-wireless-powerbank-10k",
            "بنك طاقة أنكر لاسلكي ماج سيف 10,000 مللي أمبير",
            "Anker MagSafe Wireless Power Bank 10,000mAh",
            "Anker",
            "يثبت مغناطيسياً بقوة خلف هاتف آيفون لشحن لاسلكي مريح مع شاشة ديجيتال ذكية تعرض نسبة البطارية والوقت المتبقي بدقة.",
            "Snap-and-charge convenience with strong 10N magnetic hold, smart digital display, and 20W two-way fast USB-C port.",
            69.00,
            55.00,
            38,
            4.8,
            92,
            "magsafe-powerbank.svg",
            json.dumps(["magsafe-powerbank.svg"]),
            json.dumps({
                "capacity": "10,000 mAh High-Density",
                "wireless_charge": "7.5W / 15W Qi-certified",
                "wired_charge": "20W USB-C Power Delivery",
                "display": "Smart Digital LCD status screen",
                "warranty": "سنتان ضمان / 2 Years Warranty"
            }),
            1, 0, 0
        )
    ]

    cursor.executemany("""
        INSERT OR IGNORE INTO products (
            category_id, slug, name_ar, name_en, brand,
            description_ar, description_en, price, discount_price, stock,
            rating, rating_count, main_image, gallery_images, specs_json,
            is_featured, is_bestseller, is_new
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, products)

    # 4. Seed Discount Coupons
    coupons = [
        ("GHAZI10", "percent", 10.0, 50.0, "2027-12-31", 1),
        ("WELCOME20", "percent", 20.0, 100.0, "2027-12-31", 1),
        ("SUPER50", "fixed", 50.0, 500.0, "2027-12-31", 1),
    ]
    cursor.executemany("""
        INSERT OR IGNORE INTO coupons (code, discount_type, discount_val, min_order, expiry_date, is_active)
        VALUES (?, ?, ?, ?, ?, ?)
    """, coupons)

    # 5. Seed Store Settings
    settings = [
        ("store_name_ar", "متجر الغزي للهواتف الذكية"),
        ("store_name_en", "AL GHAZI Phone Store"),
        ("store_phone", "+966 50 123 4567"),
        ("store_whatsapp", "+966501234567"),
        ("store_email", "support@alghazi.com"),
        ("store_address_ar", "المملكة العربية السعودية، الرياض، شارع العليا العام، مجمع الغزي للاتصالات"),
        ("store_address_en", "King Fahd & Olaya St, Al Ghazi Telecom Center, Riyadh, Saudi Arabia"),
        ("currency_symbol", "$"),
        ("currency_code", "USD"),
        ("currency_symbol_ar", "دولار"),
        ("shipping_cost", "15.00"),
        ("free_shipping_min", "250.00"),
        ("tax_rate", "0.00")
    ]
    cursor.executemany("""
        INSERT OR IGNORE INTO settings (setting_key, setting_value)
        VALUES (?, ?)
    """, settings)

    # 6. Seed Sample Initial Orders (To populate admin dashboard graphs and orders list)
    sample_orders = [
        ("ORD-2026-9011", 2, "أحمد عبد الله", "customer@alghazi.com", "+966559876543", "جدة", "حي الروضة شارع الأمير سلطان", "cod", 1199.00, 0.0, 119.90, "GHAZI10", 1079.10, "delivered", "يرجى التوصيل بعد العصر"),
        ("ORD-2026-9012", 3, "سارة المنصور", "sara@gmail.com", "+966541122334", "الدمام", "حي الشاطئ فيلا 14", "card", 548.00, 0.0, 0.0, None, 548.00, "shipped", "اتصل قبل الوصول"),
        ("ORD-2026-9013", 2, "أحمد عبد الله", "customer@alghazi.com", "+966559876543", "جدة", "حي الروضة شارع الأمير سلطان", "bank_transfer", 1249.00, 0.0, 0.0, None, 1249.00, "processing", "تم تحويل المبلغ للراجحي"),
        ("ORD-2026-9014", None, "خالد بن فيصل", "khaled.f@hotmail.com", "+966509988776", "الرياض", "حي النخيل الغربي", "cod", 219.00, 15.0, 0.0, None, 234.00, "pending", "طلب جديد كضيف"),
    ]
    cursor.executemany("""
        INSERT OR IGNORE INTO orders (
            order_number, user_id, customer_name, customer_email, customer_phone,
            shipping_city, shipping_address, payment_method, subtotal, shipping_cost,
            discount_amount, coupon_code, grand_total, status, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, sample_orders)

    # Order Items for the sample orders
    cursor.execute("SELECT id, order_number FROM orders")
    ord_map = {row[1]: row[0] for row in cursor.fetchall()}

    order_items = [
        (ord_map["ORD-2026-9011"], 1, "آبل آيفون 16 برو ماكس - 256 جيجابايت", "iphone-16-pro-max.svg", 1199.00, 1, 1199.00),
        (ord_map["ORD-2026-9012"], 11, "سوني WH-1000XM5 - ملكة عزل الضوضاء", "sony-wh1000xm5.svg", 329.00, 1, 329.00),
        (ord_map["ORD-2026-9012"], 9, "آبل إيربودز برو 2 مع علبة MagSafe USB-C", "airpods-pro-2.svg", 219.00, 1, 219.00),
        (ord_map["ORD-2026-9013"], 3, "سامسونج جالكسي S25 ألترا - 512 جيجابايت", "samsung-s25-ultra.svg", 1249.00, 1, 1249.00),
        (ord_map["ORD-2026-9014"], 9, "آبل إيربودز برو 2 مع علبة MagSafe USB-C", "airpods-pro-2.svg", 219.00, 1, 219.00),
    ]
    cursor.executemany("""
        INSERT OR IGNORE INTO order_items (order_id, product_id, product_name, product_image, price, quantity, subtotal)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, order_items)

    # 7. Seed Contact Messages
    messages = [
        ("فيصل الحربي", "faisal@example.com", "+966501112233", "استفسار عن توفر لون التيتانيوم الطبيعي", "السلام عليكم، هل سيتوفر لون التيتانيوم الطبيعي لآيفون 16 برو ماكس قريباً؟ شكراً لكم.", 0),
        ("نورة العتيبي", "noura@example.com", "+966554443322", "سؤال عن الضمان والصيانة", "مرحباً، هل الضمان المشمول مع هواتف سامسونج ساري لدى الوكيل المعتمد في السعودية؟", 1),
    ]
    cursor.executemany("""
        INSERT OR IGNORE INTO contact_messages (name, email, phone, subject, message, is_read)
        VALUES (?, ?, ?, ?, ?, ?)
    """, messages)

    conn.commit()
    conn.close()
    print("Database initialization and seeding completed successfully!")

if __name__ == "__main__":
    init_database()
