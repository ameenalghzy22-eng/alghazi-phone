<?php
/**
 * AL GHAZI Store - Reusable Product Card Component
 * متجر الغزي للهواتف الذكية - بطاقة المنتج الموحدة
 */

if (!isset($p)) return;

$p_name = get_localized($p, 'name');
$p_price = (float)$p['price'];
$p_discount = ($p['discount_price'] !== null && $p['discount_price'] > 0) ? (float)$p['discount_price'] : null;
$effective_price = $p_discount ?: $p_price;
$has_discount = $p_discount && $p_discount < $p_price;
$discount_percent = $has_discount ? round((($p_price - $p_discount) / $p_price) * 100) : 0;

$img_src = 'assets/images/products/' . htmlspecialchars($p['main_image']);
if (!file_exists(__DIR__ . '/../' . $img_src)) {
    $img_src = 'uploads/products/' . htmlspecialchars($p['main_image']);
}
?>

<div class="product-card">
  <!-- Badges -->
  <div class="product-badges">
    <?php if ($has_discount): ?>
      <span class="badge badge-discount"><?php _e('discount_badge'); ?> <?php echo $discount_percent; ?>%</span>
    <?php endif; ?>
    <?php if (!empty($p['is_new'])): ?>
      <span class="badge badge-new"><?php _e('new_badge'); ?></span>
    <?php endif; ?>
    <?php if (!empty($p['is_bestseller'])): ?>
      <span class="badge badge-bestseller"><?php _e('bestseller_badge'); ?></span>
    <?php endif; ?>
  </div>

  <!-- Thumbnail -->
  <a href="product-details.php?id=<?php echo $p['id']; ?>" class="product-thumb">
    <img src="<?php echo $img_src; ?>" alt="<?php echo htmlspecialchars($p_name); ?>" loading="lazy">
  </a>

  <!-- Content -->
  <div class="product-content">
    <div class="product-brand"><?php echo htmlspecialchars($p['brand']); ?></div>
    <a href="product-details.php?id=<?php echo $p['id']; ?>">
      <h3 class="product-name" title="<?php echo htmlspecialchars($p_name); ?>">
        <?php echo htmlspecialchars($p_name); ?>
      </h3>
    </a>

    <!-- Rating -->
    <div class="product-rating">
      <span>★</span>
      <span style="font-weight:700; color:#fff;"><?php echo number_format($p['rating'], 1); ?></span>
      <span class="count">(<?php echo $p['rating_count']; ?>)</span>
    </div>

    <!-- Pricing Row -->
    <div class="product-price-row">
      <span class="current-price"><?php echo format_price($effective_price); ?></span>
      <?php if ($has_discount): ?>
        <span class="old-price"><?php echo format_price($p_price); ?></span>
      <?php endif; ?>
    </div>

    <!-- Actions -->
    <div class="product-card-actions">
      <?php if ($p['stock'] > 0): ?>
        <button type="button" class="btn-add-cart btn-add-cart-ajax" data-id="<?php echo $p['id']; ?>">
          <span>🛒</span>
          <span><?php _e('add_to_cart'); ?></span>
        </button>
      <?php else: ?>
        <button type="button" class="btn-add-cart" disabled style="opacity:0.5; cursor:not-allowed;">
          <span><?php _e('out_of_stock'); ?></span>
        </button>
      <?php endif; ?>
      <a href="product-details.php?id=<?php echo $p['id']; ?>" class="btn-quick-view" title="<?php _e('view_details'); ?>">
        <span>👁️</span>
      </a>
    </div>
  </div>
</div>
