  </div> <!-- End admin-content -->
</div> <!-- End admin-main -->

<script src="../assets/js/main.js"></script>
<script src="../assets/js/admin.js"></script>
</body>
</html>
