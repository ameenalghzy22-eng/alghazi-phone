  </div> <!-- End container from header -->
</main>

<!-- Main Footer -->
<footer class="main-footer">
  <div class="container">
    <div class="footer-grid">
      <!-- Col 1: About AL GHAZI -->
      <div class="footer-col">
        <img src="assets/images/logo.svg" alt="<?php _e('site_name'); ?>" style="height: 42px; margin-bottom: 16px;">
        <p><?php _e('footer_about'); ?></p>
        <div style="margin-top: 16px; display: flex; gap: 12px; font-size: 1.25rem;">
          <span title="X / Twitter">𝕏</span>
          <span title="Instagram">📸</span>
          <span title="TikTok">🎵</span>
          <span title="Snapchat">👻</span>
        </div>
      </div>

      <!-- Col 2: Quick Links -->
      <div class="footer-col">
        <h4><?php _e('quick_links'); ?></h4>
        <ul class="footer-links">
          <li><a href="index.php"><?php _e('home'); ?></a></li>
          <li><a href="products.php"><?php _e('all_products'); ?></a></li>
          <li><a href="products.php?category=phones"><?php _e('phones'); ?></a></li>
          <li><a href="products.php?category=headphones"><?php _e('headphones'); ?></a></li>
          <li><a href="products.php?category=accessories"><?php _e('accessories'); ?></a></li>
          <li><a href="about.php"><?php _e('about_us'); ?></a></li>
          <li><a href="contact.php"><?php _e('contact_us'); ?></a></li>
        </ul>
      </div>

      <!-- Col 3: Customer Care & Guarantee -->
      <div class="footer-col">
        <h4><?php _e('customer_care'); ?></h4>
        <ul class="footer-links">
          <li><a href="order-tracking.php"><?php _e('order_tracking'); ?></a></li>
          <li><a href="profile.php"><?php _e('my_account'); ?></a></li>
          <li><a href="about.php#warranty"><?php _e('warranty_policy'); ?></a></li>
          <li><a href="about.php#returns"><?php _e('return_policy'); ?></a></li>
          <li><a href="about.php#terms"><?php _e('terms_conditions'); ?></a></li>
          <li><a href="about.php#privacy"><?php _e('privacy_policy'); ?></a></li>
        </ul>
      </div>

      <!-- Col 4: Newsletter & Contact Details -->
      <div class="footer-col">
        <h4><?php _e('newsletter_title'); ?></h4>
        <p><?php _e('newsletter_desc'); ?></p>
        <form onsubmit="event.preventDefault(); showToast('<?php echo current_lang() === 'ar' ? 'شكراً لاشتراكك في النشرة الإخبارية!' : 'Thank you for subscribing!'; ?>', 'success');" style="margin-top: 14px; display: flex; gap: 8px;">
          <input type="email" placeholder="<?php echo current_lang() === 'ar' ? 'بريدك الإلكتروني...' : 'Your email address...'; ?>" required 
                 style="flex:1; background:var(--bg-surface); border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:10px 14px; color:#fff;">
          <button type="submit" class="btn-primary" style="width: auto; padding: 10px 18px; font-size: 0.875rem;">
            <?php _e('subscribe'); ?>
          </button>
        </form>
        <div style="margin-top: 18px; font-size: 0.85rem; color: var(--text-muted); line-height: 1.6;">
          <div>📍 <?php echo htmlspecialchars(get_setting('store_address_' . current_lang(), get_setting('store_address_ar'))); ?></div>
          <div>📞 <?php echo htmlspecialchars(get_setting('store_phone', '+966 50 123 4567')); ?></div>
          <div>✉️ <?php echo htmlspecialchars(get_setting('store_email', 'support@alghazi.com')); ?></div>
        </div>
      </div>
    </div>

    <!-- Bottom Copyright & Badges -->
    <div class="footer-bottom">
      <div>
        <?php _e('all_rights_reserved'); ?> &copy; <?php echo date('Y'); ?>
      </div>
      <div style="display: flex; align-items: center; gap: 12px; font-size: 0.85rem;">
        <span>🔒 <?php _e('secured_payment'); ?>:</span>
        <span style="background:var(--bg-surface); padding:3px 8px; border-radius:4px; font-weight:700;">MADA</span>
        <span style="background:var(--bg-surface); padding:3px 8px; border-radius:4px; font-weight:700;">VISA</span>
        <span style="background:var(--bg-surface); padding:3px 8px; border-radius:4px; font-weight:700;">MasterCard</span>
        <span style="background:var(--bg-surface); padding:3px 8px; border-radius:4px; font-weight:700;">Apple Pay</span>
      </div>
    </div>
  </div>
</footer>

<!-- Mobile Bottom Navigation Bar (App-like experience on phones) -->
<nav class="mobile-bottom-nav">
  <div class="mobile-bottom-nav-inner">
    <a href="index.php" class="mobile-nav-link">
      <span class="nav-icon">🏠</span>
      <span><?php _e('home'); ?></span>
    </a>
    <a href="products.php" class="mobile-nav-link">
      <span class="nav-icon">📱</span>
      <span><?php _e('all_products'); ?></span>
    </a>
    <a href="cart.php" class="mobile-nav-link">
      <span class="nav-icon">🛒</span>
      <span><?php _e('cart'); ?></span>
      <span class="badge-count" style="<?php echo (isset($cart_count) && $cart_count > 0) ? '' : 'display:none;'; ?>">
        <?php echo $cart_count ?? 0; ?>
      </span>
    </a>
    <a href="order-tracking.php" class="mobile-nav-link">
      <span class="nav-icon">📦</span>
      <span><?php _e('order_tracking'); ?></span>
    </a>
    <a href="admin/index.php" class="mobile-nav-link" style="color:var(--primary);">
      <span class="nav-icon">⚙️</span>
      <span>الإدارة</span>
    </a>
  </div>
</nav>

<!-- Floating WhatsApp Support Button -->
<a href="https://wa.me/<?php echo preg_replace('/[^0-9]/', '', get_setting('store_whatsapp', '966501234567')); ?>" 
   class="floating-whatsapp" target="_blank" rel="noopener noreferrer" title="WhatsApp Support">
  💬
</a>

<!-- JavaScript Assets -->
<script src="assets/js/main.js"></script>
<script src="assets/js/cart.js"></script>
</body>
</html>
