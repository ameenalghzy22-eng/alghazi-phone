<?php
/**
 * AL GHAZI Store - Database Connection (SQLite via PDO)
 * متجر الغزي للهواتف الذكية - الاتصال بقاعدة البيانات
 */

// Configure local writable session directory
$session_dir = __DIR__ . '/../database/sessions';
if (!is_dir($session_dir)) {
    @mkdir($session_dir, 0777, true);
}
if (is_dir($session_dir) && is_writable($session_dir)) {
    @session_save_path($session_dir);
}

if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

$db_file = __DIR__ . '/../database/database.sqlite';

try {
    $pdo = new PDO("sqlite:" . $db_file);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec("PRAGMA foreign_keys = ON;");
    $GLOBALS['pdo'] = $pdo;
} catch (PDOException $e) {
    die("Database Connection Error: " . $e->getMessage());
}

function get_db() {
    global $pdo;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) {
        return $GLOBALS['pdo'];
    }
    $db_file = __DIR__ . '/../database/database.sqlite';
    $p = new PDO("sqlite:" . $db_file);
    $p->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $p->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $GLOBALS['pdo'] = $p;
    return $p;
}

/**
 * Helper to fetch all key-value settings into an associative array
 */
function get_all_settings($db = null) {
    static $settings = null;
    if ($settings === null) {
        if (!$db) {
            $db = get_db();
        }
        $stmt = $db->query("SELECT setting_key, setting_value FROM settings");
        $settings = [];
        while ($row = $stmt->fetch()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }
    }
    return $settings;
}

function get_setting($key, $default = '') {
    $settings = get_all_settings();
    return isset($settings[$key]) ? $settings[$key] : $default;
}
