<?php
/**
 * AL GHAZI Store - Authentication & Permissions
 * متجر الغزي للهواتف الذكية - نظام المصادقة والصلاحيات
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function current_user() {
    if (!is_logged_in()) {
        return null;
    }
    return [
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'] ?? '',
        'email' => $_SESSION['user_email'] ?? '',
        'role' => $_SESSION['user_role'] ?? 'customer',
        'phone' => $_SESSION['user_phone'] ?? '',
    ];
}

function is_admin() {
    return is_logged_in() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

function is_staff() {
    return is_logged_in() && isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['admin', 'staff']);
}

function is_pure_staff() {
    return is_logged_in() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'staff';
}

function can_view_financials() {
    return is_admin();
}

function can_manage_settings() {
    return is_admin();
}

function can_delete() {
    return is_admin();
}

function require_admin_or_staff($redirect = '../login.php') {
    if (!is_staff()) {
        set_flash('danger', current_lang() === 'ar' ? 'غير مصرح بالدخول! لوحة التحكم خاصة بالمدير وموظفي المتجر فقط.' : 'Access restricted to Manager and Staff only.');
        header("Location: $redirect");
        exit;
    }
}

function login_user($user) {
    // Regenerate session ID to prevent session fixation
    session_regenerate_id(true);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_role'] = $user['role'];
    $_SESSION['user_phone'] = $user['phone'] ?? '';
}

function logout_user() {
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

function require_login($redirect = 'login.php') {
    if (!is_logged_in()) {
        set_flash('warning', current_lang() === 'ar' ? 'يرجى تسجيل الدخول أولاً للوصول إلى هذه الصفحة.' : 'Please log in first to access this page.');
        header("Location: $redirect");
        exit;
    }
}

function require_admin($redirect = '../login.php') {
    if (!is_admin()) {
        set_flash('danger', current_lang() === 'ar' ? 'غير مصرح لك بالوصول! هذه الصفحة مخصصة لمدير المتجر فقط.' : 'Access denied! This area is restricted to administrators.');
        header("Location: $redirect");
        exit;
    }
}
