<?php
/**
 * AL GHAZI Store - Admin Header & Navigation Component
 * متجر الغزي للهواتف الذكية - رأس وقائمة لوحة التحكم
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

require_admin_or_staff('../login.php');

$pdo = get_db();
$lang = current_lang();
$dir = is_rtl() ? 'rtl' : 'ltr';
$user = current_user();
$is_mgr = is_admin();
$is_emp = is_pure_staff();

// Unread messages count
$stmt_msg = $pdo->query("SELECT COUNT(*) FROM contact_messages WHERE is_read = 0");
$unread_msg_count = (int)$stmt_msg->fetchColumn();

// Pending orders count
$stmt_ord = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'");
$pending_orders_count = (int)$stmt_ord->fetchColumn();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $dir; ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo isset($admin_page_title) ? htmlspecialchars($admin_page_title) . ' | ' . __('admin_panel') : __('admin_panel'); ?></title>
  <link rel="icon" type="image/svg+xml" href="../assets/images/logo.svg">
  <link rel="stylesheet" href="../assets/css/style.css">
  <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="admin-body" dir="<?php echo $dir; ?>">

<!-- Admin Sidebar -->
<aside class="admin-sidebar">
  <div class="admin-brand">
    <img src="../assets/images/logo.svg" alt="<?php _e('site_name'); ?>" style="height: 38px;">
  </div>

  <ul class="admin-nav">
    <li class="admin-nav-item <?php echo (isset($admin_nav) && $admin_nav === 'dashboard') ? 'active' : ''; ?>">
      <a href="index.php">📊 <span><?php _e('admin_dashboard'); ?></span></a>
    </li>
    <li class="admin-nav-item <?php echo (isset($admin_nav) && $admin_nav === 'products') ? 'active' : ''; ?>">
      <a href="products.php">📱 <span><?php _e('manage_products'); ?></span></a>
    </li>
    <li class="admin-nav-item <?php echo (isset($admin_nav) && $admin_nav === 'product_add') ? 'active' : ''; ?>">
      <a href="product-form.php">➕ <span><?php _e('add_product'); ?></span></a>
    </li>
    <li class="admin-nav-item <?php echo (isset($admin_nav) && $admin_nav === 'categories') ? 'active' : ''; ?>">
      <a href="categories.php">📁 <span><?php _e('manage_categories'); ?></span></a>
    </li>
    <li class="admin-nav-item <?php echo (isset($admin_nav) && $admin_nav === 'orders') ? 'active' : ''; ?>">
      <a href="orders.php">
        📦 <span><?php _e('manage_orders'); ?></span>
        <?php if ($pending_orders_count > 0): ?>
          <span class="badge"><?php echo $pending_orders_count; ?></span>
        <?php endif; ?>
      </a>
    </li>
    <li class="admin-nav-item <?php echo (isset($admin_nav) && $admin_nav === 'messages') ? 'active' : ''; ?>">
      <a href="messages.php">
        💬 <span><?php _e('contact_inquiries'); ?></span>
        <?php if ($unread_msg_count > 0): ?>
          <span class="badge"><?php echo $unread_msg_count; ?></span>
        <?php endif; ?>
      </a>
    </li>
    <?php if ($is_mgr): ?>
      <li class="admin-nav-item <?php echo (isset($admin_nav) && $admin_nav === 'users') ? 'active' : ''; ?>">
        <a href="users.php">👥 <span><?php _e('manage_users'); ?></span></a>
      </li>
      <li class="admin-nav-item <?php echo (isset($admin_nav) && $admin_nav === 'reports') ? 'active' : ''; ?>">
        <a href="reports.php">🐍 <span><?php _e('analytics_reports'); ?></span></a>
      </li>
      <li class="admin-nav-item <?php echo (isset($admin_nav) && $admin_nav === 'settings') ? 'active' : ''; ?>">
        <a href="settings.php">⚙️ <span><?php _e('store_settings'); ?></span></a>
      </li>
    <?php endif; ?>
  </ul>

  <div class="admin-sidebar-footer">
    <div style="margin-bottom: 8px;">
      <a href="../index.php" style="color:var(--admin-primary); font-weight:700; display:flex; align-items:center; gap:6px;">
        ⬅️ <?php _e('back_to_store'); ?>
      </a>
    </div>
    <div style="font-size: 0.8rem; font-weight:700; color:#fff;">
      <?php echo htmlspecialchars($user['name']); ?>
    </div>
    <div style="font-size: 0.725rem; color:<?php echo $is_mgr ? 'var(--admin-primary)' : 'var(--admin-warning)'; ?>; font-weight:800;">
      <?php echo $is_mgr ? '👑 مدير المتجر (صلاحية كاملة)' : '👤 موظف (متابعة الطلبات والمخزون)'; ?>
    </div>
  </div>
</aside>

<!-- Admin Main View Area -->
<div class="admin-main">
  <!-- Topbar -->
  <header class="admin-topbar">
    <div style="display:flex; align-items:center; gap:12px;">
      <a href="../index.php" class="btn-sm btn-secondary-sm" style="font-size:0.85rem; padding:6px 12px;">
        ⬅️ المتجر
      </a>
      <div class="admin-topbar-title">
        <?php echo isset($admin_page_title) ? htmlspecialchars($admin_page_title) : __('admin_panel'); ?>
      </div>
    </div>
    <div class="admin-topbar-actions">
      <span class="badge" style="background:<?php echo $is_mgr ? 'var(--admin-primary)' : 'var(--admin-warning)'; ?>; color:#000; font-weight:800; font-size:0.75rem;">
        <?php echo $is_mgr ? 'مدير' : 'موظف'; ?>
      </span>
      <!-- Language Switcher in Admin -->
      <?php if ($lang === 'ar'): ?>
        <a href="?lang=en" class="lang-switch" title="Switch to English">🌐 English</a>
      <?php else: ?>
        <a href="?lang=ar" class="lang-switch" title="التحويل إلى العربية">🌐 العربية</a>
      <?php endif; ?>

      <a href="../logout.php" class="btn-sm btn-secondary-sm" style="text-decoration:none;">
        🚪 <?php _e('logout'); ?>
      </a>
    </div>
  </header>

  <div class="admin-content">
    <?php 
    $flash = get_flash(); 
    if ($flash): 
    ?>
      <div class="alert alert-<?php echo htmlspecialchars($flash['type']); ?>">
        <?php echo htmlspecialchars($flash['message']); ?>
      </div>
    <?php endif; ?>
