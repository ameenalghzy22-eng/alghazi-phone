<?php
/**
 * AL GHAZI Store - Core Functions & Helpers
 * متجر الغزي للهواتف الذكية - الدوال والمساعدات الأساسية
 */

require_once __DIR__ . '/translations.php';

// Handle Language Switch
if (isset($_GET['lang']) && in_array($_GET['lang'], ['ar', 'en'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

function current_lang() {
    return isset($_SESSION['lang']) && $_SESSION['lang'] === 'en' ? 'en' : 'ar';
}

function is_rtl() {
    return current_lang() === 'ar';
}

function __($key) {
    global $translations;
    $lang = current_lang();
    if (isset($translations[$lang][$key])) {
        return $translations[$lang][$key];
    }
    if (isset($translations['en'][$key])) {
        return $translations['en'][$key];
    }
    return $key;
}

function _e($key) {
    echo htmlspecialchars(__($key), ENT_QUOTES, 'UTF-8');
}

function get_localized($array_or_obj, $field) {
    $lang = current_lang();
    $key = $field . '_' . $lang;
    if (is_array($array_or_obj) && !empty($array_or_obj[$key])) {
        return $array_or_obj[$key];
    }
    $fallback = $field . '_ar';
    if (is_array($array_or_obj) && !empty($array_or_obj[$fallback])) {
        return $array_or_obj[$fallback];
    }
    return '';
}

function format_price($amount) {
    $symbol = '$';
    return $symbol . number_format((float)$amount, 2);
}

// Flash Messages
function set_flash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'info', 'warning'
        'message' => $message
    ];
}

function get_flash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

// CSRF Protection
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field() {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token()) . '">';
}

function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Input Sanitization
function clean_input($data) {
    if (is_array($data)) {
        return array_map('clean_input', $data);
    }
    return trim(htmlspecialchars((string)$data, ENT_QUOTES, 'UTF-8'));
}

// Shopping Cart Helpers
function get_cart() {
    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    return $_SESSION['cart'];
}

function get_cart_count() {
    $cart = get_cart();
    $count = 0;
    foreach ($cart as $qty) {
        $count += (int)$qty;
    }
    return $count;
}

function add_to_cart($product_id, $qty = 1) {
    $product_id = (int)$product_id;
    $qty = max(1, (int)$qty);
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id] += $qty;
    } else {
        $_SESSION['cart'][$product_id] = $qty;
    }
}

function update_cart_quantity($product_id, $qty) {
    $product_id = (int)$product_id;
    $qty = (int)$qty;
    if ($qty <= 0) {
        remove_from_cart($product_id);
    } else {
        $_SESSION['cart'][$product_id] = $qty;
    }
}

function remove_from_cart($product_id) {
    $product_id = (int)$product_id;
    if (isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
    }
}

function clear_cart() {
    $_SESSION['cart'] = [];
    unset($_SESSION['coupon']);
}

function get_cart_items_details($pdo) {
    $cart = get_cart();
    $items = [];
    $subtotal = 0;

    if (empty($cart)) {
        return ['items' => [], 'subtotal' => 0];
    }

    $placeholders = implode(',', array_fill(0, count($cart), '?'));
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
    $stmt->execute(array_keys($cart));
    $products = $stmt->fetchAll();

    foreach ($products as $prod) {
        $pid = $prod['id'];
        $qty = $cart[$pid];
        $effective_price = ($prod['discount_price'] !== null && $prod['discount_price'] > 0) ? (float)$prod['discount_price'] : (float)$prod['price'];
        $line_total = $effective_price * $qty;
        $subtotal += $line_total;

        $items[] = [
            'product' => $prod,
            'quantity' => $qty,
            'unit_price' => $effective_price,
            'line_total' => $line_total
        ];
    }

    return ['items' => $items, 'subtotal' => $subtotal];
}

// Shipping and Coupon calculations
function calculate_shipping_fee($subtotal) {
    $free_threshold = (float)get_setting('free_shipping_min', 250);
    $standard_cost = (float)get_setting('shipping_cost', 15);
    if ($subtotal >= $free_threshold || $subtotal == 0) {
        return 0.0;
    }
    return $standard_cost;
}

function calculate_discount_amount($subtotal) {
    if (!isset($_SESSION['coupon'])) {
        return 0.0;
    }
    $coupon = $_SESSION['coupon'];
    if ($subtotal < (float)$coupon['min_order']) {
        return 0.0;
    }
    if ($coupon['discount_type'] === 'percent') {
        return round(($subtotal * (float)$coupon['discount_val']) / 100, 2);
    } else {
        return min((float)$coupon['discount_val'], $subtotal);
    }
}

// File Upload Utility
function upload_product_image($file_input_name) {
    if (!isset($_FILES[$file_input_name]) || $_FILES[$file_input_name]['error'] !== UPLOAD_ERR_OK) {
        return false;
    }

    $file = $_FILES[$file_input_name];
    $max_size = 5 * 1024 * 1024; // 5MB
    if ($file['size'] > $max_size) {
        return false;
    }

    $allowed_extensions = ['jpg', 'jpeg', 'png', 'webp', 'svg'];
    $allowed_mimes = [
        'image/jpeg', 'image/png', 'image/webp',
        'image/svg+xml', 'text/plain', 'text/xml'
    ];

    $filename = $file['name'];
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed_extensions)) {
        return false;
    }

    $new_filename = 'prod_' . bin2hex(random_bytes(8)) . '.' . $ext;
    $target_dir = __DIR__ . '/../uploads/products/';

    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $target_path = $target_dir . $new_filename;
    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        return $new_filename;
    }

    return false;
}
