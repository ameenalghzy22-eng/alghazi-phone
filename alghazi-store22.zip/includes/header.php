<?php
/**
 * AL GHAZI Store - Public Header Component
 * متجر الغزي للهواتف الذكية - رأس الصفحة العام
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

$pdo = get_db();
$lang = current_lang();
$dir = is_rtl() ? 'rtl' : 'ltr';
$cart_count = get_cart_count();
$user = current_user();

// Fetch categories for menu
$menu_categories = $pdo->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $dir; ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' | ' . __('site_name') : __('site_name'); ?></title>
  <meta name="description" content="<?php _e('site_tagline'); ?>">
  <link rel="icon" type="image/svg+xml" href="assets/images/logo.svg">
  <!-- Stylesheets -->
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body dir="<?php echo $dir; ?>">

<!-- Top Announcement Bar -->
<div class="top-bar">
  <div class="container top-bar-inner">
    <div class="top-bar-left">
      <span><?php _e('free_shipping_notice'); ?></span>
    </div>
    <div class="top-bar-right">
      <span><?php _e('customer_service'); ?></span>
      <a href="order-tracking.php"><?php _e('track_order_btn'); ?></a>
      
      <!-- Language Switcher -->
      <?php if ($lang === 'ar'): ?>
        <a href="?lang=en" class="lang-switch" title="Switch to English">
          🌐 <span>English</span>
        </a>
      <?php else: ?>
        <a href="?lang=ar" class="lang-switch" title="التحويل إلى العربية">
          🌐 <span>العربية</span>
        </a>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Main Sticky Header -->
<header class="main-header">
  <div class="container header-inner">
    <!-- Brand Logo -->
    <a href="index.php" class="logo-link">
      <img src="assets/images/logo.svg" alt="<?php _e('site_name'); ?>" class="logo-img">
    </a>

    <!-- Live Search Bar -->
    <div class="header-search">
      <form action="products.php" method="GET">
        <input type="text" name="q" class="search-input" 
               placeholder="<?php _e('search_placeholder'); ?>" 
               value="<?php echo isset($_GET['q']) ? htmlspecialchars($_GET['q']) : ''; ?>" required>
        <button type="submit" class="search-btn">
          <span>🔍</span>
          <span><?php _e('search'); ?></span>
        </button>
      </form>
    </div>

    <!-- Header Actions -->
    <div class="header-actions">
      <!-- User Account Dropdown / Link -->
      <?php if (is_logged_in()): ?>
        <a href="<?php echo is_admin() ? 'admin/index.php' : 'profile.php'; ?>" class="action-btn">
          <span>👤</span>
          <span><?php echo htmlspecialchars(explode(' ', $user['name'])[0]); ?></span>
          <?php if (is_admin()): ?>
            <span style="font-size:0.65rem; background:var(--primary); color:#000; padding:2px 5px; border-radius:4px; font-weight:800;">ADMIN</span>
          <?php endif; ?>
        </a>
        <a href="logout.php" class="action-btn" title="<?php _e('logout'); ?>">
          <span>🚪</span>
        </a>
      <?php else: ?>
        <a href="login.php" class="action-btn">
          <span>🔑</span>
          <span><?php _e('login'); ?></span>
        </a>
      <?php endif; ?>

      <!-- Shopping Cart Button -->
      <a href="cart.php" class="action-btn cart-btn">
        <span>🛒</span>
        <span><?php _e('cart'); ?></span>
        <span class="badge-count" id="cartBadgeCount" style="<?php echo $cart_count > 0 ? '' : 'display:none;'; ?>">
          <?php echo $cart_count; ?>
        </span>
      </a>

      <!-- Mobile Hamburger Button -->
      <button class="mobile-toggle" aria-label="Toggle Navigation">☰</button>
    </div>
  </div>
</header>

<!-- Categories & Links Navigation Bar -->
<nav class="nav-bar">
  <div class="container">
    <ul class="nav-menu">
      <li class="nav-item <?php echo (!isset($active_nav) || $active_nav === 'home') ? 'active' : ''; ?>">
        <a href="index.php">🏠 <?php _e('home'); ?></a>
      </li>
      <li class="nav-item <?php echo (isset($active_nav) && $active_nav === 'products') ? 'active' : ''; ?>">
        <a href="products.php">📱 <?php _e('all_products'); ?></a>
      </li>
      <li class="nav-item <?php echo (isset($active_nav) && $active_nav === 'phones') ? 'active' : ''; ?>">
        <a href="products.php?category=phones">📲 <?php _e('phones'); ?></a>
      </li>
      <li class="nav-item <?php echo (isset($active_nav) && $active_nav === 'headphones') ? 'active' : ''; ?>">
        <a href="products.php?category=headphones">🎧 <?php _e('headphones'); ?></a>
      </li>
      <li class="nav-item <?php echo (isset($active_nav) && $active_nav === 'accessories') ? 'active' : ''; ?>">
        <a href="products.php?category=accessories">⚡ <?php _e('accessories'); ?></a>
      </li>
      <li class="nav-item <?php echo (isset($active_nav) && $active_nav === 'smartwatches') ? 'active' : ''; ?>">
        <a href="products.php?category=smartwatches">⌚ <?php _e('smartwatches'); ?></a>
      </li>
      <li class="nav-item <?php echo (isset($active_nav) && $active_nav === 'about') ? 'active' : ''; ?>">
        <a href="about.php">ℹ️ <?php _e('about_us'); ?></a>
      </li>
      <li class="nav-item <?php echo (isset($active_nav) && $active_nav === 'contact') ? 'active' : ''; ?>">
        <a href="contact.php">💬 <?php _e('contact_us'); ?></a>
      </li>
    </ul>
  </div>
</nav>

<!-- Main Page Container with Flash Alerts -->
<main class="main-content">
  <div class="container" style="padding-top: 15px;">
    <?php 
    $flash = get_flash(); 
    if ($flash): 
    ?>
      <div class="alert alert-<?php echo htmlspecialchars($flash['type']); ?>">
        <?php echo htmlspecialchars($flash['message']); ?>
      </div>
    <?php endif; ?>
  </div>
