<?php
/**
 * AL GHAZI Phone Store - Customer Profile & Order History
 * متجر الغزي للهواتف الذكية - لوحة حساب العميل وسجل الطلبات
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$pdo = get_db();

require_login('login.php');

$current = current_user();
$page_title = 'حسابي';
$active_nav = 'my_account';

// Handle Profile Update POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid security token');
        header("Location: profile.php");
        exit;
    }

    $name = clean_input($_POST['name'] ?? '');
    $phone = clean_input($_POST['phone'] ?? '');
    $city = clean_input($_POST['city'] ?? '');
    $address = clean_input($_POST['address'] ?? '');
    $new_password = $_POST['new_password'] ?? '';

    if (empty($name)) {
        set_flash('danger', current_lang() === 'ar' ? 'الاسم مطلوب' : 'Name is required');
    } else {
        if (!empty($new_password)) {
            $hash = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt_up = $pdo->prepare("UPDATE users SET name = ?, phone = ?, city = ?, address = ?, password_hash = ? WHERE id = ?");
            $stmt_up->execute([$name, $phone, $city, $address, $hash, $current['id']]);
        } else {
            $stmt_up = $pdo->prepare("UPDATE users SET name = ?, phone = ?, city = ?, address = ? WHERE id = ?");
            $stmt_up->execute([$name, $phone, $city, $address, $current['id']]);
        }
        $_SESSION['user_name'] = $name;
        $_SESSION['user_phone'] = $phone;
        set_flash('success', current_lang() === 'ar' ? 'تم تحديث بيانات ملفك الشخصي بنجاح!' : 'Profile updated successfully!');
        header("Location: profile.php");
        exit;
    }
}

// Fetch full user record
$stmt_u = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt_u->execute([$current['id']]);
$user_record = $stmt_u->fetch();

// Fetch orders history
$stmt_orders = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC");
$stmt_orders->execute([$current['id']]);
$user_orders = $stmt_orders->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<div style="margin: 30px 0 60px;">
  <div class="section-header">
    <h1 class="section-title">👤 <?php _e('profile_title'); ?></h1>
    <?php if (is_admin()): ?>
      <a href="admin/index.php" class="btn-sm btn-primary-sm" style="padding:8px 16px;">
        ⚙️ <?php _e('admin_panel'); ?>
      </a>
    <?php endif; ?>
  </div>

  <div class="cart-layout">
    <!-- Orders History Column -->
    <div class="cart-table-card">
      <h3 style="font-size:1.2rem; font-weight:800; margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:12px;">
        📦 <?php _e('my_orders'); ?> (<?php echo count($user_orders); ?>)
      </h3>

      <?php if (empty($user_orders)): ?>
        <div style="padding:40px 20px; text-align:center; color:var(--text-muted);">
          <div style="font-size:2.5rem; margin-bottom:10px;">📦</div>
          <p><?php _e('no_orders_yet'); ?></p>
          <a href="products.php" class="btn-primary" style="display:inline-flex; width:auto; margin-top:15px; padding:8px 20px;">
            <?php _e('shop_now'); ?>
          </a>
        </div>
      <?php else: ?>
        <table class="cart-table">
          <thead>
            <tr>
              <th><?php _e('order_number'); ?></th>
              <th><?php _e('order_date'); ?></th>
              <th><?php _e('total'); ?></th>
              <th><?php _e('order_status'); ?></th>
              <th><?php _e('actions'); ?></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($user_orders as $ord): ?>
              <tr>
                <td>
                  <strong style="color:var(--primary);"><?php echo htmlspecialchars($ord['order_number']); ?></strong>
                </td>
                <td style="font-size:0.85rem; color:var(--text-muted);">
                  <?php echo date('Y-m-d', strtotime($ord['created_at'])); ?>
                </td>
                <td style="font-weight:700;">
                  <?php echo format_price($ord['grand_total']); ?>
                </td>
                <td>
                  <span class="status-badge status-<?php echo $ord['status']; ?>">
                    <?php _e('status_' . $ord['status']); ?>
                  </span>
                </td>
                <td>
                  <a href="order-confirmation.php?id=<?php echo $ord['id']; ?>" class="btn-sm btn-secondary-sm">
                    👁️ <?php echo current_lang() === 'ar' ? 'الفاتورة' : 'Invoice'; ?>
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>

    <!-- Personal Info & Update Column -->
    <div class="summary-card">
      <h3 style="font-size:1.2rem; font-weight:800; margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:12px;">
        ✏️ <?php _e('edit_profile'); ?>
      </h3>

      <form action="profile.php" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
          <label class="form-label"><?php _e('full_name'); ?> *</label>
          <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user_record['name']); ?>" required>
        </div>

        <div class="form-group">
          <label class="form-label"><?php _e('email_address'); ?></label>
          <input type="email" class="form-control" value="<?php echo htmlspecialchars($user_record['email']); ?>" disabled style="opacity:0.6;">
        </div>

        <div class="form-group">
          <label class="form-label"><?php _e('phone_number'); ?></label>
          <input type="tel" name="phone" class="form-control" value="<?php echo htmlspecialchars($user_record['phone'] ?? ''); ?>">
        </div>

        <div class="form-group">
          <label class="form-label"><?php _e('city'); ?></label>
          <input type="text" name="city" class="form-control" value="<?php echo htmlspecialchars($user_record['city'] ?? ''); ?>">
        </div>

        <div class="form-group">
          <label class="form-label"><?php _e('street_address'); ?></label>
          <textarea name="address" class="form-control" rows="2"><?php echo htmlspecialchars($user_record['address'] ?? ''); ?></textarea>
        </div>

        <div class="form-group">
          <label class="form-label"><?php echo current_lang() === 'ar' ? 'تغيير كلمة المرور (اتركه فارغاً إذا لا تريد تغييره)' : 'Change Password (leave empty to keep current)'; ?></label>
          <input type="password" name="new_password" class="form-control" placeholder="••••••••">
        </div>

        <button type="submit" class="btn-primary" style="margin-top:10px;">
          💾 <?php _e('save_changes'); ?>
        </button>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
