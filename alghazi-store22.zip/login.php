<?php
/**
 * AL GHAZI Phone Store - Login Page
 * متجر الغزي للهواتف الذكية - صفحة تسجيل الدخول
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$pdo = get_db();

// Redirect if already logged in
if (is_logged_in()) {
    if (is_staff()) {
        header("Location: admin/index.php");
    } else {
        header("Location: profile.php");
    }
    exit;
}

$page_title = 'تسجيل الدخول';
$active_nav = 'login';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $email = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            $error = current_lang() === 'ar' ? 'يرجى إدخال البريد الإلكتروني وكلمة المرور' : 'Email and password are required';
        } else {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password_hash'])) {
                login_user($user);
                set_flash('success', (current_lang() === 'ar' ? 'أهلاً بك مجدداً، ' : 'Welcome back, ') . htmlspecialchars($user['name']));

                if (in_array($user['role'], ['admin', 'staff'])) {
                    header("Location: admin/index.php");
                } else {
                    $redirect = $_GET['redirect'] ?? 'profile.php';
                    header("Location: " . $redirect);
                }
                exit;
            } else {
                $error = current_lang() === 'ar' ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة!' : 'Invalid email or password!';
            }
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width:480px; margin: 40px auto 70px;">
  <div class="cart-table-card">
    <div style="text-align:center; margin-bottom:24px;">
      <h1 style="font-size:1.6rem; font-weight:800; color:#fff; margin-bottom:6px;"><?php _e('login_title'); ?></h1>
      <p style="color:var(--text-muted); font-size:0.875rem;"><?php _e('login_desc'); ?></p>
    </div>

    <?php if ($error): ?>
      <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form action="login.php<?php echo isset($_GET['redirect']) ? '?redirect=' . urlencode($_GET['redirect']) : ''; ?>" method="POST">
      <?php echo csrf_field(); ?>

      <div class="form-group">
        <label class="form-label"><?php _e('email_address'); ?> *</label>
        <input type="email" name="email" class="form-control" required placeholder="admin@alghazi.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
      </div>

      <div class="form-group">
        <label class="form-label"><?php _e('password'); ?> *</label>
        <input type="password" name="password" class="form-control" required placeholder="••••••••">
      </div>

      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; font-size:0.85rem;">
        <label style="display:flex; align-items:center; gap:6px; cursor:pointer; color:var(--text-muted);">
          <input type="checkbox" name="remember" style="accent-color:var(--primary);">
          <span><?php _e('remember_me'); ?></span>
        </label>
        <a href="contact.php" style="color:var(--primary);"><?php echo current_lang() === 'ar' ? 'نسيت كلمة المرور؟' : 'Forgot password?'; ?></a>
      </div>

      <button type="submit" class="btn-primary" style="padding:13px;">
        🔑 <?php _e('login'); ?>
      </button>
    </form>

    <!-- Demo Credentials Box -->
    <div style="margin-top:24px; background:var(--bg-surface); border:1px dashed var(--border-color); border-radius:var(--radius-sm); padding:16px; font-size:0.825rem;">
      <strong style="color:var(--primary); display:block; margin-bottom:8px;">💡 <?php _e('demo_credentials'); ?></strong>
      <div style="color:var(--text-muted); line-height:1.6;">
        <div>👑 <strong>المدير العام: admin@alghazi.com / admin123</strong></div>
        <div>💼 <strong>موظف المتجر: staff@alghazi.com / staff123</strong></div>
        <div>👤 <strong>العميل التجريبي: customer@alghazi.com / user123</strong></div>
      </div>
    </div>

    <!-- Registration Link -->
    <div style="margin-top:24px; text-align:center; font-size:0.875rem; color:var(--text-muted); border-top:1px solid var(--border-color); padding-top:18px;">
      <?php _e('dont_have_account'); ?>
      <a href="register.php" style="color:var(--primary); font-weight:700; margin-inline-start:4px;">
        <?php _e('create_account_now'); ?>
      </a>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
