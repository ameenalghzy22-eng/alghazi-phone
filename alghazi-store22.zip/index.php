<?php
/**
 * AL GHAZI Phone Store - Home Page
 * متجر الغزي للهواتف الذكية - الصفحة الرئيسية
 */

$page_title = 'الرئيسية';
$active_nav = 'home';
require_once __DIR__ . '/includes/header.php';

// 1. Fetch Featured Products
$stmt_feat = $pdo->prepare("SELECT * FROM products WHERE is_featured = 1 ORDER BY id DESC LIMIT 4");
$stmt_feat->execute();
$featured_products = $stmt_feat->fetchAll();

// 2. Fetch Latest Arrivals
$stmt_new = $pdo->prepare("SELECT * FROM products WHERE is_new = 1 ORDER BY id DESC LIMIT 4");
$stmt_new->execute();
$latest_products = $stmt_new->fetchAll();

// 3. Fetch Bestsellers
$stmt_best = $pdo->prepare("SELECT * FROM products WHERE is_bestseller = 1 ORDER BY id DESC LIMIT 4");
$stmt_best->execute();
$bestseller_products = $stmt_best->fetchAll();

// 4. Fetch Discounted Deals
$stmt_deals = $pdo->prepare("SELECT * FROM products WHERE discount_price IS NOT NULL AND discount_price < price ORDER BY (price - discount_price) DESC LIMIT 4");
$stmt_deals->execute();
$discounted_products = $stmt_deals->fetchAll();
?>

<!-- Hero Banner Section -->
<section class="hero-section">
  <div class="hero-banner">
    <img src="assets/images/banner1.svg" alt="<?php _e('hero_title'); ?>">
  </div>
</section>

<!-- Trust & Value Proposition Features -->
<section class="features-grid">
  <div class="feature-card">
    <div class="feature-icon">🛡️</div>
    <div class="feature-info">
      <h4><?php _e('feature_original_title'); ?></h4>
      <p><?php _e('feature_original_desc'); ?></p>
    </div>
  </div>
  <div class="feature-card">
    <div class="feature-icon">🚀</div>
    <div class="feature-info">
      <h4><?php _e('feature_shipping_title'); ?></h4>
      <p><?php _e('feature_shipping_desc'); ?></p>
    </div>
  </div>
  <div class="feature-card">
    <div class="feature-icon">⭐</div>
    <div class="feature-info">
      <h4><?php _e('feature_warranty_title'); ?></h4>
      <p><?php _e('feature_warranty_desc'); ?></p>
    </div>
  </div>
  <div class="feature-card">
    <div class="feature-icon">🎧</div>
    <div class="feature-info">
      <h4><?php _e('feature_support_title'); ?></h4>
      <p><?php _e('feature_support_desc'); ?></p>
    </div>
  </div>
</section>

<!-- Categories Showcase Section -->
<section class="categories-section">
  <div class="section-header">
    <div>
      <h2 class="section-title">📂 <?php _e('browse_categories'); ?></h2>
      <p class="section-subtitle"><?php echo current_lang() === 'ar' ? 'تصفح أحدث الأجهزة الذكية مقسمة حسب الفئات' : 'Browse our smart gadgets organized by category'; ?></p>
    </div>
    <a href="products.php" class="view-all-link"><?php _e('view_all'); ?> &larr;</a>
  </div>

  <div class="categories-grid">
    <?php foreach ($menu_categories as $cat): ?>
      <a href="products.php?category=<?php echo urlencode($cat['slug']); ?>" class="category-card">
        <div class="category-icon-box">
          <?php 
            if ($cat['slug'] === 'phones') echo '📱';
            elseif ($cat['slug'] === 'headphones') echo '🎧';
            elseif ($cat['slug'] === 'accessories') echo '⚡';
            elseif ($cat['slug'] === 'smartwatches') echo '⌚';
            else echo '📦';
          ?>
        </div>
        <h3 class="category-title"><?php echo htmlspecialchars(get_localized($cat, 'name')); ?></h3>
        <p class="category-desc"><?php echo htmlspecialchars(get_localized($cat, 'description')); ?></p>
      </a>
    <?php endforeach; ?>
  </div>
</section>

<!-- Featured Products Section -->
<section class="products-section">
  <div class="section-header">
    <div>
      <h2 class="section-title">✨ <?php _e('featured_products'); ?></h2>
      <p class="section-subtitle"><?php _e('featured_subtitle'); ?></p>
    </div>
    <a href="products.php" class="view-all-link"><?php _e('view_all'); ?> &larr;</a>
  </div>

  <div class="products-grid">
    <?php foreach ($featured_products as $p): ?>
      <?php include __DIR__ . '/includes/product-card.php'; ?>
    <?php endforeach; ?>
  </div>
</section>

<!-- Second Banner Promotion -->
<section class="hero-section" style="margin-bottom: 40px;">
  <div class="hero-banner">
    <img src="assets/images/banner2.svg" alt="Audio & Tech">
  </div>
</section>

<!-- Exclusive Deals & Discounts Section -->
<section class="products-section">
  <div class="section-header">
    <div>
      <h2 class="section-title">🔥 <?php _e('deals_and_discounts'); ?></h2>
      <p class="section-subtitle"><?php echo current_lang() === 'ar' ? 'أكبر تخفيضات على أجهزة مختارة لفترة محدودة' : 'Biggest savings on select smartphones and gadgets'; ?></p>
    </div>
    <a href="products.php?filter=deals" class="view-all-link"><?php _e('view_all'); ?> &larr;</a>
  </div>

  <div class="products-grid">
    <?php foreach ($discounted_products as $p): ?>
      <?php include __DIR__ . '/includes/product-card.php'; ?>
    <?php endforeach; ?>
  </div>
</section>

<!-- Best Sellers Section -->
<section class="products-section">
  <div class="section-header">
    <div>
      <h2 class="section-title">🏆 <?php _e('best_sellers'); ?></h2>
      <p class="section-subtitle"><?php echo current_lang() === 'ar' ? 'الأكثر طلباً وتفضيلاً من عملائنا الكرام' : 'Top selling devices chosen by our customers'; ?></p>
    </div>
    <a href="products.php?filter=bestseller" class="view-all-link"><?php _e('view_all'); ?> &larr;</a>
  </div>

  <div class="products-grid">
    <?php foreach ($bestseller_products as $p): ?>
      <?php include __DIR__ . '/includes/product-card.php'; ?>
    <?php endforeach; ?>
  </div>
</section>

<!-- Latest Arrivals Section -->
<section class="products-section">
  <div class="section-header">
    <div>
      <h2 class="section-title">🆕 <?php _e('latest_products'); ?></h2>
      <p class="section-subtitle"><?php echo current_lang() === 'ar' ? 'أحدث الإطلاقات التكنولوجية المضافة حديثاً للمتجر' : 'Freshly added flagship gadgets to our catalog'; ?></p>
    </div>
    <a href="products.php?filter=new" class="view-all-link"><?php _e('view_all'); ?> &larr;</a>
  </div>

  <div class="products-grid">
    <?php foreach ($latest_products as $p): ?>
      <?php include __DIR__ . '/includes/product-card.php'; ?>
    <?php endforeach; ?>
  </div>
</section>

<!-- Brands Showcase -->
<section style="margin: 40px 0 60px; background: var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius-md); padding:30px; text-align:center;">
  <h3 style="font-size:1.1rem; color:var(--text-muted); margin-bottom:20px; text-transform:uppercase; letter-spacing:1px;">
    <?php echo current_lang() === 'ar' ? 'وكيل وموزع معتمد لأكبر العلامات التجارية' : 'Authorized Retailer For Leading Tech Brands'; ?>
  </h3>
  <div style="display:flex; flex-wrap:wrap; justify-content:center; align-items:center; gap:40px; font-weight:900; font-size:1.35rem; color:var(--text-dim);">
    <span> Apple</span>
    <span>SAMSUNG</span>
    <span>Xiaomi</span>
    <span>Google Pixel</span>
    <span>SONY</span>
    <span>ANKER</span>
    <span>OnePlus</span>
    <span>HONOR</span>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
