<?php
/**
 * AL GHAZI Store - Admin Settings & Profile Management
 * متجر الغزي للهواتف الذكية - إعدادات المتجر وحساب المدير
 */

$admin_page_title = 'إعدادات المتجر وحساب المدير';
$admin_nav = 'settings';
require_once __DIR__ . '/../includes/admin-header.php';
$pdo = get_db();
$user = current_user() ?: ['id' => 1, 'name' => 'Admin', 'email' => 'admin@alghazi.com', 'role' => 'admin'];

// Handle Store Settings POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_store_settings'])) {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $keys = [
            'store_name_ar', 'store_name_en', 'store_phone', 'store_whatsapp',
            'store_email', 'store_address_ar', 'store_address_en',
            'shipping_cost', 'free_shipping_min', 'currency_symbol'
        ];

        $stmt_up = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?");
        foreach ($keys as $k) {
            if (isset($_POST[$k])) {
                $stmt_up->execute([clean_input($_POST[$k]), $k]);
            }
        }
        set_flash('success', current_lang() === 'ar' ? 'تم حفظ إعدادات المتجر بنجاح!' : 'Store settings saved successfully!');
        header("Location: settings.php");
        exit;
    }
}

// Handle Admin Account Update POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_admin_account'])) {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $admin_name = clean_input($_POST['admin_name']);
        $admin_email = strtolower(clean_input($_POST['admin_email']));
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (empty($admin_name) || empty($admin_email)) {
            set_flash('danger', 'Name and email are required');
        } elseif (!empty($new_password) && $new_password !== $confirm_password) {
            set_flash('danger', 'Passwords do not match');
        } else {
            if (!empty($new_password)) {
                $hash = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt_u = $pdo->prepare("UPDATE users SET name = ?, email = ?, password_hash = ? WHERE id = ?");
                $stmt_u->execute([$admin_name, $admin_email, $hash, $user['id']]);
            } else {
                $stmt_u = $pdo->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
                $stmt_u->execute([$admin_name, $admin_email, $user['id']]);
            }
            $_SESSION['user_name'] = $admin_name;
            $_SESSION['user_email'] = $admin_email;
            set_flash('success', current_lang() === 'ar' ? 'تم تحديث بيانات حساب المدير بنجاح!' : 'Admin account updated successfully!');
            header("Location: settings.php");
            exit;
        }
    }
}

$all_settings = get_all_settings($pdo);
?>

<div style="display:grid; grid-template-columns: 2fr 1.2fr; gap:25px;">
  <!-- Store Settings Form -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title">⚙️ <?php _e('store_settings'); ?></h3>
    </div>

    <form action="settings.php" method="POST">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="save_store_settings" value="1">

      <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
        <div class="form-group">
          <label class="form-label">اسم المتجر (بالعربية)</label>
          <input type="text" name="store_name_ar" class="form-control" value="<?php echo htmlspecialchars($all_settings['store_name_ar'] ?? ''); ?>">
        </div>
        <div class="form-group">
          <label class="form-label">اسم المتجر (بالإنجليزية)</label>
          <input type="text" name="store_name_en" class="form-control" value="<?php echo htmlspecialchars($all_settings['store_name_en'] ?? ''); ?>">
        </div>
      </div>

      <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
        <div class="form-group">
          <label class="form-label">هاتف خدمة العملاء</label>
          <input type="text" name="store_phone" class="form-control" value="<?php echo htmlspecialchars($all_settings['store_phone'] ?? ''); ?>">
        </div>
        <div class="form-group">
          <label class="form-label">رقم الواتساب</label>
          <input type="text" name="store_whatsapp" class="form-control" value="<?php echo htmlspecialchars($all_settings['store_whatsapp'] ?? ''); ?>">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">البريد الإلكتروني الرسمي</label>
        <input type="email" name="store_email" class="form-control" value="<?php echo htmlspecialchars($all_settings['store_email'] ?? ''); ?>">
      </div>

      <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
        <div class="form-group">
          <label class="form-label">تكلفة الشحن القياسية ($)</label>
          <input type="number" step="0.5" name="shipping_cost" class="form-control" value="<?php echo htmlspecialchars($all_settings['shipping_cost'] ?? '15.00'); ?>">
        </div>
        <div class="form-group">
          <label class="form-label">الحد الأدنى للشحن المجاني ($)</label>
          <input type="number" step="1" name="free_shipping_min" class="form-control" value="<?php echo htmlspecialchars($all_settings['free_shipping_min'] ?? '250.00'); ?>">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">عنوان المعرض (بالعربية)</label>
        <textarea name="store_address_ar" class="form-control" rows="2"><?php echo htmlspecialchars($all_settings['store_address_ar'] ?? ''); ?></textarea>
      </div>

      <div class="form-group">
        <label class="form-label">عنوان المعرض (بالإنجليزية)</label>
        <textarea name="store_address_en" class="form-control" rows="2"><?php echo htmlspecialchars($all_settings['store_address_en'] ?? ''); ?></textarea>
      </div>

      <button type="submit" class="btn-sm btn-primary-sm" style="padding:12px 24px; font-size:1rem; margin-top:10px;">
        💾 <?php _e('save_changes'); ?>
      </button>
    </form>
  </div>

  <!-- Admin Account Management -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title">🔐 إدارة حساب المدير</h3>
    </div>

    <form action="settings.php" method="POST">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="update_admin_account" value="1">

      <div class="form-group">
        <label class="form-label"><?php _e('full_name'); ?> *</label>
        <input type="text" name="admin_name" class="form-control" required value="<?php echo htmlspecialchars($user['name']); ?>">
      </div>

      <div class="form-group">
        <label class="form-label"><?php _e('email_address'); ?> *</label>
        <input type="email" name="admin_email" class="form-control" required value="<?php echo htmlspecialchars($user['email']); ?>">
      </div>

      <div class="form-group">
        <label class="form-label">كلمة مرور جديدة (اختياري)</label>
        <input type="password" name="new_password" class="form-control" placeholder="••••••••">
      </div>

      <div class="form-group">
        <label class="form-label">تأكيد كلمة المرور الجديدة</label>
        <input type="password" name="confirm_password" class="form-control" placeholder="••••••••">
      </div>

      <button type="submit" class="btn-sm btn-primary-sm" style="width:100%; padding:11px; justify-content:center; margin-top:10px;">
        💾 تحديث حساب المدير
      </button>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
