<?php
/**
 * AL GHAZI Store - Admin Product Form (Add & Edit)
 * متجر الغزي للهواتف الذكية - نموذج إضافة وتعديل المنتج
 */

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin('../login.php');

$pdo = get_db();

$edit_id = (int)($_GET['id'] ?? 0);
$is_edit = $edit_id > 0;
$product = null;

if ($is_edit) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$edit_id]);
    $product = $stmt->fetch();
    if (!$product) {
        set_flash('danger', 'Product not found');
        header("Location: products.php");
        exit;
    }
    $admin_page_title = 'تعديل المنتج: ' . htmlspecialchars($product['name_ar']);
} else {
    $admin_page_title = 'إضافة منتج جديد';
}

$admin_nav = $is_edit ? 'products' : 'product_add';

// Handle POST Save
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid security token');
        header("Location: " . ($is_edit ? "product-form.php?id=$edit_id" : "product-form.php"));
        exit;
    }

    $name_ar = clean_input($_POST['name_ar'] ?? '');
    $name_en = clean_input($_POST['name_en'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 1);
    $brand = clean_input($_POST['brand'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $discount_price = !empty($_POST['discount_price']) ? (float)$_POST['discount_price'] : null;
    $stock = (int)($_POST['stock'] ?? 0);
    $description_ar = clean_input($_POST['description_ar'] ?? '');
    $description_en = clean_input($_POST['description_en'] ?? '');
    $specs_text = trim($_POST['specs_json'] ?? '');
    $is_featured = isset($_POST['is_featured']) ? 1 : 0;
    $is_bestseller = isset($_POST['is_bestseller']) ? 1 : 0;
    $is_new = isset($_POST['is_new']) ? 1 : 0;

    // Handle Image Upload
    $uploaded_image = upload_product_image('product_image');
    $main_image = $uploaded_image ?: ($product['main_image'] ?? 'iphone-16.svg');

    // Generate or keep slug
    $slug = !empty($_POST['slug']) ? clean_input($_POST['slug']) : strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name_en)));
    if (empty($slug)) {
        $slug = 'prod-' . time();
    }

    // Format specs
    $specs_json = null;
    if (!empty($specs_text)) {
        // Test if valid JSON
        json_decode($specs_text);
        if (json_last_error() === JSON_ERROR_NONE) {
            $specs_json = $specs_text;
        } else {
            // Convert newline key:value pairs into JSON
            $lines = explode("\n", $specs_text);
            $parsed = [];
            foreach ($lines as $line) {
                if (strpos($line, ':') !== false) {
                    list($k, $v) = explode(':', $line, 2);
                    $parsed[trim($k)] = trim($v);
                }
            }
            $specs_json = json_encode($parsed, JSON_UNESCAPED_UNICODE);
        }
    }

    if ($is_edit) {
        $stmt_up = $pdo->prepare("
            UPDATE products SET
                category_id = ?, slug = ?, name_ar = ?, name_en = ?, brand = ?,
                description_ar = ?, description_en = ?, price = ?, discount_price = ?,
                stock = ?, main_image = ?, specs_json = ?, is_featured = ?, is_bestseller = ?, is_new = ?
            WHERE id = ?
        ");
        $stmt_up->execute([
            $category_id, $slug, $name_ar, $name_en, $brand,
            $description_ar, $description_en, $price, $discount_price,
            $stock, $main_image, $specs_json, $is_featured, $is_bestseller, $is_new,
            $edit_id
        ]);
        set_flash('success', current_lang() === 'ar' ? 'تم تحديث بيانات المنتج بنجاح!' : 'Product updated successfully!');
        header("Location: products.php");
        exit;
    } else {
        $stmt_in = $pdo->prepare("
            INSERT INTO products (
                category_id, slug, name_ar, name_en, brand,
                description_ar, description_en, price, discount_price, stock,
                main_image, specs_json, is_featured, is_bestseller, is_new
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt_in->execute([
            $category_id, $slug, $name_ar, $name_en, $brand,
            $description_ar, $description_en, $price, $discount_price, $stock,
            $main_image, $specs_json, $is_featured, $is_bestseller, $is_new
        ]);
        set_flash('success', current_lang() === 'ar' ? 'تمت إضافة المنتج بنجاح!' : 'Product added successfully!');
        header("Location: products.php");
        exit;
    }
}

require_once __DIR__ . '/../includes/admin-header.php';
$categories = $pdo->query("SELECT * FROM categories ORDER BY sort_order ASC")->fetchAll();
?>

<div class="admin-card" style="max-width:900px; margin:0 auto;">
  <div class="admin-card-header">
    <h3 class="admin-card-title"><?php echo $is_edit ? __('edit_product') : __('add_product'); ?></h3>
    <a href="products.php" class="btn-sm btn-secondary-sm">&larr; <?php _e('manage_products'); ?></a>
  </div>

  <form action="product-form.php<?php echo $is_edit ? '?id=' . $edit_id : ''; ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <!-- Names AR & EN -->
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
      <div class="form-group">
        <label class="form-label"><?php _e('product_name_ar'); ?> *</label>
        <input type="text" name="name_ar" class="form-control" required value="<?php echo htmlspecialchars($product['name_ar'] ?? ''); ?>" placeholder="آبل آيفون 16 برو ماكس">
      </div>
      <div class="form-group">
        <label class="form-label"><?php _e('product_name_en'); ?> *</label>
        <input type="text" name="name_en" class="form-control" required value="<?php echo htmlspecialchars($product['name_en'] ?? ''); ?>" placeholder="Apple iPhone 16 Pro Max">
      </div>
    </div>

    <!-- Category & Brand & Slug -->
    <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px;">
      <div class="form-group">
        <label class="form-label"><?php _e('product_category'); ?> *</label>
        <select name="category_id" class="form-control" required>
          <?php foreach ($categories as $cat): ?>
            <option value="<?php echo $cat['id']; ?>" <?php echo (isset($product['category_id']) && $product['category_id'] == $cat['id']) ? 'selected' : ''; ?>>
              <?php echo htmlspecialchars(get_localized($cat, 'name')); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="form-group">
        <label class="form-label"><?php _e('product_brand'); ?> *</label>
        <input type="text" name="brand" class="form-control" required value="<?php echo htmlspecialchars($product['brand'] ?? ''); ?>" placeholder="Apple, Samsung, Xiaomi...">
      </div>

      <div class="form-group">
        <label class="form-label">الاسم اللطيف في الرابط (Slug)</label>
        <input type="text" name="slug" class="form-control" value="<?php echo htmlspecialchars($product['slug'] ?? ''); ?>" placeholder="iphone-16-pro-max">
      </div>
    </div>

    <!-- Pricing & Stock -->
    <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px;">
      <div class="form-group">
        <label class="form-label"><?php _e('product_price'); ?> ($) *</label>
        <input type="number" step="0.01" name="price" class="form-control" required value="<?php echo htmlspecialchars($product['price'] ?? ''); ?>" placeholder="1199.00">
      </div>

      <div class="form-group">
        <label class="form-label"><?php _e('product_discount_price'); ?> ($)</label>
        <input type="number" step="0.01" name="discount_price" class="form-control" value="<?php echo htmlspecialchars($product['discount_price'] ?? ''); ?>" placeholder="1049.00">
      </div>

      <div class="form-group">
        <label class="form-label"><?php _e('product_stock'); ?> *</label>
        <input type="number" name="stock" class="form-control" required value="<?php echo htmlspecialchars($product['stock'] ?? '10'); ?>" placeholder="10">
      </div>
    </div>

    <!-- Descriptions AR & EN -->
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
      <div class="form-group">
        <label class="form-label"><?php _e('product_desc_ar'); ?></label>
        <textarea name="description_ar" class="form-control" rows="4"><?php echo htmlspecialchars($product['description_ar'] ?? ''); ?></textarea>
      </div>
      <div class="form-group">
        <label class="form-label"><?php _e('product_desc_en'); ?></label>
        <textarea name="description_en" class="form-control" rows="4"><?php echo htmlspecialchars($product['description_en'] ?? ''); ?></textarea>
      </div>
    </div>

    <!-- Specifications JSON / Key-Value -->
    <div class="form-group">
      <label class="form-label"><?php _e('specs_helper'); ?></label>
      <textarea name="specs_json" class="form-control" rows="3" placeholder="RAM: 8GB&#10;Storage: 256GB&#10;Battery: 4685 mAh"><?php 
        if (!empty($product['specs_json'])) {
            $dec = json_decode($product['specs_json'], true);
            if (is_array($dec)) {
                $lines = [];
                foreach ($dec as $k => $v) $lines[] = "$k: $v";
                echo htmlspecialchars(implode("\n", $lines));
            } else {
                echo htmlspecialchars($product['specs_json']);
            }
        }
      ?></textarea>
    </div>

    <!-- Image Upload & Live Preview -->
    <div class="form-group">
      <label class="form-label"><?php _e('upload_image'); ?></label>
      <div class="image-upload-wrapper">
        <div class="image-preview-box">
          <?php
            $current_img = '';
            if (!empty($product['main_image'])) {
                $current_img = '../assets/images/products/' . htmlspecialchars($product['main_image']);
                if (!file_exists($current_img)) {
                    $current_img = '../uploads/products/' . htmlspecialchars($product['main_image']);
                }
            }
          ?>
          <img id="productImagePreview" src="<?php echo $current_img; ?>" alt="Preview" style="<?php echo empty($current_img) ? 'display:none;' : ''; ?>">
        </div>
        <div style="flex:1;">
          <input type="file" name="product_image" id="productImageInput" class="form-control" accept="image/png, image/jpeg, image/webp, image/svg+xml">
          <small style="color:var(--admin-muted); display:block; margin-top:6px;">
            الملفات المدعومة: PNG, JPG, WebP, SVG (حجم أقصى 5 ميجابايت)
          </small>
        </div>
      </div>
    </div>

    <!-- Visibility / Feature Flags -->
    <div style="display:flex; flex-wrap:wrap; gap:25px; margin:25px 0; background:var(--admin-surface); padding:16px; border-radius:8px;">
      <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
        <input type="checkbox" name="is_featured" value="1" <?php echo !empty($product['is_featured']) ? 'checked' : ''; ?> style="accent-color:var(--admin-primary); width:18px; height:18px;">
        <strong style="color:#fff;">✨ <?php _e('featured_products'); ?></strong>
      </label>

      <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
        <input type="checkbox" name="is_bestseller" value="1" <?php echo !empty($product['is_bestseller']) ? 'checked' : ''; ?> style="accent-color:var(--admin-primary); width:18px; height:18px;">
        <strong style="color:#fff;">🏆 <?php _e('best_sellers'); ?></strong>
      </label>

      <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
        <input type="checkbox" name="is_new" value="1" <?php echo !empty($product['is_new']) ? 'checked' : ''; ?> style="accent-color:var(--admin-primary); width:18px; height:18px;">
        <strong style="color:#fff;">🆕 <?php _e('new_badge'); ?></strong>
      </label>
    </div>

    <!-- Submit Buttons -->
    <div style="display:flex; gap:12px;">
      <button type="submit" class="btn-sm btn-primary-sm" style="padding:12px 28px; font-size:1rem;">
        💾 <?php _e('save_changes'); ?>
      </button>
      <a href="products.php" class="btn-sm btn-secondary-sm" style="padding:12px 20px;">
        <?php _e('cancel'); ?>
      </a>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
