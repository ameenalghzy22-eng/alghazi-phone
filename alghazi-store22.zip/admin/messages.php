<?php
/**
 * AL GHAZI Store - Admin Messages Management
 * متجر الغزي للهواتف الذكية - استعراض رسائل واستفسارات العملاء
 */

$admin_page_title = 'رسائل واستفسارات العملاء';
$admin_nav = 'messages';
require_once __DIR__ . '/../includes/admin-header.php';
$pdo = get_db();

// Handle Mark as Read / Unread
if (isset($_GET['toggle_read'])) {
    $mid = (int)$_GET['toggle_read'];
    if ($mid > 0) {
        $stmt_m = $pdo->prepare("SELECT is_read FROM contact_messages WHERE id = ?");
        $stmt_m->execute([$mid]);
        $current = $stmt_m->fetchColumn();
        $new_val = $current ? 0 : 1;

        $stmt_up = $pdo->prepare("UPDATE contact_messages SET is_read = ? WHERE id = ?");
        $stmt_up->execute([$new_val, $mid]);
        set_flash('success', current_lang() === 'ar' ? 'تم تحديث حالة الرسالة' : 'Message status updated');
        header("Location: messages.php");
        exit;
    }
}

// Handle Delete Message
if (isset($_GET['delete'])) {
    $mid = (int)$_GET['delete'];
    if ($mid > 0) {
        $stmt_del = $pdo->prepare("DELETE FROM contact_messages WHERE id = ?");
        $stmt_del->execute([$mid]);
        set_flash('success', current_lang() === 'ar' ? 'تم حذف الرسالة' : 'Message deleted');
        header("Location: messages.php");
        exit;
    }
}

$messages = $pdo->query("SELECT * FROM contact_messages ORDER BY id DESC")->fetchAll();
?>

<div class="admin-card">
  <div class="admin-card-header">
    <h3 class="admin-card-title">💬 <?php _e('contact_inquiries'); ?> (<?php echo count($messages); ?>)</h3>
  </div>

  <?php if (empty($messages)): ?>
    <div style="text-align:center; padding:40px; color:var(--admin-muted);">
      <div style="font-size:2.5rem; margin-bottom:10px;">📭</div>
      <p><?php echo current_lang() === 'ar' ? 'صندوق الرسائل فارغ، لا توجد استفسارات جديدة.' : 'Inbox is empty, no new messages.'; ?></p>
    </div>
  <?php else: ?>
    <div style="display:flex; flex-direction:column; gap:16px;">
      <?php foreach ($messages as $msg): ?>
        <div style="background:var(--admin-surface); border:1px solid <?php echo $msg['is_read'] ? 'var(--admin-border)' : 'var(--admin-primary)'; ?>; border-radius:10px; padding:18px;">
          <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:10px;">
            <div>
              <div style="display:flex; align-items:center; gap:10px;">
                <strong style="color:#fff; font-size:1.05rem;"><?php echo htmlspecialchars($msg['subject']); ?></strong>
                <?php if (!$msg['is_read']): ?>
                  <span class="badge" style="background:var(--admin-danger); color:#fff; font-size:0.7rem;">جديد</span>
                <?php endif; ?>
              </div>
              <div style="font-size:0.8rem; color:var(--admin-muted); margin-top:4px;">
                من: <strong><?php echo htmlspecialchars($msg['name']); ?></strong> (<?php echo htmlspecialchars($msg['email']); ?> | <?php echo htmlspecialchars($msg['phone'] ?? '—'); ?>) • 
                <?php echo date('Y-m-d H:i', strtotime($msg['created_at'])); ?>
              </div>
            </div>
            <div style="display:flex; gap:8px;">
              <a href="messages.php?toggle_read=<?php echo $msg['id']; ?>" class="btn-sm btn-secondary-sm">
                <?php echo $msg['is_read'] ? 'تعليم كغير مقروء' : 'تعليم كمقروء ✓'; ?>
              </a>
              <a href="messages.php?delete=<?php echo $msg['id']; ?>" class="btn-sm btn-danger-sm btn-confirm-delete" data-confirm="<?php _e('confirm_delete'); ?>">
                🗑️
              </a>
            </div>
          </div>
          <div style="background:#090F20; padding:12px; border-radius:6px; font-size:0.9rem; color:#E2E8F0; line-height:1.6;">
            <?php echo nl2br(htmlspecialchars($msg['message'])); ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
