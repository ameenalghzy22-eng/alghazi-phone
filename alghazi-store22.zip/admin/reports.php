<?php
/**
 * AL GHAZI Store - Admin Reports & Python Analytics Service
 * متجر الغزي للهواتف الذكية - التقارير وخدمات بايثون المساندة وإدارة الخصومات
 */

$admin_page_title = 'التقارير وخدمات بايثون';
$admin_nav = 'reports';
require_once __DIR__ . '/../includes/admin-header.php';
$pdo = get_db();

$python_output = '';
$action_performed = '';

// Handle Python Script Execution POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['run_python'])) {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $task = clean_input($_POST['python_task'] ?? 'all');
        $python_script = realpath(__DIR__ . '/../python/analytics_export.py');

        // Detect python executable
        $cmd = "python \"$python_script\" $task 2>&1";
        $python_output = shell_exec($cmd);
        $action_performed = $task;
        set_flash('success', current_lang() === 'ar' ? 'تم تنفيذ خدمة بايثون وتوليد التقارير بنجاح!' : 'Python service executed successfully!');
    }
}

// Handle Add Coupon POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_coupon'])) {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $code = strtoupper(clean_input($_POST['coupon_code']));
        $type = clean_input($_POST['discount_type']);
        $val = (float)$_POST['discount_val'];
        $min_order = (float)$_POST['min_order'];
        $expiry = clean_input($_POST['expiry_date']);

        if (!empty($code) && $val > 0) {
            $stmt_ins = $pdo->prepare("INSERT INTO coupons (code, discount_type, discount_val, min_order, expiry_date) VALUES (?, ?, ?, ?, ?)");
            $stmt_ins->execute([$code, $type, $val, $min_order, $expiry ?: null]);
            set_flash('success', current_lang() === 'ar' ? 'تمت إضافة كود الخصم الجديد بنجاح!' : 'Coupon created successfully!');
            header("Location: reports.php");
            exit;
        }
    }
}

// Handle Delete Coupon
if (isset($_GET['del_coupon'])) {
    $cid = (int)$_GET['del_coupon'];
    if ($cid > 0) {
        $pdo->prepare("DELETE FROM coupons WHERE id = ?")->execute([$cid]);
        set_flash('success', current_lang() === 'ar' ? 'تم حذف الكود' : 'Coupon deleted');
        header("Location: reports.php");
        exit;
    }
}

// Fetch generated CSV files from reports/ directory
$reports_dir = realpath(__DIR__ . '/../reports');
$csv_files = [];
if ($reports_dir && is_dir($reports_dir)) {
    $files = scandir($reports_dir);
    foreach ($files as $f) {
        if (str_ends_with($f, '.csv')) {
            $csv_files[] = [
                'name' => $f,
                'path' => '../reports/' . $f,
                'size' => round(filesize($reports_dir . '/' . $f) / 1024, 2) . ' KB',
                'time' => date('Y-m-d H:i', filemtime($reports_dir . '/' . $f))
            ];
        }
    }
}

// Fetch all coupons
$coupons = $pdo->query("SELECT * FROM coupons ORDER BY id DESC")->fetchAll();
?>

<!-- Python Automation & Intelligence Section -->
<div class="admin-card" style="border: 1px solid var(--admin-primary);">
  <div class="admin-card-header">
    <div>
      <h3 class="admin-card-title">🐍 <?php _e('analytics_reports'); ?></h3>
      <p style="font-size:0.85rem; color:var(--admin-muted); margin-top:4px;">
        <?php echo current_lang() === 'ar' 
          ? 'تشغيل خدمات بايثون المستقلة لتحليل أداء المبيعات وحركة المخزون وتصدير ملفات CSV.' 
          : 'Execute backend Python service for intelligence analytics and CSV reporting.'; ?>
      </p>
    </div>
  </div>

  <div style="display:flex; flex-wrap:wrap; gap:12px; margin-bottom:20px;">
    <!-- Run Full Summary & Exports -->
    <form action="reports.php" method="POST" style="margin:0;">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="run_python" value="1">
      <input type="hidden" name="python_task" value="all">
      <button type="submit" class="btn-sm btn-primary-sm" style="padding:10px 18px; font-size:0.9rem;">
        ⚡ <?php echo current_lang() === 'ar' ? 'تشغيل التحليل الشامل وتوليد التقارير' : 'Run Full Analytics & Export CSV'; ?>
      </button>
    </form>

    <!-- Run Sales Only -->
    <form action="reports.php" method="POST" style="margin:0;">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="run_python" value="1">
      <input type="hidden" name="python_task" value="sales">
      <button type="submit" class="btn-sm btn-secondary-sm" style="padding:10px 18px; font-size:0.9rem;">
        📥 <?php echo current_lang() === 'ar' ? 'تصدير تقرير المبيعات فقط (CSV)' : 'Export Sales CSV'; ?>
      </button>
    </form>

    <!-- Run Inventory Only -->
    <form action="reports.php" method="POST" style="margin:0;">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="run_python" value="1">
      <input type="hidden" name="python_task" value="inventory">
      <button type="submit" class="btn-sm btn-secondary-sm" style="padding:10px 18px; font-size:0.9rem;">
        📦 <?php echo current_lang() === 'ar' ? 'تصدير تقرير المخزون (CSV)' : 'Export Inventory CSV'; ?>
      </button>
    </form>
  </div>

  <!-- Live Terminal Log from Python -->
  <?php if (!empty($python_output)): ?>
    <div style="margin-top:20px;">
      <h4 style="font-size:0.9rem; font-weight:700; color:var(--admin-primary); margin-bottom:8px;">
        💻 مخرجات خدمة بايثون (Python CLI Output):
      </h4>
      <div class="terminal-box"><?php echo htmlspecialchars($python_output); ?></div>
    </div>
  <?php endif; ?>
</div>

<!-- CSV Reports Downloads -->
<div class="admin-card">
  <div class="admin-card-header">
    <h3 class="admin-card-title">📁 <?php echo current_lang() === 'ar' ? 'ملفات التقارير المولدة عبر بايثون (CSV)' : 'Generated Python Reports (CSV)'; ?></h3>
  </div>

  <?php if (empty($csv_files)): ?>
    <p style="color:var(--admin-muted); text-align:center; padding:20px;">
      <?php echo current_lang() === 'ar' ? 'اضغط على زر تشغيل التحليل أعلاه لتوليد أول تقرير.' : 'Click Run Analytics above to generate your first CSV report.'; ?>
    </p>
  <?php else: ?>
    <table class="admin-table">
      <thead>
        <tr>
          <th>اسم الملف</th>
          <th>الحجم</th>
          <th>تاريخ التوليد</th>
          <th>تحميل</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($csv_files as $cf): ?>
          <tr>
            <td>
              <strong style="color:#fff;">📄 <?php echo htmlspecialchars($cf['name']); ?></strong>
            </td>
            <td><?php echo $cf['size']; ?></td>
            <td style="color:var(--admin-muted);"><?php echo $cf['time']; ?></td>
            <td>
              <a href="<?php echo $cf['path']; ?>" download class="btn-sm btn-primary-sm">
                ⬇️ <?php echo current_lang() === 'ar' ? 'تحميل الملف' : 'Download'; ?>
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>

<!-- Coupons & Discounts Management -->
<div style="display:grid; grid-template-columns: 2fr 1.2fr; gap:25px;">
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title">🎟️ <?php echo current_lang() === 'ar' ? 'كوبونات الخصم النشطة' : 'Active Discount Coupons'; ?></h3>
    </div>

    <table class="admin-table">
      <thead>
        <tr>
          <th>كود الخصم</th>
          <th>قيمة الخصم</th>
          <th>الحد الأدنى للطلب</th>
          <th>تاريخ الانتهاء</th>
          <th>إجراء</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($coupons as $coup): ?>
          <tr>
            <td><strong style="color:var(--admin-primary); font-size:1rem;"><?php echo htmlspecialchars($coup['code']); ?></strong></td>
            <td>
              <?php echo $coup['discount_type'] === 'percent' ? $coup['discount_val'] . '%' : format_price($coup['discount_val']); ?>
            </td>
            <td><?php echo format_price($coup['min_order']); ?></td>
            <td style="font-size:0.85rem; color:var(--admin-muted);"><?php echo $coup['expiry_date'] ?: 'غير محدد'; ?></td>
            <td>
              <a href="reports.php?del_coupon=<?php echo $coup['id']; ?>" class="btn-sm btn-danger-sm btn-confirm-delete" data-confirm="حذف هذا الكوبون؟">🗑️</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- Add Coupon Form -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title">➕ إضافة كود خصم جديد</h3>
    </div>

    <form action="reports.php" method="POST">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="add_coupon" value="1">

      <div class="form-group">
        <label class="form-label">كود الخصم (رمز الكوبون) *</label>
        <input type="text" name="coupon_code" class="form-control" placeholder="SALE20" required style="text-transform:uppercase;">
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
        <div class="form-group">
          <label class="form-label">نوع الخصم</label>
          <select name="discount_type" class="form-control">
            <option value="percent">نسبة مئوية (%)</option>
            <option value="fixed">مبلغ ثابت ($)</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">القيمة *</label>
          <input type="number" step="0.5" name="discount_val" class="form-control" placeholder="10" required>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">الحد الأدنى لقيمة الطلب ($)</label>
        <input type="number" step="1" name="min_order" class="form-control" value="0">
      </div>

      <div class="form-group">
        <label class="form-label">تاريخ الانتهاء (اختياري)</label>
        <input type="date" name="expiry_date" class="form-control">
      </div>

      <button type="submit" class="btn-sm btn-primary-sm" style="width:100%; padding:11px; justify-content:center; margin-top:8px;">
        ✨ تفعيل كود الخصم
      </button>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
