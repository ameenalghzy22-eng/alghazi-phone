<?php
/**
 * AL GHAZI Store - Admin Orders Management
 * متجر الغزي للهواتف الذكية - إدارة طلبات العملاء وحالات الشحن
 */

$admin_page_title = 'إدارة الطلبات';
$admin_nav = 'orders';
require_once __DIR__ . '/../includes/admin-header.php';
$pdo = get_db();

// Handle Quick Status Update POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $ord_id = (int)$_POST['order_id'];
        $new_status = clean_input($_POST['status']);
        $stmt_up = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt_up->execute([$new_status, $ord_id]);
        set_flash('success', current_lang() === 'ar' ? 'تم تحديث حالة الطلب بنجاح!' : 'Order status updated successfully!');
        header("Location: orders.php" . (isset($_GET['status']) ? '?status=' . urlencode($_GET['status']) : ''));
        exit;
    }
}

// Handle Delete Order GET
if (isset($_GET['delete'])) {
    $del_id = (int)$_GET['delete'];
    if ($del_id > 0) {
        $stmt_del = $pdo->prepare("DELETE FROM orders WHERE id = ?");
        $stmt_del->execute([$del_id]);
        set_flash('success', current_lang() === 'ar' ? 'تم حذف الطلب' : 'Order deleted');
        header("Location: orders.php");
        exit;
    }
}

// Status & Search Filters
$status_filter = $_GET['status'] ?? '';
$search = trim($_GET['search'] ?? '');

$where = ["1=1"];
$params = [];

if (!empty($status_filter) && in_array($status_filter, ['pending', 'processing', 'shipped', 'delivered', 'cancelled'])) {
    $where[] = "status = ?";
    $params[] = $status_filter;
}

if (!empty($search)) {
    $where[] = "(order_number LIKE ? OR customer_name LIKE ? OR customer_phone LIKE ? OR customer_email LIKE ?)";
    $term = "%{$search}%";
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

$where_sql = implode(' AND ', $where);

$stmt_orders = $pdo->prepare("SELECT * FROM orders WHERE {$where_sql} ORDER BY id DESC");
$stmt_orders->execute($params);
$orders_list = $stmt_orders->fetchAll();
?>

<div class="admin-card">
  <!-- Card Header -->
  <div class="admin-card-header">
    <h3 class="admin-card-title">📦 <?php _e('manage_orders'); ?> (<?php echo count($orders_list); ?>)</h3>
    <a href="reports.php" class="btn-sm btn-secondary-sm">
      📊 <?php echo current_lang() === 'ar' ? 'تقارير المبيعات' : 'Sales Reports'; ?>
    </a>
  </div>

  <!-- Filter Buttons Bar -->
  <div style="display:flex; flex-wrap:wrap; gap:8px; margin-bottom:20px;">
    <a href="orders.php" class="btn-sm <?php echo empty($status_filter) ? 'btn-primary-sm' : 'btn-secondary-sm'; ?>">
      <?php echo current_lang() === 'ar' ? 'جميع الطلبات' : 'All Orders'; ?>
    </a>
    <a href="orders.php?status=pending" class="btn-sm <?php echo $status_filter === 'pending' ? 'btn-primary-sm' : 'btn-secondary-sm'; ?>">
      ⏳ <?php _e('status_pending'); ?>
    </a>
    <a href="orders.php?status=processing" class="btn-sm <?php echo $status_filter === 'processing' ? 'btn-primary-sm' : 'btn-secondary-sm'; ?>">
      ⚙️ <?php _e('status_processing'); ?>
    </a>
    <a href="orders.php?status=shipped" class="btn-sm <?php echo $status_filter === 'shipped' ? 'btn-primary-sm' : 'btn-secondary-sm'; ?>">
      🚚 <?php _e('status_shipped'); ?>
    </a>
    <a href="orders.php?status=delivered" class="btn-sm <?php echo $status_filter === 'delivered' ? 'btn-primary-sm' : 'btn-secondary-sm'; ?>">
      ✓ <?php _e('status_delivered'); ?>
    </a>
    <a href="orders.php?status=cancelled" class="btn-sm <?php echo $status_filter === 'cancelled' ? 'btn-primary-sm' : 'btn-secondary-sm'; ?>">
      ✕ <?php _e('status_cancelled'); ?>
    </a>
  </div>

  <!-- Search Toolbar -->
  <form action="orders.php" method="GET" style="display:flex; gap:12px; margin-bottom:20px; max-width:400px;">
    <?php if (!empty($status_filter)): ?>
      <input type="hidden" name="status" value="<?php echo htmlspecialchars($status_filter); ?>">
    <?php endif; ?>
    <input type="text" name="search" class="form-control" placeholder="رقم الطلب أو اسم العميل..." value="<?php echo htmlspecialchars($search); ?>">
    <button type="submit" class="btn-sm btn-secondary-sm">🔍</button>
  </form>

  <!-- Orders Data Table -->
  <table class="admin-table">
    <thead>
      <tr>
        <th><?php _e('order_number'); ?></th>
        <th><?php _e('customer_information'); ?></th>
        <th><?php _e('city'); ?></th>
        <th><?php _e('total'); ?></th>
        <th><?php _e('order_status'); ?></th>
        <th>تغيير الحالة</th>
        <th><?php _e('actions'); ?></th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($orders_list)): ?>
        <tr>
          <td colspan="7" style="text-align:center; padding:30px; color:var(--admin-muted);">
            <?php echo current_lang() === 'ar' ? 'لا توجد طلبات تطابق معايير البحث.' : 'No orders found matching criteria.'; ?>
          </td>
        </tr>
      <?php else: ?>
        <?php foreach ($orders_list as $ord): ?>
          <tr>
            <td>
              <strong style="color:var(--admin-primary); font-size:0.95rem;"><?php echo htmlspecialchars($ord['order_number']); ?></strong>
              <div style="font-size:0.75rem; color:var(--admin-muted);"><?php echo date('Y-m-d H:i', strtotime($ord['created_at'])); ?></div>
            </td>
            <td>
              <strong style="color:#fff;"><?php echo htmlspecialchars($ord['customer_name']); ?></strong>
              <div style="font-size:0.8rem; color:var(--admin-muted);"><?php echo htmlspecialchars($ord['customer_phone']); ?></div>
            </td>
            <td><?php echo htmlspecialchars($ord['shipping_city']); ?></td>
            <td style="font-weight:700; color:#fff;">
              <?php echo format_price($ord['grand_total']); ?>
              <div style="font-size:0.75rem; color:var(--admin-muted);"><?php echo strtoupper($ord['payment_method']); ?></div>
            </td>
            <td>
              <span class="status-badge status-<?php echo $ord['status']; ?>">
                <?php _e('status_' . $ord['status']); ?>
              </span>
            </td>
            <td>
              <!-- Quick Status Update Form -->
              <form action="orders.php<?php echo !empty($status_filter) ? '?status=' . urlencode($status_filter) : ''; ?>" method="POST" style="margin:0;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="update_status" value="1">
                <input type="hidden" name="order_id" value="<?php echo $ord['id']; ?>">
                <select name="status" class="form-control" style="padding:4px 8px; font-size:0.8rem; width:130px;" onchange="this.form.submit()">
                  <option value="pending" <?php echo $ord['status'] === 'pending' ? 'selected' : ''; ?>>⏳ <?php _e('status_pending'); ?></option>
                  <option value="processing" <?php echo $ord['status'] === 'processing' ? 'selected' : ''; ?>>⚙️ <?php _e('status_processing'); ?></option>
                  <option value="shipped" <?php echo $ord['status'] === 'shipped' ? 'selected' : ''; ?>>🚚 <?php _e('status_shipped'); ?></option>
                  <option value="delivered" <?php echo $ord['status'] === 'delivered' ? 'selected' : ''; ?>>✓ <?php _e('status_delivered'); ?></option>
                  <option value="cancelled" <?php echo $ord['status'] === 'cancelled' ? 'selected' : ''; ?>>✕ <?php _e('status_cancelled'); ?></option>
                </select>
              </form>
            </td>
            <td>
              <div style="display:flex; gap:6px;">
                <a href="order-view.php?id=<?php echo $ord['id']; ?>" class="btn-sm btn-secondary-sm" title="عرض التفاصيل">
                  👁️
                </a>
                <a href="orders.php?delete=<?php echo $ord['id']; ?>" class="btn-sm btn-danger-sm btn-confirm-delete" data-confirm="<?php _e('confirm_delete'); ?>" title="حذف">
                  🗑️
                </a>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
