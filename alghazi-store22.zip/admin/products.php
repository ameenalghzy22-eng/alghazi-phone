<?php
/**
 * AL GHAZI Store - Admin Products Management
 * متجر الغزي للهواتف الذكية - إدارة المنتجات والمخزون والأسعار
 */

$admin_page_title = 'إدارة المنتجات';
$admin_nav = 'products';
require_once __DIR__ . '/../includes/admin-header.php';
$pdo = get_db();

// Handle Delete Action
if (isset($_GET['delete'])) {
    $del_id = (int)$_GET['delete'];
    if ($del_id > 0) {
        $stmt_del = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt_del->execute([$del_id]);
        set_flash('success', current_lang() === 'ar' ? 'تم حذف المنتج بنجاح!' : 'Product deleted successfully!');
        header("Location: products.php");
        exit;
    }
}

// Search and Category Filter
$search = trim($_GET['search'] ?? '');
$category_id = (int)($_GET['cat_id'] ?? 0);

$where = ["1=1"];
$params = [];

if (!empty($search)) {
    $where[] = "(p.name_ar LIKE ? OR p.name_en LIKE ? OR p.brand LIKE ?)";
    $term = "%{$search}%";
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

if ($category_id > 0) {
    $where[] = "p.category_id = ?";
    $params[] = $category_id;
}

$where_sql = implode(' AND ', $where);

$stmt_prods = $pdo->prepare("
    SELECT p.*, c.name_ar as cat_ar, c.name_en as cat_en
    FROM products p
    JOIN categories c ON p.category_id = c.id
    WHERE {$where_sql}
    ORDER BY p.id DESC
");
$stmt_prods->execute($params);
$all_prods = $stmt_prods->fetchAll();

// Categories for filter dropdown
$categories_list = $pdo->query("SELECT id, name_ar, name_en FROM categories ORDER BY sort_order ASC")->fetchAll();
?>

<div class="admin-card">
  <!-- Card Header with Add Button -->
  <div class="admin-card-header">
    <h3 class="admin-card-title">📱 <?php _e('manage_products'); ?> (<?php echo count($all_prods); ?>)</h3>
    <a href="product-form.php" class="btn-sm btn-primary-sm">
      ➕ <?php _e('add_product'); ?>
    </a>
  </div>

  <!-- Filter & Search Toolbar -->
  <form action="products.php" method="GET" style="display:flex; flex-wrap:wrap; gap:12px; margin-bottom:20px;">
    <input type="text" name="search" class="form-control" placeholder="بحث بالاسم أو الماركة..." value="<?php echo htmlspecialchars($search); ?>" style="max-width:280px; padding:8px 14px;">
    <select name="cat_id" class="form-control" style="max-width:220px; padding:8px 14px;" onchange="this.form.submit()">
      <option value="0"><?php _e('all_categories'); ?></option>
      <?php foreach ($categories_list as $c): ?>
        <option value="<?php echo $c['id']; ?>" <?php echo $category_id === (int)$c['id'] ? 'selected' : ''; ?>>
          <?php echo htmlspecialchars(get_localized($c, 'name')); ?>
        </option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn-sm btn-secondary-sm">
      🔍 <?php _e('search'); ?>
    </button>
    <?php if (!empty($search) || $category_id > 0): ?>
      <a href="products.php" class="btn-sm btn-secondary-sm">✕ <?php _e('reset_filters'); ?></a>
    <?php endif; ?>
  </form>

  <!-- Products Data Table -->
  <table class="admin-table">
    <thead>
      <tr>
        <th>#</th>
        <th><?php _e('product'); ?></th>
        <th><?php _e('category'); ?></th>
        <th><?php _e('product_price'); ?></th>
        <th><?php _e('product_stock'); ?></th>
        <th><?php _e('actions'); ?></th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($all_prods)): ?>
        <tr>
          <td colspan="6" style="text-align:center; padding:30px; color:var(--admin-muted);">
            <?php _e('no_products_found'); ?>
          </td>
        </tr>
      <?php else: ?>
        <?php foreach ($all_prods as $prod): ?>
          <?php
            $img = '../assets/images/products/' . htmlspecialchars($prod['main_image']);
            if (!file_exists($img)) {
                $img = '../uploads/products/' . htmlspecialchars($prod['main_image']);
            }
          ?>
          <tr>
            <td style="color:var(--admin-muted);"><?php echo $prod['id']; ?></td>
            <td>
              <div style="display:flex; align-items:center; gap:12px;">
                <img src="<?php echo $img; ?>" alt="thumb" style="width:48px; height:48px; border-radius:6px; background:var(--admin-surface); padding:2px; object-fit:contain;">
                <div>
                  <div style="font-size:0.75rem; color:var(--admin-primary); font-weight:700; text-transform:uppercase;"><?php echo htmlspecialchars($prod['brand']); ?></div>
                  <strong style="color:#fff; font-size:0.95rem;"><?php echo htmlspecialchars(get_localized($prod, 'name')); ?></strong>
                  <?php if (!empty($prod['is_featured'])): ?>
                    <span style="font-size:0.65rem; background:rgba(0,229,255,0.2); color:var(--admin-primary); padding:2px 5px; border-radius:4px; margin-inline-start:6px;">FEATURED</span>
                  <?php endif; ?>
                </div>
              </div>
            </td>
            <td><?php echo htmlspecialchars(get_localized($prod, 'cat')); ?></td>
            <td>
              <div style="font-weight:700; color:#fff;"><?php echo format_price($prod['price']); ?></div>
              <?php if ($prod['discount_price'] !== null && $prod['discount_price'] > 0): ?>
                <div style="font-size:0.8rem; color:var(--admin-success); font-weight:700;">
                  <?php echo format_price($prod['discount_price']); ?> (<?php _e('discount_badge'); ?>)
                </div>
              <?php endif; ?>
            </td>
            <td>
              <?php if ($prod['stock'] <= 0): ?>
                <span class="status-badge status-cancelled">0 (<?php _e('out_of_stock'); ?>)</span>
              <?php elseif ($prod['stock'] <= 5): ?>
                <span class="status-badge status-pending"><?php echo $prod['stock']; ?> (منخفض)</span>
              <?php else: ?>
                <span class="status-badge status-delivered"><?php echo $prod['stock']; ?></span>
              <?php endif; ?>
            </td>
            <td>
              <div style="display:flex; gap:6px;">
                <a href="product-form.php?id=<?php echo $prod['id']; ?>" class="btn-sm btn-secondary-sm" title="<?php _e('edit_product'); ?>">
                  ✏️
                </a>
                <a href="products.php?delete=<?php echo $prod['id']; ?>" class="btn-sm btn-danger-sm btn-confirm-delete" 
                   data-confirm="<?php _e('confirm_delete'); ?>" title="<?php _e('delete_product'); ?>">
                  🗑️
                </a>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
