<?php
/**
 * AL GHAZI Store - Admin Dashboard Index
 * متجر الغزي للهواتف الذكية - لوحة التحكم الرئيسية
 */

$admin_page_title = 'لوحة التحكم الرئيسية';
$admin_nav = 'dashboard';
require_once __DIR__ . '/../includes/admin-header.php';
$pdo = get_db();

// Key Metrics
$total_revenue = (float)$pdo->query("SELECT COALESCE(SUM(grand_total), 0) FROM orders WHERE status != 'cancelled'")->fetchColumn();
$total_orders = (int)$pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$total_products = (int)$pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$total_customers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();
$low_stock_count = (int)$pdo->query("SELECT COUNT(*) FROM products WHERE stock <= 5")->fetchColumn();

// Recent Orders
$stmt_recent = $pdo->query("SELECT * FROM orders ORDER BY id DESC LIMIT 5");
$recent_orders = $stmt_recent->fetchAll();

// Top Selling Products
$stmt_top = $pdo->query("
    SELECT oi.product_name, oi.product_image, SUM(oi.quantity) as sold_count, SUM(oi.subtotal) as total_val
    FROM order_items oi
    GROUP BY oi.product_id
    ORDER BY sold_count DESC
    LIMIT 4
");
$top_products = $stmt_top->fetchAll();
?>

<!-- Role Permission Notice Banner -->
<?php if ($is_emp): ?>
  <div class="alert alert-info" style="display:flex; align-items:center; gap:12px; margin-bottom:24px;">
    <span style="font-size:1.5rem;">👤</span>
    <div>
      <strong style="display:block; font-size:1rem;">مرحباً بك، <?php echo htmlspecialchars($user['name']); ?> (صلاحية موظف متجر)</strong>
      <span style="font-size:0.85rem;">صلاحياتك المتاحة تشمل: متابعة وتحديث حالات الطلبات، مراجعة المخزون، والرد على استفسارات العملاء. البيانات المالية وإعدادات المتجر محجوزة للمدير العام.</span>
    </div>
  </div>
<?php endif; ?>

<!-- Statistics Overview Grid -->
<div class="stats-grid">
  <!-- Revenue Card (Admin Only) -->
  <div class="stat-card">
    <div class="stat-icon" style="color:var(--admin-primary);">💵</div>
    <div class="stat-info">
      <h3><?php echo $is_mgr ? format_price($total_revenue) : '<span style="font-size:1.1rem; color:var(--admin-muted);">محمي (للمدير)</span>'; ?></h3>
      <p><?php _e('total_revenue'); ?></p>
    </div>
  </div>

  <!-- Orders Card -->
  <div class="stat-card">
    <div class="stat-icon" style="color:var(--admin-secondary);">📦</div>
    <div class="stat-info">
      <h3><?php echo $total_orders; ?></h3>
      <p><?php _e('total_orders'); ?></p>
    </div>
  </div>

  <!-- Products Card -->
  <div class="stat-card">
    <div class="stat-icon" style="color:#A855F7;">📱</div>
    <div class="stat-info">
      <h3><?php echo $total_products; ?></h3>
      <p><?php _e('total_products'); ?></p>
    </div>
  </div>

  <!-- Customers Card -->
  <div class="stat-card">
    <div class="stat-icon" style="color:#10B981;">👥</div>
    <div class="stat-info">
      <h3><?php echo $total_customers; ?></h3>
      <p><?php _e('total_customers'); ?></p>
    </div>
  </div>

  <!-- Low Stock Alert -->
  <div class="stat-card" style="<?php echo $low_stock_count > 0 ? 'border-color:var(--admin-danger);' : ''; ?>">
    <div class="stat-icon" style="color:var(--admin-warning);">⚠️</div>
    <div class="stat-info">
      <h3 style="<?php echo $low_stock_count > 0 ? 'color:var(--admin-danger);' : ''; ?>"><?php echo $low_stock_count; ?></h3>
      <p><?php _e('low_stock_alert'); ?></p>
    </div>
  </div>
</div>

<!-- Quick Action Shortcuts -->
<div style="display:flex; flex-wrap:wrap; gap:12px; margin-bottom:30px;">
  <a href="product-form.php" class="btn-sm btn-primary-sm" style="padding:10px 18px; font-size:0.9rem;">
    ➕ <?php _e('add_product'); ?>
  </a>
  <a href="orders.php" class="btn-sm btn-secondary-sm" style="padding:10px 18px; font-size:0.9rem;">
    📦 <?php _e('manage_orders'); ?>
  </a>
  <a href="reports.php" class="btn-sm btn-secondary-sm" style="padding:10px 18px; font-size:0.9rem;">
    🐍 <?php _e('analytics_reports'); ?>
  </a>
</div>

<!-- Layout: Recent Orders & Top Selling -->
<div style="display:grid; grid-template-columns: 2fr 1fr; gap:25px;">
  <!-- Recent Orders Table -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title">📦 <?php _e('recent_orders'); ?></h3>
      <a href="orders.php" class="btn-sm btn-secondary-sm"><?php _e('view_all'); ?> &rarr;</a>
    </div>

    <?php if (empty($recent_orders)): ?>
      <p style="color:var(--admin-muted); text-align:center; padding:30px;"><?php echo current_lang() === 'ar' ? 'لا توجد طلبات مسجلة حتى الآن.' : 'No orders recorded yet.'; ?></p>
    <?php else: ?>
      <table class="admin-table">
        <thead>
          <tr>
            <th><?php _e('order_number'); ?></th>
            <th><?php _e('customer_information'); ?></th>
            <th><?php _e('total'); ?></th>
            <th><?php _e('order_status'); ?></th>
            <th><?php _e('actions'); ?></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($recent_orders as $ord): ?>
            <tr>
              <td>
                <strong style="color:var(--admin-primary);"><?php echo htmlspecialchars($ord['order_number']); ?></strong>
                <div style="font-size:0.75rem; color:var(--admin-muted);"><?php echo date('Y-m-d', strtotime($ord['created_at'])); ?></div>
              </td>
              <td>
                <div style="font-weight:700; color:#fff;"><?php echo htmlspecialchars($ord['customer_name']); ?></div>
                <div style="font-size:0.75rem; color:var(--admin-muted);"><?php echo htmlspecialchars($ord['shipping_city']); ?></div>
              </td>
              <td style="font-weight:700; color:#fff;">
                <?php echo format_price($ord['grand_total']); ?>
              </td>
              <td>
                <span class="status-badge status-<?php echo $ord['status']; ?>">
                  <?php _e('status_' . $ord['status']); ?>
                </span>
              </td>
              <td>
                <a href="order-view.php?id=<?php echo $ord['id']; ?>" class="btn-sm btn-secondary-sm">
                  👁️ <?php echo current_lang() === 'ar' ? 'تفاصيل' : 'View'; ?>
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>

  <!-- Top Selling Products -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title">🔥 <?php _e('best_sellers'); ?></h3>
    </div>

    <div style="display:flex; flex-direction:column; gap:16px;">
      <?php foreach ($top_products as $tp): ?>
        <?php 
          $timg = '../assets/images/products/' . htmlspecialchars($tp['product_image']);
          if (!file_exists($timg)) {
              $timg = '../uploads/products/' . htmlspecialchars($tp['product_image']);
          }
        ?>
        <div style="display:flex; align-items:center; gap:12px; font-size:0.875rem;">
          <img src="<?php echo $timg; ?>" alt="img" style="width:46px; height:46px; border-radius:6px; background:var(--admin-surface); padding:2px; object-fit:contain;">
          <div style="flex:1;">
            <div style="font-weight:700; color:#fff; line-height:1.3; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:160px;">
              <?php echo htmlspecialchars($tp['product_name']); ?>
            </div>
            <div style="font-size:0.75rem; color:var(--admin-muted);">
              <?php echo $tp['sold_count']; ?> <?php echo current_lang() === 'ar' ? 'قطعة مباعة' : 'units sold'; ?>
            </div>
          </div>
          <div style="font-weight:700; color:var(--admin-primary);">
            <?php echo format_price($tp['total_val']); ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
