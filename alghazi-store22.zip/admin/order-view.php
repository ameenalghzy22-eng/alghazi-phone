<?php
/**
 * AL GHAZI Store - Admin View Order Details
 * متجر الغزي للهواتف الذكية - تفاصيل الطلب الكاملة
 */

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

require_admin('../login.php');

$pdo = get_db();

$order_id = (int)($_GET['id'] ?? 0);
if ($order_id <= 0) {
    header("Location: orders.php");
    exit;
}

// Handle Status & Notes Update POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $status = clean_input($_POST['status']);
        $notes = clean_input($_POST['notes']);
        $stmt_up = $pdo->prepare("UPDATE orders SET status = ?, notes = ? WHERE id = ?");
        $stmt_up->execute([$status, $notes, $order_id]);
        set_flash('success', current_lang() === 'ar' ? 'تم تحديث بيانات الطلب بنجاح!' : 'Order updated successfully!');
        header("Location: order-view.php?id=$order_id");
        exit;
    }
}

// Fetch Order
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch();

if (!$order) {
    set_flash('danger', 'Order not found');
    header("Location: orders.php");
    exit;
}

// Fetch Items
$stmt_items = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
$stmt_items->execute([$order_id]);
$order_items = $stmt_items->fetchAll();

$admin_page_title = 'تفاصيل الطلب: ' . htmlspecialchars($order['order_number']);
$admin_nav = 'orders';
require_once __DIR__ . '/../includes/admin-header.php';
?>

<div style="display:grid; grid-template-columns: 2fr 1fr; gap:25px;">
  <!-- Order Items & Invoice Column -->
  <div class="admin-card">
    <div class="admin-card-header">
      <div>
        <h3 class="admin-card-title"><?php echo htmlspecialchars($order['order_number']); ?></h3>
        <span style="font-size:0.85rem; color:var(--admin-muted);"><?php _e('order_date'); ?>: <?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?></span>
      </div>
      <div>
        <span class="status-badge status-<?php echo $order['status']; ?>" style="font-size:0.9rem; padding:6px 14px;">
          <?php _e('status_' . $order['status']); ?>
        </span>
      </div>
    </div>

    <!-- Items Table -->
    <table class="admin-table" style="margin-bottom:24px;">
      <thead>
        <tr>
          <th><?php _e('product'); ?></th>
          <th><?php _e('price'); ?></th>
          <th><?php _e('quantity'); ?></th>
          <th><?php _e('subtotal'); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($order_items as $oi): ?>
          <?php
            $img = '../assets/images/products/' . htmlspecialchars($oi['product_image']);
            if (!file_exists($img)) {
                $img = '../uploads/products/' . htmlspecialchars($oi['product_image']);
            }
          ?>
          <tr>
            <td>
              <div style="display:flex; align-items:center; gap:12px;">
                <img src="<?php echo $img; ?>" alt="img" style="width:44px; height:44px; border-radius:6px; background:var(--admin-surface); padding:2px; object-fit:contain;">
                <div>
                  <strong style="color:#fff; font-size:0.95rem;"><?php echo htmlspecialchars($oi['product_name']); ?></strong>
                  <div style="font-size:0.75rem; color:var(--admin-muted);">ID: #<?php echo $oi['product_id']; ?></div>
                </div>
              </div>
            </td>
            <td><?php echo format_price($oi['price']); ?></td>
            <td><strong><?php echo $oi['quantity']; ?></strong></td>
            <td style="font-weight:700; color:var(--admin-primary);"><?php echo format_price($oi['subtotal']); ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <!-- Totals Breakdown -->
    <div style="max-width:320px; margin-inline-start:auto; border-top:1px solid var(--admin-border); padding-top:14px;">
      <div class="summary-row">
        <span><?php _e('subtotal'); ?>:</span>
        <strong style="color:#fff;"><?php echo format_price($order['subtotal']); ?></strong>
      </div>
      <?php if ($order['discount_amount'] > 0): ?>
        <div class="summary-row" style="color:var(--admin-success);">
          <span><?php _e('discount'); ?> (<?php echo htmlspecialchars($order['coupon_code']); ?>):</span>
          <strong>-<?php echo format_price($order['discount_amount']); ?></strong>
        </div>
      <?php endif; ?>
      <div class="summary-row">
        <span><?php _e('shipping'); ?>:</span>
        <strong><?php echo $order['shipping_cost'] == 0 ? __('free') : format_price($order['shipping_cost']); ?></strong>
      </div>
      <div class="summary-row total">
        <span><?php _e('total'); ?>:</span>
        <span style="color:var(--admin-primary); font-size:1.4rem;"><?php echo format_price($order['grand_total']); ?></span>
      </div>
    </div>
  </div>

  <!-- Customer Info & Status Updater Column -->
  <div>
    <!-- Status Update Form -->
    <div class="admin-card" style="margin-bottom:25px;">
      <div class="admin-card-header">
        <h3 class="admin-card-title">⚙️ تحديث حالة الطلب</h3>
      </div>
      <form action="order-view.php?id=<?php echo $order['id']; ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
          <label class="form-label"><?php _e('order_status'); ?></label>
          <select name="status" class="form-control">
            <option value="pending" <?php echo $order['status'] === 'pending' ? 'selected' : ''; ?>>⏳ <?php _e('status_pending'); ?></option>
            <option value="processing" <?php echo $order['status'] === 'processing' ? 'selected' : ''; ?>>⚙️ <?php _e('status_processing'); ?></option>
            <option value="shipped" <?php echo $order['status'] === 'shipped' ? 'selected' : ''; ?>>🚚 <?php _e('status_shipped'); ?></option>
            <option value="delivered" <?php echo $order['status'] === 'delivered' ? 'selected' : ''; ?>>✓ <?php _e('status_delivered'); ?></option>
            <option value="cancelled" <?php echo $order['status'] === 'cancelled' ? 'selected' : ''; ?>>✕ <?php _e('status_cancelled'); ?></option>
          </select>
        </div>

        <div class="form-group">
          <label class="form-label"><?php _e('order_notes'); ?></label>
          <textarea name="notes" class="form-control" rows="3"><?php echo htmlspecialchars($order['notes'] ?? ''); ?></textarea>
        </div>

        <button type="submit" class="btn-sm btn-primary-sm" style="width:100%; padding:11px; justify-content:center;">
          💾 <?php _e('save_changes'); ?>
        </button>
      </form>
    </div>

    <!-- Customer Details Card -->
    <div class="admin-card">
      <div class="admin-card-header">
        <h3 class="admin-card-title">👤 <?php _e('customer_information'); ?></h3>
      </div>

      <div style="font-size:0.9rem; line-height:1.8;">
        <div><strong>الاسم:</strong> <?php echo htmlspecialchars($order['customer_name']); ?></div>
        <div><strong>البريد:</strong> <?php echo htmlspecialchars($order['customer_email']); ?></div>
        <div><strong>الهاتف:</strong> <?php echo htmlspecialchars($order['customer_phone']); ?></div>
        <div style="margin-top:10px; border-top:1px solid var(--admin-border); padding-top:10px;">
          <strong>العنوان:</strong>
          <div><?php echo htmlspecialchars($order['shipping_city']); ?></div>
          <div style="color:var(--admin-muted);"><?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?></div>
        </div>
        <div style="margin-top:10px;">
          <strong>طريقة الدفع:</strong> 
          <span style="color:var(--admin-primary); font-weight:700;"><?php echo strtoupper($order['payment_method']); ?></span>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
