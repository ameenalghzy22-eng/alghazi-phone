<?php
/**
 * AL GHAZI Store - Admin Categories Management
 * متجر الغزي للهواتف الذكية - إدارة أقسام وتصنيفات المتجر
 */

$admin_page_title = 'إدارة الأقسام';
$admin_nav = 'categories';
require_once __DIR__ . '/../includes/admin-header.php';
$pdo = get_db();

// Handle Add or Edit Category POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid security token');
        header("Location: categories.php");
        exit;
    }

    $cat_id = (int)($_POST['category_id'] ?? 0);
    $name_ar = clean_input($_POST['name_ar'] ?? '');
    $name_en = clean_input($_POST['name_en'] ?? '');
    $slug = clean_input($_POST['slug'] ?? '');
    $icon = clean_input($_POST['icon'] ?? 'phone');
    $sort_order = (int)($_POST['sort_order'] ?? 0);

    if (empty($slug)) {
        $slug = strtolower(preg_replace('/[^A-Za-z0-9-]+/', '-', $name_en));
    }

    if (empty($name_ar) || empty($name_en)) {
        set_flash('danger', current_lang() === 'ar' ? 'يرجى إدخال اسم القسم بالعربية والإنجليزية' : 'Category names are required');
    } else {
        if ($cat_id > 0) {
            $stmt = $pdo->prepare("UPDATE categories SET name_ar = ?, name_en = ?, slug = ?, icon = ?, sort_order = ? WHERE id = ?");
            $stmt->execute([$name_ar, $name_en, $slug, $icon, $sort_order, $cat_id]);
            set_flash('success', current_lang() === 'ar' ? 'تم تحديث القسم بنجاح!' : 'Category updated successfully!');
        } else {
            $stmt = $pdo->prepare("INSERT INTO categories (name_ar, name_en, slug, icon, sort_order) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name_ar, $name_en, $slug, $icon, $sort_order]);
            set_flash('success', current_lang() === 'ar' ? 'تمت إضافة القسم الجديد بنجاح!' : 'Category added successfully!');
        }
        header("Location: categories.php");
        exit;
    }
}

// Handle Delete Category GET
if (isset($_GET['delete'])) {
    $del_id = (int)$_GET['delete'];
    if ($del_id > 0) {
        $stmt_del = $pdo->prepare("DELETE FROM categories WHERE id = ?");
        $stmt_del->execute([$del_id]);
        set_flash('success', current_lang() === 'ar' ? 'تم حذف القسم بنجاح' : 'Category deleted');
        header("Location: categories.php");
        exit;
    }
}

// Fetch categories with product counts
$categories = $pdo->query("
    SELECT c.*, COUNT(p.id) as products_count
    FROM categories c
    LEFT JOIN products p ON c.id = p.category_id
    GROUP BY c.id
    ORDER BY c.sort_order ASC
")->fetchAll();

$edit_cat = null;
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    foreach ($categories as $c) {
        if ($c['id'] == $edit_id) {
            $edit_cat = $c;
            break;
        }
    }
}
?>

<div style="display:grid; grid-template-columns: 1fr 340px; gap:25px;">
  <!-- Categories List Column -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title">📁 <?php _e('manage_categories'); ?> (<?php echo count($categories); ?>)</h3>
    </div>

    <table class="admin-table">
      <thead>
        <tr>
          <th>#</th>
          <th><?php _e('category'); ?></th>
          <th>Slug</th>
          <th><?php echo current_lang() === 'ar' ? 'المنتجات' : 'Products'; ?></th>
          <th><?php echo current_lang() === 'ar' ? 'الترتيب' : 'Sort'; ?></th>
          <th><?php _e('actions'); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($categories as $cat): ?>
          <tr>
            <td style="color:var(--admin-muted);"><?php echo $cat['id']; ?></td>
            <td>
              <strong style="color:#fff;"><?php echo htmlspecialchars($cat['name_ar']); ?></strong>
              <div style="font-size:0.8rem; color:var(--admin-muted);"><?php echo htmlspecialchars($cat['name_en']); ?></div>
            </td>
            <td><code><?php echo htmlspecialchars($cat['slug']); ?></code></td>
            <td>
              <span class="badge" style="background:var(--admin-surface); color:var(--admin-primary); border:1px solid var(--admin-border);">
                <?php echo $cat['products_count']; ?>
              </span>
            </td>
            <td><?php echo $cat['sort_order']; ?></td>
            <td>
              <div style="display:flex; gap:6px;">
                <a href="categories.php?edit=<?php echo $cat['id']; ?>" class="btn-sm btn-secondary-sm" title="تعديل">
                  ✏️
                </a>
                <a href="categories.php?delete=<?php echo $cat['id']; ?>" class="btn-sm btn-danger-sm btn-confirm-delete" data-confirm="<?php _e('confirm_delete'); ?>" title="حذف">
                  🗑️
                </a>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- Add / Edit Category Form Column -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title">
        <?php echo $edit_cat ? '✏️ تعديل القسم' : '➕ إضافة قسم جديد'; ?>
      </h3>
      <?php if ($edit_cat): ?>
        <a href="categories.php" class="btn-sm btn-secondary-sm">✕ إلغاء</a>
      <?php endif; ?>
    </div>

    <form action="categories.php" method="POST">
      <?php echo csrf_field(); ?>
      <?php if ($edit_cat): ?>
        <input type="hidden" name="category_id" value="<?php echo $edit_cat['id']; ?>">
      <?php endif; ?>

      <div class="form-group">
        <label class="form-label">اسم القسم بالعربية *</label>
        <input type="text" name="name_ar" class="form-control" required value="<?php echo htmlspecialchars($edit_cat['name_ar'] ?? ''); ?>" placeholder="الهواتف الذكية">
      </div>

      <div class="form-group">
        <label class="form-label">اسم القسم بالإنجليزية *</label>
        <input type="text" name="name_en" class="form-control" required value="<?php echo htmlspecialchars($edit_cat['name_en'] ?? ''); ?>" placeholder="Smartphones">
      </div>

      <div class="form-group">
        <label class="form-label">الاسم اللطيف (Slug) *</label>
        <input type="text" name="slug" class="form-control" value="<?php echo htmlspecialchars($edit_cat['slug'] ?? ''); ?>" placeholder="phones">
      </div>

      <div class="form-group">
        <label class="form-label">ترتيب الظهور</label>
        <input type="number" name="sort_order" class="form-control" value="<?php echo htmlspecialchars($edit_cat['sort_order'] ?? '0'); ?>">
      </div>

      <button type="submit" class="btn-sm btn-primary-sm" style="width:100%; padding:11px; justify-content:center; margin-top:10px;">
        💾 <?php echo $edit_cat ? 'تحديث القسم' : 'إضافة القسم'; ?>
      </button>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
