<?php
/**
 * AL GHAZI Store - Admin Staff & Users Management
 * متجر الغزي للهواتف الذكية - إدارة الموظفين والمستخدمين والصلاحيات
 */

$admin_page_title = 'إدارة الموظفين والمستخدمين';
$admin_nav = 'users';
require_once __DIR__ . '/../includes/admin-header.php';
$pdo = get_db();
$user = current_user() ?: ['id' => 1, 'name' => 'Admin', 'role' => 'admin'];

// Strict Access: Manager Only! Staff cannot access this page.
if (!$is_mgr) {
    set_flash('danger', current_lang() === 'ar' ? 'غير مصرح لك بالوصول! صفحة إدارة الموظفين مخصصة للمدير العام فقط.' : 'Access denied! Staff management is restricted to the General Manager.');
    header("Location: index.php");
    exit;
}

// 1. Handle Add New Staff / Employee
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_staff') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'فشل التحقق من رمز الأمان CSRF');
    } else {
        $name = trim($_POST['name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';
        $phone = trim($_POST['phone'] ?? '');
        $role = in_array($_POST['role'] ?? '', ['staff', 'admin']) ? $_POST['role'] : 'staff';

        if (empty($name) || empty($email) || empty($password)) {
            set_flash('danger', 'يرجى ملء جميع الحقول المطلوبة (الاسم، البريد الإلكتروني، كلمة المرور).');
        } elseif (strlen($password) < 6) {
            set_flash('danger', 'كلمة المرور يجب ألا تقل عن 6 خانات.');
        } else {
            // Check if email exists
            $stmt_chk = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt_chk->execute([$email]);
            if ($stmt_chk->fetch()) {
                set_flash('danger', 'البريد الإلكتروني مستخدم بالفعل! يرجى اختيار بريد آخر.');
            } else {
                $password_hash = password_hash($password, PASSWORD_BCRYPT);
                $stmt_ins = $pdo->prepare("INSERT INTO users (name, email, password_hash, phone, role, is_active) VALUES (?, ?, ?, ?, ?, 1)");
                $stmt_ins->execute([$name, $email, $password_hash, $phone, $role]);
                set_flash('success', "تمت إضافة الموظف ({$name}) بنجاح! يمكنه الآن تسجيل الدخول مباشرة.");
                header("Location: users.php");
                exit;
            }
        }
    }
}

// 2. Handle Delete Staff / User
if (isset($_GET['delete_user'])) {
    $uid = (int)$_GET['delete_user'];
    if ($uid > 0) {
        if ($uid === (int)$user['id']) {
            set_flash('danger', 'لا يمكنك حذف حسابك الحالي!');
        } elseif ($uid === 1) {
            set_flash('danger', 'لا يمكن حذف حساب المدير العام الأساسي للنظام.');
        } else {
            $stmt_d = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt_d->execute([$uid]);
            set_flash('success', 'تم حذف الموظف/المستخدم نهائياً من النظام بنجاح.');
            header("Location: users.php");
            exit;
        }
    }
}

// 3. Handle Status Toggle
if (isset($_GET['toggle_status'])) {
    $uid = (int)$_GET['toggle_status'];
    if ($uid > 0 && $uid !== (int)$user['id']) {
        $stmt_s = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
        $stmt_s->execute([$uid]);
        $curr_status = $stmt_s->fetchColumn();
        $new_status = $curr_status ? 0 : 1;

        $stmt_up = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
        $stmt_up->execute([$new_status, $uid]);
        set_flash('success', 'تم تحديث حالة تفعيل الحساب.');
        header("Location: users.php");
        exit;
    }
}

// 4. Handle Change Password for Any Staff or User
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $target_uid = (int)($_POST['target_user_id'] ?? 0);
        $new_pass = $_POST['new_password'] ?? '';
        if ($target_uid > 0 && strlen($new_pass) >= 4) {
            $hash = password_hash($new_pass, PASSWORD_BCRYPT);
            $stmt_p = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
            $stmt_p->execute([$hash, $target_uid]);
            set_flash('success', 'تم تغيير وتحديث كلمة المرور بنجاح.');
            header("Location: users.php");
            exit;
        } else {
            set_flash('danger', 'كلمة المرور يجب أن لا تقل عن 4 خانات.');
        }
    }
}

// 5. Handle Edit Staff / User Details (Name, Phone, Role, Password)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit_user') {
    if (verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $target_uid = (int)($_POST['target_user_id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $role = in_array($_POST['role'] ?? '', ['admin', 'staff', 'customer']) ? $_POST['role'] : 'staff';
        $new_pass = $_POST['new_password'] ?? '';

        if ($target_uid > 0 && !empty($name)) {
            if (!empty($new_pass) && strlen($new_pass) >= 4) {
                $hash = password_hash($new_pass, PASSWORD_BCRYPT);
                $stmt_up = $pdo->prepare("UPDATE users SET name = ?, phone = ?, role = ?, password_hash = ? WHERE id = ?");
                $stmt_up->execute([$name, $phone, $role, $hash, $target_uid]);
            } else {
                $stmt_up = $pdo->prepare("UPDATE users SET name = ?, phone = ?, role = ? WHERE id = ?");
                $stmt_up->execute([$name, $phone, $role, $target_uid]);
            }

            if ($target_uid === (int)$user['id']) {
                $_SESSION['user_name'] = $name;
            }

            set_flash('success', "تم تحديث بيانات وصلاحيات ({$name}) بنجاح.");
            header("Location: users.php");
            exit;
        }
    }
}

// Fetch Staff & Admins
$staff_list = $pdo->query("
    SELECT * FROM users WHERE role IN ('admin', 'staff') ORDER BY id ASC
")->fetchAll();

// Fetch Customers
$customers_list = $pdo->query("
    SELECT u.*, COUNT(o.id) as orders_count
    FROM users u
    LEFT JOIN orders o ON u.id = o.user_id
    WHERE u.role = 'customer'
    GROUP BY u.id
    ORDER BY u.id DESC
")->fetchAll();
?>

<!-- Top Header Info -->
<div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:12px; margin-bottom:24px;">
  <div>
    <h2 style="font-size:1.5rem; font-weight:800; color:#fff; margin-bottom:4px;">👥 إدارة الموظفين وفريق العمل</h2>
    <p style="color:var(--admin-muted); font-size:0.875rem;">صلاحية خاصة بالمدير العام: إضافة وتعيين الموظفين وحذفهم وتحديد صلاحياتهم.</p>
  </div>
  <a href="index.php" class="btn-back" style="margin:0;">
    <span>⬅️</span> <span>العودة للوحة الرئيسية</span>
  </a>
</div>

<!-- Add New Staff Form Card -->
<div class="admin-card" style="margin-bottom:30px; border:1px solid rgba(0,229,255,0.3);">
  <div class="admin-card-header" style="background:rgba(0,229,255,0.05);">
    <h3 class="admin-card-title">➕ إضافة موظف جديد إلى متجر الغزي</h3>
  </div>

  <form action="users.php" method="POST" style="padding:20px;">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="action" value="add_staff">

    <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:16px; margin-bottom:16px;">
      <div class="form-group">
        <label class="form-label">الاسم الكامل للموظف *</label>
        <input type="text" name="name" class="form-control" required placeholder="مثال: فهد سالم الحارثي">
      </div>

      <div class="form-group">
        <label class="form-label">البريد الإلكتروني (اسم المستخدم) *</label>
        <input type="email" name="email" class="form-control" required placeholder="مثال: fahad@alghazi.com">
      </div>

      <div class="form-group">
        <label class="form-label">كلمة المرور *</label>
        <input type="password" name="password" class="form-control" required placeholder="6 خانات على الأقل">
      </div>

      <div class="form-group">
        <label class="form-label">رقم الهاتف / الجوال</label>
        <input type="text" name="phone" class="form-control" placeholder="+966 50 000 0000">
      </div>

      <div class="form-group">
        <label class="form-label">الدور / الصلاحية *</label>
        <select name="role" class="form-control">
          <option value="staff" selected>💼 موظف متجر (تحديث الطلبات والمخزون، حجب الأرباح)</option>
          <option value="admin">👑 مدير مساعد (صلاحية كاملة للمبيعات والإعدادات)</option>
        </select>
      </div>
    </div>

    <button type="submit" class="btn btn-primary" style="padding:10px 24px; font-weight:700;">
      💾 حفظ وتعيين الموظف
    </button>
  </form>
</div>

<!-- Staff Table -->
<div class="admin-card" style="margin-bottom:30px;">
  <div class="admin-card-header">
    <h3 class="admin-card-title">👔 قائمة الموظفين والمدراء (<?php echo count($staff_list); ?>)</h3>
  </div>

  <div style="overflow-x:auto;">
    <table class="admin-table">
      <thead>
        <tr>
          <th>#</th>
          <th>اسم الموظف</th>
          <th>البريد الإلكتروني (اسم الدخول)</th>
          <th>رقم الجوال</th>
          <th>الصلاحية</th>
          <th>الحالة</th>
          <th>الإجراءات</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($staff_list as $s): ?>
          <tr>
            <td style="color:var(--admin-muted);"><?php echo $s['id']; ?></td>
            <td>
              <strong style="color:#fff;"><?php echo htmlspecialchars($s['name']); ?></strong>
              <?php if ($s['id'] === $user['id']): ?>
                <span class="badge" style="background:rgba(0,229,255,0.2); color:var(--admin-primary); margin-right:6px;">أنت</span>
              <?php endif; ?>
            </td>
            <td><?php echo htmlspecialchars($s['email']); ?></td>
            <td><?php echo htmlspecialchars($s['phone'] ?? '—'); ?></td>
            <td>
              <span class="badge" style="background:<?php echo $s['role'] === 'admin' ? 'var(--admin-primary)' : 'var(--admin-secondary)'; ?>; color:#000; font-weight:800;">
                <?php echo $s['role'] === 'admin' ? '👑 مدير عام' : '💼 موظف متجر'; ?>
              </span>
            </td>
            <td>
              <?php if ($s['is_active']): ?>
                <span class="status-badge status-delivered">نشط</span>
              <?php else: ?>
                <span class="status-badge status-cancelled">معطل</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if ($s['id'] !== $user['id'] && $s['id'] !== 1): ?>
                <div style="display:flex; gap:8px;">
                  <a href="users.php?toggle_status=<?php echo $s['id']; ?>" class="btn-sm <?php echo $s['is_active'] ? 'btn-secondary-sm' : 'btn-primary-sm'; ?>" title="تفعيل / إيقاف">
                    <?php echo $s['is_active'] ? '⏸️ إيقاف' : '▶️ تفعيل'; ?>
                  </a>
                  <a href="users.php?delete_user=<?php echo $s['id']; ?>" class="btn-sm btn-danger-sm" onclick="return confirm('هل أنت متأكد من حذف هذا الموظف نهائياً من النظام؟ لن يتمكن من تسجيل الدخول بعد الآن.');" title="حذف الموظف">
                    🗑️ حذف
                  </a>
                </div>
              <?php else: ?>
                <span style="font-size:0.8rem; color:var(--admin-muted);">محمي</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Customers Table -->
<div class="admin-card">
  <div class="admin-card-header">
    <h3 class="admin-card-title">👥 عملاء المتجر المسجلين (<?php echo count($customers_list); ?>)</h3>
  </div>

  <div style="overflow-x:auto;">
    <table class="admin-table">
      <thead>
        <tr>
          <th>#</th>
          <th>اسم العميل</th>
          <th>البريد الإلكتروني</th>
          <th>رقم الجوال</th>
          <th>المدينة</th>
          <th>عدد الطلبات</th>
          <th>الحالة</th>
          <th>الإجراءات</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($customers_list as $c): ?>
          <tr>
            <td style="color:var(--admin-muted);"><?php echo $c['id']; ?></td>
            <td><strong style="color:#fff;"><?php echo htmlspecialchars($c['name']); ?></strong></td>
            <td><?php echo htmlspecialchars($c['email']); ?></td>
            <td><?php echo htmlspecialchars($c['phone'] ?? '—'); ?></td>
            <td><?php echo htmlspecialchars($c['city'] ?? '—'); ?></td>
            <td><strong style="color:var(--admin-primary);"><?php echo $c['orders_count']; ?></strong></td>
            <td>
              <?php if ($c['is_active']): ?>
                <span class="status-badge status-delivered">مفعل</span>
              <?php else: ?>
                <span class="status-badge status-cancelled">معطل</span>
              <?php endif; ?>
            </td>
            <td>
              <a href="users.php?delete_user=<?php echo $c['id']; ?>" class="btn-sm btn-danger-sm" onclick="return confirm('هل تريد حذف هذا العميل؟');">
                🗑️ حذف
              </a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
