<?php
/**
 * AL GHAZI Store - Cart Action Handler (JSON & POST)
 * متجر الغزي للهواتف الذكية - معالجة عمليات السلة
 */

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

if ($action === 'add') {
    $product_id = (int)($_POST['product_id'] ?? 0);
    $quantity = max(1, (int)($_POST['quantity'] ?? 1));

    if ($product_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid product ID']);
        exit;
    }

    // Check if product exists and has stock
    $stmt = $pdo->prepare("SELECT id, name_ar, name_en, stock FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $prod = $stmt->fetch();

    if (!$prod) {
        echo json_encode(['success' => false, 'message' => current_lang() === 'ar' ? 'المنتج غير موجود' : 'Product not found']);
        exit;
    }

    if ($prod['stock'] < $quantity) {
        echo json_encode(['success' => false, 'message' => current_lang() === 'ar' ? 'الكمية المطلوبة غير متوفرة في المخزون' : 'Insufficient stock']);
        exit;
    }

    add_to_cart($product_id, $quantity);

    $msg = current_lang() === 'ar' 
        ? "تمت إضافة (" . htmlspecialchars($prod['name_ar']) . ") إلى السلة بنجاح!" 
        : "Added (" . htmlspecialchars($prod['name_en']) . ") to your cart!";

    echo json_encode([
        'success' => true,
        'message' => $msg,
        'cart_count' => get_cart_count()
    ]);
    exit;
}

if ($action === 'update') {
    $product_id = (int)($_POST['product_id'] ?? 0);
    $quantity = (int)($_POST['quantity'] ?? 1);

    update_cart_quantity($product_id, $quantity);

    echo json_encode([
        'success' => true,
        'cart_count' => get_cart_count(),
        'message' => current_lang() === 'ar' ? 'تم تحديث الكمية' : 'Quantity updated'
    ]);
    exit;
}

if ($action === 'remove') {
    $product_id = (int)($_POST['product_id'] ?? 0);
    remove_from_cart($product_id);

    echo json_encode([
        'success' => true,
        'cart_count' => get_cart_count(),
        'message' => current_lang() === 'ar' ? 'تم حذف المنتج من السلة' : 'Item removed'
    ]);
    exit;
}

if ($action === 'coupon') {
    $code = strtoupper(trim($_POST['coupon_code'] ?? ''));

    if (empty($code)) {
        unset($_SESSION['coupon']);
        echo json_encode(['success' => false, 'message' => current_lang() === 'ar' ? 'يرجى إدخال كود الخصم' : 'Please enter coupon code']);
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM coupons WHERE code = ? AND is_active = 1");
    $stmt->execute([$code]);
    $coupon = $stmt->fetch();

    if (!$coupon) {
        unset($_SESSION['coupon']);
        echo json_encode(['success' => false, 'message' => __('coupon_invalid')]);
        exit;
    }

    // Check expiry
    if ($coupon['expiry_date'] && strtotime($coupon['expiry_date']) < time()) {
        unset($_SESSION['coupon']);
        echo json_encode(['success' => false, 'message' => __('coupon_invalid')]);
        exit;
    }

    $_SESSION['coupon'] = [
        'code' => $coupon['code'],
        'discount_type' => $coupon['discount_type'],
        'discount_val' => (float)$coupon['discount_val'],
        'min_order' => (float)$coupon['min_order']
    ];

    echo json_encode([
        'success' => true,
        'message' => __('coupon_applied')
    ]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Unknown action']);
