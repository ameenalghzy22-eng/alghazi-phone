<?php
/**
 * AL GHAZI Phone Store - Checkout Page
 * متجر الغزي للهواتف الذكية - صفحة إتمام الطلب والدفع
 */

$page_title = 'إتمام الطلب';
$active_nav = 'checkout';
require_once __DIR__ . '/includes/header.php';
$pdo = get_db();

$cart_data = get_cart_items_details($pdo);
$items = $cart_data['items'];
$subtotal = $cart_data['subtotal'];

if (empty($items)) {
    header("Location: cart.php");
    exit;
}

$discount = calculate_discount_amount($subtotal);
$shipping = calculate_shipping_fee($subtotal - $discount);
$grand_total = max(0, ($subtotal - $discount) + $shipping);
$coupon_code = isset($_SESSION['coupon']) ? $_SESSION['coupon']['code'] : null;

$logged_user = current_user();

// Process Checkout POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        set_flash('danger', 'Invalid security token. Please try again.');
        header("Location: checkout.php");
        exit;
    }

    $customer_name = clean_input($_POST['customer_name'] ?? '');
    $customer_email = clean_input($_POST['customer_email'] ?? '');
    $customer_phone = clean_input($_POST['customer_phone'] ?? '');
    $shipping_city = clean_input($_POST['shipping_city'] ?? '');
    $shipping_address = clean_input($_POST['shipping_address'] ?? '');
    $payment_method = clean_input($_POST['payment_method'] ?? 'cod');
    $notes = clean_input($_POST['order_notes'] ?? '');

    // Validation
    $errors = [];
    if (empty($customer_name)) $errors[] = current_lang() === 'ar' ? 'يرجى إدخال الاسم الكامل' : 'Full name is required';
    if (empty($customer_email) || !filter_var($customer_email, FILTER_VALIDATE_EMAIL)) $errors[] = current_lang() === 'ar' ? 'يرجى إدخال بريد إلكتروني صحيح' : 'Valid email is required';
    if (empty($customer_phone)) $errors[] = current_lang() === 'ar' ? 'يرجى إدخال رقم الهاتف' : 'Phone number is required';
    if (empty($shipping_city)) $errors[] = current_lang() === 'ar' ? 'يرجى تحديد المدينة' : 'City is required';
    if (empty($shipping_address)) $errors[] = current_lang() === 'ar' ? 'يرجى كتابة العنوان بالتفصيل' : 'Street address is required';

    if (!empty($errors)) {
        set_flash('danger', implode(' - ', $errors));
    } else {
        try {
            $pdo->beginTransaction();

            // Generate unique Order Number
            $order_number = 'ORD-' . date('Y') . '-' . mt_rand(10000, 99999);
            $user_id = $logged_user ? $logged_user['id'] : null;

            $stmt_ord = $pdo->prepare("
                INSERT INTO orders (
                    order_number, user_id, customer_name, customer_email, customer_phone,
                    shipping_city, shipping_address, payment_method, subtotal, shipping_cost,
                    discount_amount, coupon_code, grand_total, status, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)
            ");
            $stmt_ord->execute([
                $order_number, $user_id, $customer_name, $customer_email, $customer_phone,
                $shipping_city, $shipping_address, $payment_method, $subtotal, $shipping_cost ?? $shipping,
                $discount, $coupon_code, $grand_total, $notes
            ]);
            $order_id = $pdo->lastInsertId();

            // Insert Order Items and decrement stock
            $stmt_item = $pdo->prepare("
                INSERT INTO order_items (order_id, product_id, product_name, product_image, price, quantity, subtotal)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt_stock = $pdo->prepare("UPDATE products SET stock = MAX(0, stock - ?) WHERE id = ?");

            foreach ($items as $item) {
                $prod = $item['product'];
                $stmt_item->execute([
                    $order_id,
                    $prod['id'],
                    get_localized($prod, 'name'),
                    $prod['main_image'],
                    $item['unit_price'],
                    $item['quantity'],
                    $item['line_total']
                ]);

                // Decrement stock
                $stmt_stock->execute([$item['quantity'], $prod['id']]);
            }

            $pdo->commit();

            // Clear Cart and Coupon
            clear_cart();

            // Redirect to Confirmation
            header("Location: order-confirmation.php?id=" . $order_id);
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            set_flash('danger', 'Error placing order: ' . $e->getMessage());
        }
    }
}
?>

<button onclick="window.location.href='cart.php'" class="btn-back">
  ⬅️ <?php echo current_lang() === 'ar' ? 'رجوع إلى السلة' : 'Back to Cart'; ?>
</button>

<div class="section-header" style="margin-top: 5px;">
  <h1 class="section-title">💳 <?php _e('checkout_title'); ?></h1>
</div>

<form action="checkout.php" method="POST">
  <?php echo csrf_field(); ?>

  <div class="cart-layout">
    <!-- Customer Details & Shipping Form -->
    <div class="cart-table-card">
      <h3 style="font-size:1.2rem; font-weight:800; margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:12px;">
        👤 <?php _e('customer_information'); ?>
      </h3>

      <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
        <div class="form-group">
          <label class="form-label"><?php _e('full_name'); ?> *</label>
          <input type="text" name="customer_name" class="form-control" required
                 value="<?php echo htmlspecialchars($logged_user['name'] ?? $_POST['customer_name'] ?? ''); ?>"
                 placeholder="محمد عبد الله">
        </div>

        <div class="form-group">
          <label class="form-label"><?php _e('email_address'); ?> *</label>
          <input type="email" name="customer_email" class="form-control" required
                 value="<?php echo htmlspecialchars($logged_user['email'] ?? $_POST['customer_email'] ?? ''); ?>"
                 placeholder="name@example.com">
        </div>
      </div>

      <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
        <div class="form-group">
          <label class="form-label"><?php _e('phone_number'); ?> *</label>
          <input type="tel" name="customer_phone" class="form-control" required
                 value="<?php echo htmlspecialchars($logged_user['phone'] ?? $_POST['customer_phone'] ?? ''); ?>"
                 placeholder="+967 7X XXX XXXX (يمن موبايل / يو / سبأفون)">
        </div>

        <div class="form-group">
          <label class="form-label">المحافظة / المدينة (اليمن) *</label>
          <select name="shipping_city" class="form-control" required>
            <optgroup label="🇾🇪 محافظات الجمهورية اليمنية">
              <option value="صنعاء" selected>صنعاء (Sana'a) - أمانة العاصمة والمحافظة</option>
              <option value="عدن">عدن (Aden) - المعلا، خور مكسر، كريتر، الشيخ عثمان</option>
              <option value="تعز">تعز (Taiz) - الحوبان، المدينة، التربة</option>
              <option value="حضرموت - المكلا">حضرموت - المكلا (Mukalla)</option>
              <option value="حضرموت - سيئون">حضرموت - سيئون وتريم والوادي</option>
              <option value="الحديدة">الحديدة (Hodeidah)</option>
              <option value="إب">إب (Ibb) - المدينة، يريم، القاعدة</option>
              <option value="ذمار">ذمار (Dhamar)</option>
              <option value="مأرب">مأرب (Marib)</option>
              <option value="شبوة - عتق">شبوة - عتق (Ataq)</option>
              <option value="المهرة - الغيضة">المهرة - الغيضة (Al Mahrah)</option>
              <option value="لحج">لحج - الحوطة</option>
              <option value="أبين - زنجبار">أبين - زنجبار وجعار</option>
              <option value="البيضاء">البيضاء ورداع</option>
              <option value="حجة">حجة (Hajjah)</option>
              <option value="صعدة">صعدة (Saada)</option>
              <option value="الضالع">الضالع (Ad Dali)</option>
              <option value="عمران">عمران (Amran)</option>
              <option value="الجوف">الجوف (Al Jawf)</option>
              <option value="المحويت">المحويت (Al Mahwit)</option>
              <option value="ريمة">ريمة (Raymah)</option>
              <option value="أرخبيل سقطرى">أرخبيل سقطرى (Socotra)</option>
            </optgroup>
            <optgroup label="🌍 مدن ودول أخرى">
              <option value="الرياض">الرياض (Riyadh)</option>
              <option value="جدة">جدة (Jeddah)</option>
              <option value="مسقط">مسقط (Muscat)</option>
              <option value="دبي">دبي (Dubai)</option>
              <option value="أخرى">مدينة أخرى (Other)</option>
            </optgroup>
          </select>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label"><?php _e('street_address'); ?> *</label>
        <textarea name="shipping_address" class="form-control" rows="3" required placeholder="الحي، اسم الشارع، رقم المبنى، الرمز البريدي..."><?php echo htmlspecialchars($_POST['shipping_address'] ?? ''); ?></textarea>
      </div>

      <div class="form-group">
        <label class="form-label"><?php _e('order_notes'); ?></label>
        <textarea name="order_notes" class="form-control" rows="2" placeholder="ملاحظات التسليم لمندوب الشحن..."><?php echo htmlspecialchars($_POST['order_notes'] ?? ''); ?></textarea>
      </div>

      <!-- Payment Method Selection -->
      <h3 style="font-size:1.2rem; font-weight:800; margin:30px 0 20px; border-bottom:1px solid var(--border-color); padding-bottom:12px;">
        💰 <?php _e('payment_method'); ?>
      </h3>

      <div style="display:flex; flex-direction:column; gap:14px;">
        <label style="background:var(--bg-surface); border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:16px; display:flex; align-items:flex-start; gap:14px; cursor:pointer;">
          <input type="radio" name="payment_method" value="cod" checked style="margin-top:4px; accent-color:var(--primary);">
          <div>
            <strong style="color:#fff; display:block; font-size:1rem; margin-bottom:4px;">💵 <?php _e('cod'); ?></strong>
            <span style="font-size:0.85rem; color:var(--text-muted);"><?php _e('cod_desc'); ?></span>
          </div>
        </label>

        <label style="background:var(--bg-surface); border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:16px; display:flex; align-items:flex-start; gap:14px; cursor:pointer;">
          <input type="radio" name="payment_method" value="bank_transfer" style="margin-top:4px; accent-color:var(--primary);">
          <div>
            <strong style="color:#fff; display:block; font-size:1rem; margin-bottom:4px;">🏦 <?php _e('bank_transfer'); ?></strong>
            <span style="font-size:0.85rem; color:var(--text-muted);"><?php _e('bank_transfer_desc'); ?></span>
          </div>
        </label>

        <label style="background:var(--bg-surface); border:1px solid var(--border-color); border-radius:var(--radius-sm); padding:16px; display:flex; align-items:flex-start; gap:14px; cursor:pointer;">
          <input type="radio" name="payment_method" value="card" style="margin-top:4px; accent-color:var(--primary);">
          <div>
            <strong style="color:#fff; display:block; font-size:1rem; margin-bottom:4px;">💳 <?php _e('credit_card'); ?></strong>
            <span style="font-size:0.85rem; color:var(--text-muted);"><?php _e('credit_card_desc'); ?></span>
          </div>
        </label>
      </div>
    </div>

    <!-- Review Order Summary Column -->
    <div class="summary-card">
      <h3 style="font-size:1.25rem; font-weight:800; margin-bottom:20px; border-bottom:1px solid var(--border-color); padding-bottom:12px;">
        <?php _e('order_summary'); ?> (<?php echo count($items); ?>)
      </h3>

      <!-- Items Mini List -->
      <div style="display:flex; flex-direction:column; gap:12px; margin-bottom:20px; max-height:260px; overflow-y:auto;">
        <?php foreach ($items as $item): ?>
          <?php 
            $prod = $item['product']; 
            $p_name = get_localized($prod, 'name');
            $img = 'assets/images/products/' . htmlspecialchars($prod['main_image']);
            if (!file_exists(__DIR__ . '/' . $img)) {
                $img = 'uploads/products/' . htmlspecialchars($prod['main_image']);
            }
          ?>
          <div style="display:flex; align-items:center; gap:12px; font-size:0.875rem;">
            <img src="<?php echo $img; ?>" alt="img" style="width:44px; height:44px; border-radius:6px; background:var(--bg-surface); padding:2px; object-fit:contain;">
            <div style="flex:1;">
              <div style="font-weight:700; line-height:1.3; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:170px;">
                <?php echo htmlspecialchars($p_name); ?>
              </div>
              <div style="color:var(--text-dim); font-size:0.75rem;">x<?php echo $item['quantity']; ?></div>
            </div>
            <div style="font-weight:700;">
              <?php echo format_price($item['line_total']); ?>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <!-- Financial Totals -->
      <div class="summary-row">
        <span><?php _e('subtotal'); ?>:</span>
        <strong style="color:#fff;"><?php echo format_price($subtotal); ?></strong>
      </div>

      <?php if ($discount > 0): ?>
        <div class="summary-row" style="color:var(--success);">
          <span><?php _e('discount'); ?> (<?php echo htmlspecialchars($coupon_code); ?>):</span>
          <strong>-<?php echo format_price($discount); ?></strong>
        </div>
      <?php endif; ?>

      <div class="summary-row">
        <span><?php _e('shipping'); ?>:</span>
        <strong><?php echo $shipping == 0 ? '<span style="color:var(--success);">' . __('free') . '</span>' : format_price($shipping); ?></strong>
      </div>

      <div class="summary-row total">
        <span><?php _e('total'); ?>:</span>
        <span style="color:var(--primary);"><?php echo format_price($grand_total); ?></span>
      </div>

      <!-- Submit Order Button -->
      <div style="margin-top:24px;">
        <button type="submit" class="btn-primary" style="padding:15px; font-size:1.05rem;">
          🚀 <?php _e('place_order'); ?>
        </button>
      </div>

      <div style="margin-top:16px; font-size:0.75rem; color:var(--text-dim); text-align:center;">
        🔒 <?php echo current_lang() === 'ar' ? 'بياناتك مشفرة ومحمية بالكامل عبر بروتوكول SSL الآمن.' : 'Your details are encrypted and securely protected via SSL.'; ?>
      </div>
    </div>
  </div>
</form>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
