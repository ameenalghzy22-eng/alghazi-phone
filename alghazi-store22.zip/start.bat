@echo off
title AL GHAZI Phone Store - متجر الغزي
chcp 65001 > nul
echo ===================================================
echo     AL GHAZI Phone Store - متجر الغزي للهواتف
echo ===================================================
echo جاري تشغيل المتجر وقاعدة البيانات...
python run_store.py
pause
