<?php
/**
 * AL GHAZI Phone Store - Logout Handler
 * متجر الغزي للهواتف الذكية - تسجيل الخروج
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

logout_user();
set_flash('info', current_lang() === 'ar' ? 'تم تسجيل خروجك بنجاح. نتمنى رؤيتك مجدداً!' : 'You have been logged out successfully. See you soon!');
header("Location: login.php");
exit;
