<?php
/**
 * AL GHAZI Phone Store - Registration Page
 * متجر الغزي للهواتف الذكية - صفحة إنشاء حساب جديد
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$pdo = get_db();

if (is_logged_in()) {
    header("Location: profile.php");
    exit;
}

$page_title = 'إنشاء حساب جديد';
$active_nav = 'register';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid security token. Please try again.';
    } else {
        $name = clean_input($_POST['name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $phone = clean_input($_POST['phone'] ?? '');
        $city = clean_input($_POST['city'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (empty($name) || empty($email) || empty($password)) {
            $error = current_lang() === 'ar' ? 'يرجى ملء جميع الحقول المطلوبة' : 'Please fill all required fields';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = current_lang() === 'ar' ? 'البريد الإلكتروني المدخل غير صالح' : 'Invalid email format';
        } elseif (strlen($password) < 6) {
            $error = current_lang() === 'ar' ? 'كلمة المرور يجب أن لا تقل عن 6 خانات' : 'Password must be at least 6 characters';
        } elseif ($password !== $confirm_password) {
            $error = current_lang() === 'ar' ? 'كلمتا المرور غير متطابقتين' : 'Passwords do not match';
        } else {
            // Check if email already exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = current_lang() === 'ar' ? 'هذا البريد الإلكتروني مسجل مسبقاً، يرجى تسجيل الدخول' : 'Email is already registered. Please login.';
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt_ins = $pdo->prepare("
                    INSERT INTO users (name, email, password_hash, phone, city, role)
                    VALUES (?, ?, ?, ?, ?, 'customer')
                ");
                $stmt_ins->execute([$name, $email, $hash, $phone, $city]);
                $new_id = $pdo->lastInsertId();

                // Login user
                $new_user = [
                    'id' => $new_id,
                    'name' => $name,
                    'email' => $email,
                    'role' => 'customer',
                    'phone' => $phone
                ];
                login_user($new_user);

                set_flash('success', current_lang() === 'ar' ? 'تم إنشاء حسابك بنجاح! أهلاً بك في متجر الغزي.' : 'Account created successfully! Welcome to AL GHAZI.');
                header("Location: profile.php");
                exit;
            }
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width:520px; margin: 40px auto 70px;">
  <div class="cart-table-card">
    <div style="text-align:center; margin-bottom:24px;">
      <h1 style="font-size:1.6rem; font-weight:800; color:#fff; margin-bottom:6px;"><?php _e('register'); ?></h1>
      <p style="color:var(--text-muted); font-size:0.875rem;"><?php echo current_lang() === 'ar' ? 'انضم إلى عائلة متجر الغزي وتمتع بتجربة تسوق فريدة' : 'Join the AL GHAZI family and enjoy an exceptional shopping experience'; ?></p>
    </div>

    <?php if ($error): ?>
      <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form action="register.php" method="POST">
      <?php echo csrf_field(); ?>

      <div class="form-group">
        <label class="form-label"><?php _e('full_name'); ?> *</label>
        <input type="text" name="name" class="form-control" required placeholder="أحمد المنصور" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
      </div>

      <div class="form-group">
        <label class="form-label"><?php _e('email_address'); ?> *</label>
        <input type="email" name="email" class="form-control" required placeholder="ahmad@example.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
        <div class="form-group">
          <label class="form-label"><?php _e('phone_number'); ?></label>
          <input type="tel" name="phone" class="form-control" placeholder="+967 7X XXX XXXX" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>">
        </div>
        <div class="form-group">
          <label class="form-label">المحافظة / المدينة *</label>
          <select name="city" class="form-control">
            <option value="صنعاء">صنعاء (Sana'a)</option>
            <option value="عدن">عدن (Aden)</option>
            <option value="تعز">تعز (Taiz)</option>
            <option value="حضرموت - المكلا">حضرموت - المكلا</option>
            <option value="حضرموت - سيئون">حضرموت - سيئون</option>
            <option value="الحديدة">الحديدة (Hodeidah)</option>
            <option value="إب">إب (Ibb)</option>
            <option value="ذمار">ذمار (Dhamar)</option>
            <option value="مأرب">مأرب (Marib)</option>
            <option value="شبوة">شبوة (Shabwah)</option>
            <option value="المهرة">المهرة (Al Mahrah)</option>
            <option value="لحج">لحج (Lahij)</option>
            <option value="أبين">أبين (Abyan)</option>
            <option value="البيضاء">البيضاء (Al Bayda)</option>
            <option value="حجة">حجة (Hajjah)</option>
            <option value="صعدة">صعدة (Saada)</option>
            <option value="الضالع">الضالع (Ad Dali)</option>
            <option value="أخرى">مدينة / محافظة أخرى</option>
          </select>
        </div>
      </div>

      <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
        <div class="form-group">
          <label class="form-label"><?php _e('password'); ?> *</label>
          <input type="password" name="password" class="form-control" required placeholder="••••••••">
        </div>
        <div class="form-group">
          <label class="form-label"><?php _e('confirm_password'); ?> *</label>
          <input type="password" name="confirm_password" class="form-control" required placeholder="••••••••">
        </div>
      </div>

      <button type="submit" class="btn-primary" style="padding:13px; margin-top:10px;">
        ✨ <?php _e('create_account_now'); ?>
      </button>
    </form>

    <div style="margin-top:24px; text-align:center; font-size:0.875rem; color:var(--text-muted); border-top:1px solid var(--border-color); padding-top:18px;">
      <?php _e('already_have_account'); ?>
      <a href="login.php" style="color:var(--primary); font-weight:700; margin-inline-start:4px;">
        <?php _e('login_here'); ?>
      </a>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
