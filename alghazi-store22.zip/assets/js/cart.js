/**
 * AL GHAZI Phone Store - Cart JavaScript
 * متجر الغزي للهواتف الذكية - إدارة السلة والعمليات الفورية
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. AJAX Add to Cart Buttons
    document.querySelectorAll('.btn-add-cart-ajax').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.preventDefault();
            const productId = btn.getAttribute('data-id');
            const qtyInput = document.getElementById('productQty');
            const qty = qtyInput ? parseInt(qtyInput.value) || 1 : 1;

            const originalText = btn.innerHTML;
            btn.innerHTML = '<span>⏳...</span>';
            btn.disabled = true;

            try {
                const formData = new FormData();
                formData.append('action', 'add');
                formData.append('product_id', productId);
                formData.append('quantity', qty);

                const response = await fetch('php/cart-action.php', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();
                if (data.success) {
                    // Update Badge in header
                    const badge = document.getElementById('cartBadgeCount');
                    if (badge) {
                        badge.textContent = data.cart_count;
                        badge.style.display = 'flex';
                    }
                    showToast(data.message, 'success');
                } else {
                    showToast(data.message || 'حدث خطأ أثناء الإضافة', 'danger');
                }
            } catch (err) {
                console.error('Cart Error:', err);
                // Fallback: regular form submit or link
                window.location.href = `cart.php?add=${productId}&qty=${qty}`;
            } finally {
                btn.innerHTML = originalText;
                btn.disabled = false;
            }
        });
    });
});
