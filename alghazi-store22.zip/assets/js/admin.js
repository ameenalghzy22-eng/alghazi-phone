/**
 * AL GHAZI Store - Admin Panel JavaScript
 * متجر الغزي للهواتف الذكية - تفاعلات لوحة التحكم
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Image Upload Live Preview
    const imageInput = document.getElementById('productImageInput');
    const imagePreview = document.getElementById('productImagePreview');

    if (imageInput && imagePreview) {
        imageInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        });
    }

    // 2. Confirmation prompt on delete buttons
    document.querySelectorAll('.btn-confirm-delete').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const msg = btn.getAttribute('data-confirm') || 'هل أنت متأكد من الحذف؟ لا يمكن التراجع.';
            if (!confirm(msg)) {
                e.preventDefault();
            }
        });
    });
});
