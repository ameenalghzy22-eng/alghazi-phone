<?php
/**
 * AL GHAZI Phone Store - About Us Page
 * متجر الغزي للهواتف الذكية - صفحة من نحن والضمان
 */

$page_title = 'من نحن';
$active_nav = 'about';
require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width:960px; margin: 30px auto 60px;">
  <!-- Hero Section -->
  <div style="background: linear-gradient(135deg, rgba(0,229,255,0.1), rgba(58,134,255,0.15)); border:1px solid var(--border-color); border-radius:var(--radius-lg); padding:50px 30px; text-align:center; margin-bottom:40px;">
    <h1 style="font-size:2.2rem; font-weight:900; color:#fff; margin-bottom:12px;">
      <?php _e('about_heading'); ?>
    </h1>
    <p style="font-size:1.1rem; color:var(--text-muted); max-width:650px; margin:0 auto; line-height:1.7;">
      <?php _e('site_tagline'); ?>
    </p>
  </div>

  <!-- Story & Vision -->
  <div class="cart-table-card" style="margin-bottom:30px;">
    <h2 style="font-size:1.4rem; font-weight:800; color:#fff; margin-bottom:15px;">
      📖 <?php echo current_lang() === 'ar' ? 'قصتنا ورؤيتنا' : 'Our Story & Vision'; ?>
    </h2>
    <p style="color:var(--text-muted); line-height:1.8; margin-bottom:16px;">
      <?php echo current_lang() === 'ar'
        ? 'انطلق <strong>متجر الغزي (AL GHAZI)</strong> برؤية طموحة تهدف إلى إعادة تعريف تجربة شراء الهواتف الذكية والأجهزة الإلكترونية في العالم العربي، من خلال تقديم أحدث المنتجات العالمية الأصلية 100% بأسعار منافسة وبأعلى معايير الشفافية والموثوقية.'
        : '<strong>AL GHAZI Phone Store</strong> was founded with an ambitious vision to redefine the smartphone and electronics purchasing experience, delivering 100% genuine global flagships at competitive prices with supreme transparency and reliability.';
      ?>
    </p>
    <p style="color:var(--text-muted); line-height:1.8;">
      <?php echo current_lang() === 'ar'
        ? 'نحن نؤمن بأن الهاتف الذكي ليس مجرد جهاز، بل هو بوابتك للعمل والتواصل والإبداع، ولهذا نحرص على انتقاء أفضل الإصدارات من كبرى الشركات العالمية مثل Apple، Samsung، Xiaomi، Google، وSony، وتوفيرها مع ضمانات رسمية معتمدة وخدمات دعم فني متواصلة.'
        : 'We believe a smartphone is not just a tool, but your daily hub for productivity, connection, and creativity. We curate the latest innovations from world-leading brands and back them with verified official warranties and round-the-clock support.';
      ?>
    </p>
  </div>

  <!-- Core Pillars Grid -->
  <div class="features-grid" style="margin-bottom:40px;">
    <div class="feature-card">
      <div class="feature-icon">🛡️</div>
      <div class="feature-info">
        <h4><?php _e('feature_original_title'); ?></h4>
        <p><?php _e('feature_original_desc'); ?></p>
      </div>
    </div>
    <div class="feature-card">
      <div class="feature-icon">⚡</div>
      <div class="feature-info">
        <h4><?php _e('feature_shipping_title'); ?></h4>
        <p><?php _e('feature_shipping_desc'); ?></p>
      </div>
    </div>
    <div class="feature-card">
      <div class="feature-icon">🏅</div>
      <div class="feature-info">
        <h4><?php _e('feature_warranty_title'); ?></h4>
        <p><?php _e('feature_warranty_desc'); ?></p>
      </div>
    </div>
    <div class="feature-card">
      <div class="feature-icon">🤝</div>
      <div class="feature-info">
        <h4><?php _e('feature_support_title'); ?></h4>
        <p><?php _e('feature_support_desc'); ?></p>
      </div>
    </div>
  </div>

  <!-- Policies: Warranty & Returns -->
  <div id="warranty" class="cart-table-card" style="margin-bottom:30px;">
    <h2 style="font-size:1.35rem; font-weight:800; color:#fff; margin-bottom:14px;">
      🛡️ <?php _e('warranty_policy'); ?>
    </h2>
    <p style="color:var(--text-muted); line-height:1.8;">
      <?php echo current_lang() === 'ar'
        ? 'جميع الهواتف والأجهزة الإلكترونية المباعة عبر متجر الغزي مشمولة بضمان رسمي معتمد لمدة سنتين (24 شهراً) يشمل الصيانة وقطع الغيار الأصلية لدى مراكز الخدمة المعتمدة، مع استبدال فوري للجهاز خلال الـ 14 يوماً الأولى في حال وجود أي عيب مصنعي.'
        : 'All smartphones and devices purchased through AL GHAZI are protected by a comprehensive 2-year (24-month) official agency warranty covering genuine parts and certified repair centers, plus immediate replacement within the first 14 days for any factory defect.';
      ?>
    </p>
  </div>

  <div id="returns" class="cart-table-card" style="margin-bottom:30px;">
    <h2 style="font-size:1.35rem; font-weight:800; color:#fff; margin-bottom:14px;">
      🔄 <?php _e('return_policy'); ?>
    </h2>
    <p style="color:var(--text-muted); line-height:1.8;">
      <?php echo current_lang() === 'ar'
        ? 'يحق للعميل استرجاع أو استبدال المنتج خلال 14 يوماً من تاريخ الاستلام، شريطة أن يكون المنتج بحالته الأصلية غير مفتوح ومغلفاً بغلاف المصنع، مع كافة ملحقاته وفاتورة الشراء الرسمية.'
        : 'Customers have the right to return or exchange unopened products within 14 days of receipt, provided the item is in its brand new sealed factory packaging with all accessories and the official invoice.';
      ?>
    </p>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
