<?php
/**
 * AL GHAZI Phone Store - Order Confirmation & Invoice
 * متجر الغزي للهواتف الذكية - صفحة تأكيد الطلب والفاتورة
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

$pdo = get_db();

$order_id = (int)($_GET['id'] ?? 0);

if ($order_id <= 0) {
    header("Location: index.php");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch();

if (!$order) {
    header("Location: index.php");
    exit;
}

// Fetch order items
$stmt_items = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
$stmt_items->execute([$order_id]);
$order_items = $stmt_items->fetchAll();

$page_title = 'تأكيد الطلب #' . $order['order_number'];
require_once __DIR__ . '/includes/header.php';
?>

<div style="max-width:850px; margin: 30px auto 60px;">
  <!-- Success Banner -->
  <div style="background:var(--bg-card); border:1px solid var(--primary); border-radius:var(--radius-lg); padding:35px 30px; text-align:center; box-shadow:var(--shadow-glow); margin-bottom:30px;">
    <div style="width:70px; height:70px; border-radius:50%; background:rgba(0,229,255,0.15); border:2px solid var(--primary); color:var(--primary); font-size:2.5rem; display:flex; align-items:center; justify-content:center; margin:0 auto 16px;">
      ✓
    </div>
    <h1 style="font-size:1.85rem; font-weight:900; margin-bottom:8px; color:#fff;">
      <?php _e('order_success_title'); ?>
    </h1>
    <p style="color:var(--text-muted); font-size:0.95rem; max-width:550px; margin:0 auto 18px;">
      <?php _e('order_success_desc'); ?>
    </p>

    <div style="display:inline-flex; align-items:center; gap:12px; background:var(--bg-surface); border:1px solid var(--border-color); padding:10px 24px; border-radius:var(--radius-full); font-size:1.1rem; font-weight:800; color:var(--primary);">
      <span><?php _e('order_number'); ?>:</span>
      <span><?php echo htmlspecialchars($order['order_number']); ?></span>
    </div>
  </div>

  <!-- Order Progress Stepper -->
  <div style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius-md); padding:24px; margin-bottom:30px;">
    <h3 style="font-size:1.1rem; font-weight:800; margin-bottom:15px; text-align:center;">
      📍 <?php _e('order_status'); ?>: 
      <span style="color:var(--primary);"><?php _e('status_' . $order['status']); ?></span>
    </h3>

    <?php
      $steps = ['pending', 'processing', 'shipped', 'delivered'];
      $current_index = array_search($order['status'], $steps);
      if ($current_index === false) $current_index = 0;
    ?>
    <div class="tracking-steps">
      <div class="step-item <?php echo $current_index >= 0 ? 'completed' : ''; ?> <?php echo $order['status'] === 'pending' ? 'active' : ''; ?>">
        <div class="step-circle">1</div>
        <div class="step-label"><?php _e('status_pending'); ?></div>
      </div>
      <div class="step-item <?php echo $current_index >= 1 ? 'completed' : ''; ?> <?php echo $order['status'] === 'processing' ? 'active' : ''; ?>">
        <div class="step-circle">2</div>
        <div class="step-label"><?php _e('status_processing'); ?></div>
      </div>
      <div class="step-item <?php echo $current_index >= 2 ? 'completed' : ''; ?> <?php echo $order['status'] === 'shipped' ? 'active' : ''; ?>">
        <div class="step-circle">3</div>
        <div class="step-label"><?php _e('status_shipped'); ?></div>
      </div>
      <div class="step-item <?php echo $current_index >= 3 ? 'completed' : ''; ?> <?php echo $order['status'] === 'delivered' ? 'active' : ''; ?>">
        <div class="step-circle">4</div>
        <div class="step-label"><?php _e('status_delivered'); ?></div>
      </div>
    </div>
  </div>

  <!-- Order Invoice Card -->
  <div class="cart-table-card" id="printableInvoice">
    <!-- Invoice Header -->
    <div style="display:flex; justify-content:space-between; align-items:flex-start; border-bottom:1px solid var(--border-color); padding-bottom:20px; margin-bottom:20px;">
      <div>
        <img src="assets/images/logo.svg" alt="AL GHAZI" style="height:40px; margin-bottom:10px;">
        <div style="font-size:0.85rem; color:var(--text-muted);"><?php echo htmlspecialchars(get_setting('store_address_' . current_lang(), get_setting('store_address_ar'))); ?></div>
        <div style="font-size:0.85rem; color:var(--text-muted);"><?php echo htmlspecialchars(get_setting('store_phone')); ?></div>
      </div>
      <div style="text-align:<?php echo is_rtl() ? 'left' : 'right'; ?>;">
        <h2 style="font-size:1.4rem; font-weight:800; color:#fff;"><?php echo current_lang() === 'ar' ? 'فاتورة ضريبية' : 'Tax Invoice'; ?></h2>
        <div style="font-size:0.85rem; color:var(--text-muted);"><?php _e('order_date'); ?>: <?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?></div>
        <div style="font-size:0.85rem; color:var(--primary); font-weight:700;"><?php echo htmlspecialchars($order['order_number']); ?></div>
      </div>
    </div>

    <!-- Customer & Shipping Summary -->
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; background:var(--bg-surface); padding:16px; border-radius:var(--radius-sm); margin-bottom:24px; font-size:0.875rem;">
      <div>
        <div style="color:var(--text-dim); font-size:0.775rem; text-transform:uppercase; margin-bottom:4px;"><?php _e('customer_information'); ?></div>
        <div style="font-weight:700; font-size:1rem; color:#fff;"><?php echo htmlspecialchars($order['customer_name']); ?></div>
        <div><?php echo htmlspecialchars($order['customer_email']); ?></div>
        <div><?php echo htmlspecialchars($order['customer_phone']); ?></div>
      </div>
      <div>
        <div style="color:var(--text-dim); font-size:0.775rem; text-transform:uppercase; margin-bottom:4px;"><?php _e('street_address'); ?></div>
        <div style="font-weight:700; color:#fff;"><?php echo htmlspecialchars($order['shipping_city']); ?></div>
        <div style="color:var(--text-muted);"><?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?></div>
        <div style="margin-top:4px;"><strong><?php _e('payment_method'); ?>:</strong> <?php echo strtoupper($order['payment_method']); ?></div>
      </div>
    </div>

    <!-- Items Table -->
    <table class="cart-table" style="margin-bottom:20px;">
      <thead>
        <tr>
          <th><?php _e('product'); ?></th>
          <th><?php _e('price'); ?></th>
          <th><?php _e('quantity'); ?></th>
          <th><?php _e('subtotal'); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($order_items as $oi): ?>
          <tr>
            <td>
              <strong style="color:#fff;"><?php echo htmlspecialchars($oi['product_name']); ?></strong>
            </td>
            <td><?php echo format_price($oi['price']); ?></td>
            <td><?php echo $oi['quantity']; ?></td>
            <td style="font-weight:700; color:var(--primary);"><?php echo format_price($oi['subtotal']); ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <!-- Totals Breakdown -->
    <div style="max-width:320px; margin-inline-start:auto; border-top:1px solid var(--border-color); padding-top:14px;">
      <div class="summary-row">
        <span><?php _e('subtotal'); ?>:</span>
        <strong style="color:#fff;"><?php echo format_price($order['subtotal']); ?></strong>
      </div>
      <?php if ($order['discount_amount'] > 0): ?>
        <div class="summary-row" style="color:var(--success);">
          <span><?php _e('discount'); ?>:</span>
          <strong>-<?php echo format_price($order['discount_amount']); ?></strong>
        </div>
      <?php endif; ?>
      <div class="summary-row">
        <span><?php _e('shipping'); ?>:</span>
        <strong><?php echo $order['shipping_cost'] == 0 ? __('free') : format_price($order['shipping_cost']); ?></strong>
      </div>
      <div class="summary-row total">
        <span><?php _e('total'); ?>:</span>
        <span style="color:var(--primary); font-size:1.35rem;"><?php echo format_price($order['grand_total']); ?></span>
      </div>
    </div>
  </div>

  <!-- Actions -->
  <div style="margin-top:25px; display:flex; justify-content:space-between; flex-wrap:wrap; gap:12px;">
    <button onclick="window.print()" class="btn-sm btn-secondary-sm" style="padding:10px 20px;">
      🖨️ <?php _e('print_invoice'); ?>
    </button>
    <div style="display:flex; gap:10px;">
      <a href="order-tracking.php?order=<?php echo urlencode($order['order_number']); ?>&email=<?php echo urlencode($order['customer_email']); ?>" class="btn-sm btn-secondary-sm" style="padding:10px 20px;">
        🔍 <?php _e('order_tracking'); ?>
      </a>
      <a href="products.php" class="btn-primary" style="display:inline-flex; width:auto; padding:10px 24px;">
        🛒 <?php _e('continue_shopping'); ?>
      </a>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
