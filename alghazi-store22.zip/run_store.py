#!/usr/bin/env python3
"""
AL GHAZI Phone Store - Server & Service Runner (Python)
مشغل متجر الغزي للهواتف الذكية - فحص البيئة وتشغيل السيرفر المحلي
"""
import os
import sys
import shutil
import subprocess
import webbrowser

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.path.join(BASE_DIR, "database", "database.sqlite")
PORT = 8000

def find_php_executable():
    # 1. Check system PATH
    php_path = shutil.which("php")
    if php_path:
        return php_path
    
    # 2. Check common Windows paths
    candidates = [
        r"C:\xampp\php\php.exe",
        r"C:\php\php.exe",
        r"C:\tools\php\php.exe",
        r"C:\Program Files\PHP\php.exe",
        r"C:\Program Files (x86)\PHP\php.exe"
    ]
    for c in candidates:
        if os.path.isfile(c):
            return c
            
    return None

def verify_database():
    if not os.path.isfile(DB_FILE) or os.path.getsize(DB_FILE) == 0:
        print("[*] Database not found. Initializing SQLite database...")
        init_script = os.path.join(BASE_DIR, "python", "db_init.py")
        subprocess.run([sys.executable, init_script], check=True)
    else:
        print(f"[✓] Database verified: {DB_FILE}")

def verify_images():
    logo_file = os.path.join(BASE_DIR, "assets", "images", "logo.svg")
    if not os.path.isfile(logo_file):
        print("[*] Generating store branding and product images...")
        img_script = os.path.join(BASE_DIR, "python", "generate_sample_images.py")
        subprocess.run([sys.executable, img_script], check=True)
    else:
        print("[✓] Store images and graphics verified.")

def main():
    print("=" * 65)
    print("      AL GHAZI STORE — متجر الغزي للهواتف الذكية")
    print("=" * 65)

    # 1. Check & Setup DB & Assets
    verify_images()
    verify_database()

    # 2. Locate PHP
    php_bin = find_php_executable()
    if not php_bin:
        print("\n[!] خطأ: لم يتم العثور على مفسر PHP (php.exe) في النظام.")
        print("    يرجى تثبيت PHP أو إضافته إلى متغيرات البيئة PATH.")
        sys.exit(1)

    print(f"[✓] PHP Executable found: {php_bin}")
    print(f"[✓] Document Root: {BASE_DIR}")
    print(f"[✓] Server URL: http://localhost:{PORT}")
    print("-" * 65)
    print("بيانات الدخول التجريبية (Demo Accounts):")
    print("  👑 المدير: admin@alghazi.com | كلمة المرور: admin123")
    print("  👤 العميل: customer@alghazi.com | كلمة المرور: user123")
    print("-" * 65)
    print(f"🔗 رابط واجهة المتجر: http://localhost:{PORT}/")
    print(f"🔗 رابط لوحة التحكم: http://localhost:{PORT}/admin/")
    print("=" * 65)
    print("جاري تشغيل خادم الويب المحلي... اضغط Ctrl+C للإيقاف.\n")

    # Launch PHP Built-in Server
    try:
        subprocess.run([php_bin, "-S", f"localhost:{PORT}", "-t", BASE_DIR])
    except KeyboardInterrupt:
        print("\n[!] تم إيقاف خادم المتجر بنجاح.")

if __name__ == "__main__":
    main()
