<?php
/**
 * AL GHAZI Phone Store - Product Details Page
 * متجر الغزي للهواتف الذكية - تفاصيل ومواصفات المنتج
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

$pdo = get_db();

$product_id = (int)($_GET['id'] ?? 0);

if ($product_id <= 0) {
    header("Location: products.php");
    exit;
}

$stmt = $pdo->prepare("
    SELECT p.*, c.name_ar as cat_name_ar, c.name_en as cat_name_en, c.slug as cat_slug 
    FROM products p
    JOIN categories c ON p.category_id = c.id
    WHERE p.id = ?
");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    header("Location: products.php");
    exit;
}

$page_title = get_localized($product, 'name');
require_once __DIR__ . '/includes/header.php';

$p_name = get_localized($product, 'name');
$p_desc = get_localized($product, 'description');
$p_price = (float)$product['price'];
$p_discount = ($product['discount_price'] !== null && $product['discount_price'] > 0) ? (float)$product['discount_price'] : null;
$effective_price = $p_discount ?: $p_price;
$has_discount = $p_discount && $p_discount < $p_price;
$discount_percent = $has_discount ? round((($p_price - $p_discount) / $p_price) * 100) : 0;

// Images
$main_image_src = 'assets/images/products/' . htmlspecialchars($product['main_image']);
if (!file_exists(__DIR__ . '/' . $main_image_src)) {
    $main_image_src = 'uploads/products/' . htmlspecialchars($product['main_image']);
}

$gallery_images = [];
if (!empty($product['gallery_images'])) {
    $decoded = json_decode($product['gallery_images'], true);
    if (is_array($decoded)) {
        foreach ($decoded as $gimg) {
            $gsrc = 'assets/images/products/' . htmlspecialchars($gimg);
            if (!file_exists(__DIR__ . '/' . $gsrc)) {
                $gsrc = 'uploads/products/' . htmlspecialchars($gimg);
            }
            $gallery_images[] = $gsrc;
        }
    }
}
if (empty($gallery_images)) {
    $gallery_images[] = $main_image_src;
}

// Specs JSON
$specs = [];
if (!empty($product['specs_json'])) {
    $specs = json_decode($product['specs_json'], true) ?: [];
}

// Related Products (same category, excluding current product)
$stmt_rel = $pdo->prepare("SELECT * FROM products WHERE category_id = ? AND id != ? ORDER BY id DESC LIMIT 4");
$stmt_rel->execute([$product['category_id'], $product_id]);
$related_products = $stmt_rel->fetchAll();
?>

<!-- Back Button & Breadcrumbs -->
<div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin: 15px 0 20px;">
  <button onclick="history.length > 1 ? history.back() : window.location.href='products.php'" class="btn-back" style="margin:0;">
    ⬅️ <?php echo current_lang() === 'ar' ? 'رجوع' : 'Back'; ?>
  </button>
  <div style="font-size:0.85rem; color:var(--text-muted);">
  <a href="index.php"><?php _e('home'); ?></a> &gt; 
  <a href="products.php?category=<?php echo urlencode($product['cat_slug']); ?>"><?php echo htmlspecialchars(get_localized($product, 'cat_name')); ?></a> &gt; 
  <span style="color:var(--text-main); font-weight:700;"><?php echo htmlspecialchars($p_name); ?></span>
</div>

<div class="product-details-layout">
  <!-- Image Gallery Column -->
  <div class="gallery-container">
    <div class="main-image-view">
      <img id="mainProductImg" src="<?php echo $main_image_src; ?>" alt="<?php echo htmlspecialchars($p_name); ?>">
    </div>

    <?php if (count($gallery_images) > 1): ?>
      <div class="gallery-thumbs">
        <?php foreach ($gallery_images as $index => $gimg): ?>
          <div class="thumb-item <?php echo $index === 0 ? 'active' : ''; ?>" data-img="<?php echo $gimg; ?>">
            <img src="<?php echo $gimg; ?>" alt="Thumb">
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>

  <!-- Product Info & Actions Column -->
  <div class="details-content">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <span style="color:var(--primary); font-weight:800; font-size:0.875rem; text-transform:uppercase; letter-spacing:1px;">
        <?php echo htmlspecialchars($product['brand']); ?>
      </span>
      <?php if ($product['stock'] > 0): ?>
        <span style="color:var(--success); font-weight:700; font-size:0.85rem; display:flex; align-items:center; gap:5px;">
          ● <?php _e('stock_available'); ?> (<?php echo $product['stock']; ?>)
        </span>
      <?php else: ?>
        <span style="color:var(--danger); font-weight:700; font-size:0.85rem;">
          ● <?php _e('out_of_stock'); ?>
        </span>
      <?php endif; ?>
    </div>

    <h1 class="details-title"><?php echo htmlspecialchars($p_name); ?></h1>

    <!-- Rating -->
    <div style="display:flex; align-items:center; gap:10px; font-size:0.95rem;">
      <span style="color:var(--accent);">★★★★★</span>
      <span style="font-weight:700;"><?php echo number_format($product['rating'], 1); ?></span>
      <span style="color:var(--text-dim);">(<?php echo $product['rating_count']; ?> <?php echo current_lang() === 'ar' ? 'تقييم موثق' : 'verified reviews'; ?>)</span>
    </div>

    <!-- Pricing Box -->
    <div class="details-price-box">
      <span style="font-size:2rem; font-weight:900; color:#fff;"><?php echo format_price($effective_price); ?></span>
      <?php if ($has_discount): ?>
        <span style="font-size:1.15rem; color:var(--text-dim); text-decoration:line-through;"><?php echo format_price($p_price); ?></span>
        <span class="badge badge-discount" style="font-size:0.85rem;"><?php _e('discount_badge'); ?> <?php echo $discount_percent; ?>%</span>
      <?php endif; ?>
    </div>

    <p class="details-desc">
      <?php echo nl2br(htmlspecialchars($p_desc)); ?>
    </p>

    <!-- Quantity & Add to Cart Action -->
    <form action="cart.php" method="POST" style="margin: 20px 0;">
      <input type="hidden" name="action" value="add">
      <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
      
      <div style="display:flex; flex-wrap:wrap; gap:15px; align-items:center;">
        <div class="quantity-picker">
          <button type="button" class="qty-btn" id="qtyMinus">-</button>
          <input type="number" name="quantity" id="productQty" class="qty-input" value="1" min="1" max="<?php echo max(1, $product['stock']); ?>">
          <button type="button" class="qty-btn" id="qtyPlus">+</button>
        </div>

        <?php if ($product['stock'] > 0): ?>
          <button type="button" class="btn-primary btn-add-cart-ajax" data-id="<?php echo $product['id']; ?>" style="flex:1; min-width:200px;">
            🛒 <?php _e('add_to_cart'); ?>
          </button>
        <?php else: ?>
          <button type="button" class="btn-primary" disabled style="flex:1; opacity:0.5; cursor:not-allowed;">
            <?php _e('out_of_stock'); ?>
          </button>
        <?php endif; ?>
      </div>
    </form>

    <!-- Highlights Badges -->
    <div style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius-md); padding:16px; display:flex; flex-direction:column; gap:10px; font-size:0.85rem;">
      <div style="display:flex; align-items:center; gap:8px;">
        <span>🚚</span>
        <span><?php _e('fast_delivery_note'); ?></span>
      </div>
      <div style="display:flex; align-items:center; gap:8px;">
        <span>💵</span>
        <span><?php _e('cash_on_delivery_available'); ?></span>
      </div>
      <div style="display:flex; align-items:center; gap:8px;">
        <span>🛡️</span>
        <span><?php echo current_lang() === 'ar' ? 'ضمان رسمي شامل لمدة سنتين مع استبدال فوري.' : '2-Year Official Warranty with immediate replacement support.'; ?></span>
      </div>
    </div>
  </div>
</div>

<!-- Technical Specifications Section -->
<?php if (!empty($specs)): ?>
<section style="margin: 40px 0 60px;">
  <div class="section-header">
    <h2 class="section-title">⚙️ <?php _e('specifications'); ?></h2>
  </div>

  <table class="specs-table">
    <tbody>
      <?php foreach ($specs as $key => $val): ?>
        <tr>
          <td><?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $key))); ?></td>
          <td><strong><?php echo htmlspecialchars($val); ?></strong></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</section>
<?php endif; ?>

<!-- Related Products Section -->
<?php if (!empty($related_products)): ?>
<section style="margin-bottom: 60px;">
  <div class="section-header">
    <div>
      <h2 class="section-title">💡 <?php _e('related_products'); ?></h2>
      <p class="section-subtitle"><?php echo current_lang() === 'ar' ? 'اكتشف أجهزة أخرى مميزة من نفس الفئة' : 'Explore more matching gadgets in this category'; ?></p>
    </div>
  </div>

  <div class="products-grid">
    <?php foreach ($related_products as $p): ?>
      <?php include __DIR__ . '/includes/product-card.php'; ?>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
