/**
 * AL GHAZI Store - GitHub Pages Edition
 * Data, Translations & LocalStorage Client Database
 */

const PRODUCTS_DATA = [
  {
    id: 1,
    slug: "iphone-16-pro-max",
    name_ar: "آبل آيفون 16 برو ماكس - 256 جيجابايت",
    name_en: "Apple iPhone 16 Pro Max - 256GB",
    brand: "Apple",
    category: "phones",
    category_name_ar: "الهواتف الذكية",
    category_name_en: "Smartphones",
    price: 1299.00,
    discount_price: 1199.00,
    stock: 15,
    rating: 4.9,
    rating_count: 88,
    main_image: "iphone-16-pro-max.svg",
    is_featured: true,
    is_bestseller: true,
    is_new: true,
    description_ar: "أقوى هاتف من آبل بشريحة A18 Pro الجبارة وإطار تيتانيوم متين مع زر التحكم الجديد بالكاميرا وبطارية تدوم طوال اليوم وشاشة Super Retina XDR مقاس 6.9 بوصة.",
    description_en: "Apple's flagship phone featuring the blazing fast A18 Pro chip, Grade 5 titanium design, Camera Control button, and a stunning 6.9-inch Super Retina XDR display.",
    specs: {
      "المعالج / Chip": "Apple A18 Pro (3nm)",
      "الشاشة / Screen": "6.9-inch OLED 120Hz ProMotion",
      "الذاكرة / Storage": "256GB Unified",
      "الكاميرا / Camera": "48MP Main + 48MP Ultra-wide + 12MP 5x",
      "البطارية / Battery": "4685 mAh, 30W Fast Charge",
      "الضمان / Warranty": "سنتان ضمان الوكيل / 2 Years Warranty"
    }
  },
  {
    id: 2,
    slug: "iphone-16",
    name_ar: "آبل آيفون 16 - 128 جيجابايت",
    name_en: "Apple iPhone 16 - 128GB",
    brand: "Apple",
    category: "phones",
    category_name_ar: "الهواتف الذكية",
    category_name_en: "Smartphones",
    price: 899.00,
    discount_price: 829.00,
    stock: 20,
    rating: 4.8,
    rating_count: 64,
    main_image: "iphone-16.svg",
    is_featured: true,
    is_bestseller: false,
    is_new: true,
    description_ar: "هاتف آيفون 16 الجديد كلياً مع دعم ميزات ذكاء آبل الاصطناعي وزر الإجراءات وكاميرا متطورة بدقة 48 ميجابكسل وألوان عصرية مبهجة.",
    description_en: "The all-new iPhone 16 with Apple Intelligence support, customizable Action button, 48MP Fusion camera and vibrant colors.",
    specs: {
      "المعالج / Chip": "Apple A18",
      "الشاشة / Screen": "6.1-inch Super Retina XDR",
      "الذاكرة / Storage": "128GB",
      "الكاميرا / Camera": "48MP Dual Fusion",
      "البطارية / Battery": "3561 mAh",
      "الضمان / Warranty": "سنتان ضمان رسمي / 2 Years Official"
    }
  },
  {
    id: 3,
    slug: "samsung-galaxy-s25-ultra",
    name_ar: "سامسونج جالكسي S25 ألترا - 512 جيجابايت",
    name_en: "Samsung Galaxy S25 Ultra - 512GB",
    brand: "Samsung",
    category: "phones",
    category_name_ar: "الهواتف الذكية",
    category_name_en: "Smartphones",
    price: 1349.00,
    discount_price: 1249.00,
    stock: 12,
    rating: 5.0,
    rating_count: 95,
    main_image: "samsung-s25-ultra.svg",
    is_featured: true,
    is_bestseller: true,
    is_new: true,
    description_ar: "قمة التقنية مع معالج Snapdragon 8 Elite وقلم S-Pen مدمج وكاميرا بدقة 200 ميجابكسل مع تقريب بصري مذهل وميزات Galaxy AI المتقدمة.",
    description_en: "Ultimate flagship power powered by Snapdragon 8 Elite for Galaxy, integrated S-Pen, 200MP camera system and advanced Galaxy AI tools.",
    specs: {
      "المعالج / Chip": "Snapdragon 8 Elite for Galaxy",
      "الشاشة / Screen": "6.8-inch Dynamic AMOLED 2X, 120Hz",
      "الرام / RAM": "16GB LPDDR5X",
      "الكاميرا / Camera": "200MP Quad ProVisual",
      "البطارية / Battery": "5000 mAh, 45W Fast",
      "الضمان / Warranty": "سنتان ضمان سامسونج / 2 Years Samsung"
    }
  },
  {
    id: 4,
    slug: "samsung-galaxy-z-fold-6",
    name_ar: "سامسونج جالكسي زد فولد 6 قابل للطي",
    name_en: "Samsung Galaxy Z Fold 6 5G",
    brand: "Samsung",
    category: "phones",
    category_name_ar: "الهواتف الذكية",
    category_name_en: "Smartphones",
    price: 1799.00,
    discount_price: 1649.00,
    stock: 8,
    rating: 4.7,
    rating_count: 42,
    main_image: "samsung-z-fold6.svg",
    is_featured: true,
    is_bestseller: false,
    is_new: false,
    description_ar: "شاشة داخلية ضخمة تفتح لتمنحك تجربة حاسوب لوحي مع تصميم أنحف وأخف وزناً ومقاومة للماء ومحرك إنتاجية مدعوم بالذكاء الاصطناعي.",
    description_en: "Unfold a tablet-sized experience in a lighter, thinner chassis with IP48 water resistance and Galaxy AI productivity tools.",
    specs: {
      "الشاشة / Screen": "7.6-inch Foldable Dynamic AMOLED 2X",
      "المعالج / Chip": "Snapdragon 8 Gen 3",
      "الذاكرة / Storage": "512GB / 12GB RAM",
      "الضمان / Warranty": "سنتان مع تأمين الشاشة"
    }
  },
  {
    id: 5,
    slug: "xiaomi-14-ultra",
    name_ar: "شاومي 14 ألترا - كاميرا لايكا الاحترافية",
    name_en: "Xiaomi 14 Ultra - Leica Quad Camera",
    brand: "Xiaomi",
    category: "phones",
    category_name_ar: "الهواتف الذكية",
    category_name_en: "Smartphones",
    price: 1099.00,
    discount_price: 999.00,
    stock: 10,
    rating: 4.8,
    rating_count: 51,
    main_image: "xiaomi-14-ultra.svg",
    is_featured: false,
    is_bestseller: true,
    is_new: false,
    description_ar: "وحش التصوير الفوتوغرافي بمستشعر مقاس 1 بوصة وعدسات لايكا الاحترافية وبطارية عملاقة 5000 مللي أمبير مع شحن خارق 90 واط.",
    description_en: "The master of mobile photography featuring a 1-inch sensor, Leica Summilux quad lenses and 90W HyperCharge.",
    specs: {
      "الكاميرا / Camera": "50MP 1-inch LYT-900 Quad Leica",
      "الشاحن / Charger": "90W HyperCharge",
      "المعالج / Chip": "Snapdragon 8 Gen 3"
    }
  },
  {
    id: 6,
    slug: "google-pixel-9-pro-xl",
    name_ar: "جوجل بيكسل 9 برو إكس إل - الذكاء الاصطناعي الأقوى",
    name_en: "Google Pixel 9 Pro XL - Gemini AI Built-in",
    brand: "Google",
    category: "phones",
    category_name_ar: "الهواتف الذكية",
    category_name_en: "Smartphones",
    price: 1149.00,
    discount_price: 1049.00,
    stock: 14,
    rating: 4.9,
    rating_count: 39,
    main_image: "pixel-9-pro.svg",
    is_featured: true,
    is_bestseller: false,
    is_new: true,
    description_ar: "هاتف جوجل الرائد مع معالج Tensor G4 ومساعد Gemini المتطور وكاميرا تلتقط أروع الصور الواقعية وتحديثات أندرويد مضمونة لسبع سنوات.",
    description_en: "Google's flagship phone with Google Tensor G4, Gemini AI integrated into everyday tasks, and 7 years of OS updates.",
    specs: {
      "المعالج / Chip": "Google Tensor G4",
      "الشاشة / Screen": "6.8-inch Super Actua LTPO 120Hz",
      "الذاكرة / Storage": "256GB / 16GB RAM"
    }
  },
  {
    id: 7,
    slug: "airpods-pro-2-usb-c",
    name_ar: "آبل إيربودز برو 2 مع علبة MagSafe USB-C",
    name_en: "Apple AirPods Pro 2 - Active Noise Cancellation",
    brand: "Apple",
    category: "headphones",
    category_name_ar: "السماعات والصوتيات",
    category_name_en: "Headphones & Audio",
    price: 249.00,
    discount_price: 219.00,
    stock: 30,
    rating: 4.9,
    rating_count: 120,
    main_image: "airpods-pro-2.svg",
    is_featured: true,
    is_bestseller: true,
    is_new: false,
    description_ar: "عزل ضوضاء أنشط بمرتين، ميزة الصوت التكيفي ووضع شفافية الصوت وتتبع حركة الرأس ثلاثي الأبعاد مع مقاومة للغبار والماء.",
    description_en: "Up to 2x more Active Noise Cancellation, Adaptive Audio, Transparency mode, and USB-C MagSafe charging case.",
    specs: {
      "المعالج / Chip": "Apple H2 Headphone Chip",
      "البطارية / Battery": "حتى 30 ساعة مع العلبة / Up to 30h",
      "الميزات / Features": "Spatial Audio, Adaptive EQ"
    }
  },
  {
    id: 8,
    slug: "sony-wh-1000xm5",
    name_ar: "سوني WH-1000XM5 - ملكة عزل الضوضاء",
    name_en: "Sony WH-1000XM5 Wireless Noise Canceling",
    brand: "Sony",
    category: "headphones",
    category_name_ar: "السماعات والصوتيات",
    category_name_en: "Headphones & Audio",
    price: 399.00,
    discount_price: 329.00,
    stock: 14,
    rating: 4.9,
    rating_count: 110,
    main_image: "sony-wh1000xm5.svg",
    is_featured: true,
    is_bestseller: true,
    is_new: false,
    description_ar: "أفضل سماعة رأس عازلة للضوضاء في العالم بمعالجين متطورين و8 ميكروفونات ومكالمات فائقة الوضوح وبطارية تدوم حتى 30 ساعة.",
    description_en: "Industry-leading noise cancellation with 8 microphones, Auto NC Optimizer, and up to 30 hours of continuous playback.",
    specs: {
      "النوع / Type": "Over-Ear Wireless",
      "البطارية / Battery": "30 ساعة / 30 hours",
      "الصوت / Audio": "Hi-Res Audio LDAC, Auto NC"
    }
  },
  {
    id: 9,
    slug: "apple-watch-ultra-2",
    name_ar: "ساعة آبل واتش ألترا 2 - تيتانيوم 49 مم",
    name_en: "Apple Watch Ultra 2 - Titanium 49mm",
    brand: "Apple",
    category: "smartwatches",
    category_name_ar: "الساعات الذكية",
    category_name_en: "Smartwatches",
    price: 799.00,
    discount_price: 749.00,
    stock: 11,
    rating: 4.9,
    rating_count: 68,
    main_image: "apple-watch-ultra-2.svg",
    is_featured: true,
    is_bestseller: true,
    is_new: true,
    description_ar: "أقوى وأصلب ساعة من آبل بهيكل تيتانيوم مقاوم للصدمات، شاشة ساطعة 3000 شمعة، وتتبع دقيق للملاحة والغوص حتى عمق 40 متراً.",
    description_en: "The ultimate sports and adventure watch featuring a rugged 49mm titanium case, 3000-nit display and dual-frequency GPS.",
    specs: {
      "الهيكل / Case": "49mm Grade 5 Titanium",
      "الشاشة / Display": "Always-On Retina 3000 nits",
      "مقاومة الماء / Water": "100m, Dive to 40m"
    }
  },
  {
    id: 10,
    slug: "anker-735-gan-65w-charger",
    name_ar: "شاحن أنكر 735 بتقنية جان 65 واط ثلاثي المنافذ",
    name_en: "Anker 735 GaN 65W Fast Charger (Nano II)",
    brand: "Anker",
    category: "accessories",
    category_name_ar: "الإكسسوارات والشواحن",
    category_name_en: "Accessories & Chargers",
    price: 59.00,
    discount_price: 45.00,
    stock: 45,
    rating: 4.9,
    rating_count: 140,
    main_image: "anker-65w-gan.svg",
    is_featured: true,
    is_bestseller: true,
    is_new: false,
    description_ar: "اشحن هاتفك وجهازك اللوحي وحاسوبك المحمول في نفس الوقت بحجم أصغر بنسبة 59% مع تقنية PowerIQ 4.0 لتوزيع الطاقة الذكي.",
    description_en: "High-speed charging for 3 devices simultaneously with 2 USB-C ports and 1 USB-A port in a compact travel-friendly size.",
    specs: {
      "القوة / Power": "65W Max GaN Technology",
      "المنافذ / Ports": "2x USB-C + 1x USB-A",
      "التوافق / Support": "iPhone, Samsung, Mac, Android"
    }
  },
  {
    id: 11,
    slug: "anker-magsafe-wireless-powerbank-10k",
    name_ar: "بنك طاقة أنكر لاسلكي ماج سيف 10,000 مللي أمبير",
    name_en: "Anker MagSafe Wireless Power Bank 10,000mAh",
    brand: "Anker",
    category: "accessories",
    category_name_ar: "الإكسسوارات والشواحن",
    category_name_en: "Accessories & Chargers",
    price: 69.00,
    discount_price: 55.00,
    stock: 38,
    rating: 4.8,
    rating_count: 92,
    main_image: "magsafe-powerbank.svg",
    is_featured: true,
    is_bestseller: false,
    is_new: false,
    description_ar: "يثبت مغناطيسياً بقوة خلف هاتف آيفون لشحن لاسلكي مريح مع شاشة ديجيتال ذكية تعرض نسبة البطارية والوقت المتبقي بدقة.",
    description_en: "Snap-and-charge convenience with strong 10N magnetic hold, smart digital display, and 20W two-way fast USB-C port.",
    specs: {
      "السعة / Capacity": "10,000 mAh High-Density",
      "الشحن / Charge": "15W Wireless + 20W USB-C PD"
    }
  },
  {
    id: 12,
    slug: "galaxy-buds-3-pro",
    name_ar: "سامسونج جالكسي بودز 3 برو الذكية",
    name_en: "Samsung Galaxy Buds 3 Pro - Hi-Fi Audio",
    brand: "Samsung",
    category: "headphones",
    category_name_ar: "السماعات والصوتيات",
    category_name_en: "Headphones & Audio",
    price: 229.00,
    discount_price: 189.00,
    stock: 25,
    rating: 4.7,
    rating_count: 75,
    main_image: "galaxy-buds-3-pro.svg",
    is_featured: false,
    is_bestseller: true,
    is_new: true,
    description_ar: "تصميم شريطي مضيء جديد كلياً مع صوت Hi-Fi 24-bit نقي وترجمة فورية مباشرة مدعومة بذكاء اصطناعي Galaxy AI وعزل تكيفي ممتاز.",
    description_en: "Sleek blade design with LED lights, 24-bit Hi-Fi sound, adaptive ANC, and real-time Interpreter via Galaxy AI.",
    specs: {
      "الصوت / Audio": "24-bit Hi-Fi Sound",
      "الميزات / Features": "Live Interpreter, Blade Light"
    }
  }
];

// Language handler
function getLang() {
  return localStorage.getItem('alghazi_lang') || 'ar';
}

function setLang(lang) {
  localStorage.setItem('alghazi_lang', lang);
  location.reload();
}

function t(obj, key) {
  const lang = getLang();
  return obj[`${key}_${lang}`] || obj[`${key}_ar`] || '';
}

// LocalStorage Shopping Cart
const Cart = {
  get: function() {
    return JSON.parse(localStorage.getItem('alghazi_cart') || '{}');
  },
  save: function(cart) {
    localStorage.setItem('alghazi_cart', JSON.stringify(cart));
    this.updateBadge();
  },
  add: function(id, qty = 1) {
    const cart = this.get();
    cart[id] = (cart[id] || 0) + parseInt(qty);
    this.save(cart);
    const prod = PRODUCTS_DATA.find(p => p.id == id);
    const title = prod ? (getLang() === 'ar' ? prod.name_ar : prod.name_en) : '';
    showToast(getLang() === 'ar' ? `تمت إضافة (${title}) للسلة بنجاح!` : `Added (${title}) to cart!`, 'success');
  },
  update: function(id, qty) {
    const cart = this.get();
    if (qty <= 0) {
      delete cart[id];
    } else {
      cart[id] = parseInt(qty);
    }
    this.save(cart);
  },
  remove: function(id) {
    const cart = this.get();
    delete cart[id];
    this.save(cart);
    showToast(getLang() === 'ar' ? 'تم حذف المنتج من السلة' : 'Item removed from cart', 'info');
  },
  clear: function() {
    localStorage.removeItem('alghazi_cart');
    localStorage.removeItem('alghazi_coupon');
    this.updateBadge();
  },
  getCount: function() {
    const cart = this.get();
    return Object.values(cart).reduce((a, b) => a + b, 0);
  },
  getItemsDetails: function() {
    const cart = this.get();
    const items = [];
    let subtotal = 0;
    for (const [id, qty] of Object.entries(cart)) {
      const prod = PRODUCTS_DATA.find(p => p.id == id);
      if (prod) {
        const unit_price = prod.discount_price || prod.price;
        const line_total = unit_price * qty;
        subtotal += line_total;
        items.push({ product: prod, quantity: qty, unit_price, line_total });
      }
    }
    return { items, subtotal };
  },
  updateBadge: function() {
    const badge = document.getElementById('cartBadgeCount');
    if (badge) {
      const count = this.getCount();
      badge.textContent = count;
      badge.style.display = count > 0 ? 'flex' : 'none';
    }
  }
};

// LocalStorage Orders
const Orders = {
  all: function() {
    const sampleOrders = [
      {
        order_number: "ORD-2026-9011",
        customer_name: "أحمد عبد الله",
        customer_email: "customer@alghazi.com",
        customer_phone: "+966559876543",
        shipping_city: "جدة",
        shipping_address: "حي الروضة شارع الأمير سلطان",
        payment_method: "cod",
        subtotal: 1199.00,
        shipping_cost: 0,
        discount_amount: 119.90,
        grand_total: 1079.10,
        status: "delivered",
        created_at: "2026-11-15 14:30",
        items: [{ product_name: "آبل آيفون 16 برو ماكس - 256 جيجابايت", quantity: 1, price: 1199.00, subtotal: 1199.00 }]
      }
    ];
    const saved = JSON.parse(localStorage.getItem('alghazi_orders') || 'null');
    if (!saved) {
      localStorage.setItem('alghazi_orders', JSON.stringify(sampleOrders));
      return sampleOrders;
    }
    return saved;
  },
  create: function(orderData) {
    const orders = this.all();
    orders.unshift(orderData);
    localStorage.setItem('alghazi_orders', JSON.stringify(orders));
    return orderData;
  },
  find: function(orderNum, contact) {
    const orders = this.all();
    return orders.find(o => 
      o.order_number.toUpperCase() === orderNum.trim().toUpperCase() &&
      (o.customer_email.toLowerCase() === contact.trim().toLowerCase() || o.customer_phone.includes(contact.trim()))
    );
  }
};

// Global Toast UI
function showToast(message, type = 'success') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<span style="font-weight:900; color:var(--primary);">${type === 'success' ? '✓' : 'ℹ️'}</span> <span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 400);
  }, 3500);
}

document.addEventListener('DOMContentLoaded', () => {
  Cart.updateBadge();
  const dir = getLang() === 'ar' ? 'rtl' : 'ltr';
  document.documentElement.setAttribute('dir', dir);
  document.documentElement.setAttribute('lang', getLang());
});
